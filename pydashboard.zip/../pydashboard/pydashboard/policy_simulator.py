from datetime import datetime

from pydashboard.pydashboard.base import Base
from pytz import timezone


class PolicySimulator(Base):
    """
    Run Simulations for Data Policy
    """

    def __init__(self, name):
        """
        :param name
        """
        self.name = name
        self.simulation_payload = {}
        self.policies = {}
        self.request = {}
        self.request_action = {"attributes": []}
        self.request_environment = {"attributes": []}
        self.request_resource = {"attributes": []}
        self.request_subject = {"attributes": []}

    def build_payload(self):
        self.simulation_payload["name"] = self.name
        self.simulation_payload["policies"] = self.policies
        self.request["action"] = self.request_action
        self.request["environment"] = self.request_environment
        self.request["resource"] = self.request_resource
        self.request["subject"] = self.request_subject
        self.simulation_payload["request"] = self.request

    ###############################################################################
    #
    # Add Policies to the simulation request
    #
    #
    #
    ###############################################################################
    def add_policies(self, policies=[]):
        self.policies["include"] = []
        for each_policy in policies:
            self.policies["include"].append({"id": each_policy["id"]})

    def set_policy_version(self, version):
        self.policies["version"] = version

    ###############################################################################
    # REQUEST -> SUBJECT
    # Add user / group
    #
    # REQUEST -> ENVIRONMENT
    # device / time for the requester
    #
    #
    #
    ###############################################################################

    def add_requester_user(self, users):
        userids = []
        for each_user in users:
            userids.append(each_user["id"])

        attribute = {"id": "subject-id", "value": userids}
        self.request_subject["attributes"].append(attribute)

    def add_requester_groups(self, groups):
        groupids = []
        for each_group in groups:
            groupids.append(each_group["id"])

        attribute = {"id": "group", "value": groupids}
        self.request_subject["attributes"].append(attribute)

    def add_requester_device(self, devices):
        deviceids = []
        for each_device in devices:
            deviceids.append(each_device["sDeviceId"])
        attribute = {"id": "device-id", "value": deviceids}
        self.request_environment["attributes"].append(attribute)

    def add_requester_time(self, specific_time=None):
        time_to_use = specific_time
        if not time_to_use:
            # Use Current Time
            time_to_use = datetime.now(timezone("Etc/GMT"))
        time_to_use = time_to_use.replace(microsecond=0).isoformat("T")
        attribute = {"id": "current-dateTime", "value": time_to_use}
        self.request_environment["attributes"].append(attribute)

    def add_requester_location(self, country):
        country_to_use = country
        if not country_to_use:
            country_to_use = "USA"
        attribute = {"id": "location-country", "value": country_to_use}
        self.request_environment["attributes"].append(attribute)

    def add_requester_ip(self, ip):
        attribute = {"id": "ipAddress", "value": ip}
        self.request_environment["attributes"].append(attribute)

    ###############################################################################
    # REQUEST -> RESOURCE
    # Add user / group / device / markings to the data being requested
    #
    #
    #
    ###############################################################################

    def add_resource_user(self, users):
        userids = []
        for each_user in users:
            userids.append(each_user["id"])

        attribute = {"id": "created-user-id", "value": userids}
        self.request_resource["attributes"].append(attribute)

    def add_resource_groups(self, groups):
        groupids = []
        for each_group in groups:
            groupids.append(each_group["id"])

        attribute = {"id": "created-group", "value": groupids}
        self.request_resource["attributes"].append(attribute)

    def add_resource_device(self, devices):
        deviceids = []
        for each_device in devices:
            deviceids.append(each_device["sDeviceId"])
        attribute = {"id": "created-device-id", "value": deviceids}
        self.request_resource["attributes"].append(attribute)

    def add_marking(self, marking_name, marking_values):
        attribute = {"id": marking_name, "value": marking_values}
        self.request_resource["attributes"].append(attribute)

    ###############################################################################
    # REQUEST -> ACTION
    # Add action type to simulator
    #
    #
    #
    ###############################################################################
    def add_request(self, type="get"):
        attribute = {"id": "action-id", "value": [type]}
        self.request_action["attributes"].append(attribute)

    ###############################################################################
    # Subject Attributes
    #
    #
    #
    #
    ###############################################################################

    def add_attributes(self, id, value, issuer="ionic-simulation", datatype="string"):
        attribute = {"id": id, "issuer": issuer, "dataType": datatype, "value": [value]}
        self.request_subject["attributes"].append(attribute)


class SimulatorResults:
    def __init__(self, result=None):
        self.result = result
        self.decision = None
        if result:
            self.refresh()

    def refresh(self):
        self.decision = self.result["response"]


if __name__ == "__main__":
    # Location True
    # mycat = LocationCondition(["USA", "UK", "AND"], isnot=False)

    # Location False
    # mycat = LocationCondition(["USA", "UK", "AND"], isnot=True)

    # User Match True
    # mycat = UserCondition("match", userids=["12345", "67890"], isnot=False)

    # User Match False
    # mycat = UserCondition("match", userids=["12345", "67890"], isnot=True)

    # User Creator True
    # mycat = UserCondition("creator", isnot=False)

    # User Creator False
    # mycat = UserCondition("creator", isnot=True)

    # User Group Match True
    # mycat = UserGroupCondition("match", groupids=["T1", "T2"], isnot=False, any_or_all="all")

    # User Group Match False
    # mycat = UserGroupCondition("match", groupids=["T1", "T2"], isnot=True)

    # User Group Creator True
    # mycat = UserGroupCondition("creator", isnot=False)

    # User Group Creator False
    # mycat = UserGroupCondition("creator", isnot=True)

    # Relative Date 123 day
    # mycat = RelativeDateCondition("days", 123)

    # Specific Date After
    # mycat = SpecificDateCondition("12345", before_or_after="after")

    # Specific Date Before
    # mycat = SpecificDateCondition(datetime.now(), before_or_after="after")

    # Device is device id
    # mycat = DeviceCondition(device_ids=["D6Sn.A.0d59d9f0-b27d-41f4-a09b-32687a24b383"], isnot=False)

    # Device is not device id
    # mycat = DeviceCondition(device_ids=["D6Sn.A.0d59d9f0-b27d-41f4-a09b-32687a24b383"], isnot=True)

    # IP address is Ionic IP - 38.140.48.58
    # mycat = IPAddressCondition(ips=["38.140.48.58"])

    # IP address is not Ionic IP - 38.140.48.58
    # mycat = IPAddressCondition(ips=["38.140.48.58"], isnot=True)

    # mycat = TargetCondition(marking_id="classification", marking_values=["red"])
    # mycat.build_condition()
    import json

    dpt = DataPolicyTarget()
    # classification_m = MarkedDataCondition(marking_name="classification", marking_values=["red", "blue"])
    # classification_m.build_condition()
    #
    paz_m = MarkedDataCondition(
        rule_type="marking_values",
        marking_names=["classification", "paz"],
        marking_values=["red"],
        isnot=False,
        any_or_all="all",
    )
    paz_m.build_condition()
    #
    # dpt.target_conditions.append(classification_m.target_condition)
    # dpt.target_conditions.append(paz_m.target_condition)
    # unmarked = UnMarkedDataCondition()
    # unmarked.build_condition()
    # unmarked1 = UnMarkedDataCondition(marking_name="paz")
    # unmarked1.build_condition()
    # dpt.target_conditions.append(unmarked.target_condition)
    dpt.target_conditions.append(paz_m.target_condition)

    dpt.build_target()

    print(json.dumps(dpt.target, sort_keys=True, separators=(",", ": "), indent=4))
    quit()

    new_rule = DataPolicyRule(effect="Permit", desc="Test123")
    mycat = UserGroupCondition("creator", isnot=False)
    mycat.build_condition()
    mycat2 = UserCondition(rule_type="match", userids=["12345", "67890"], isnot=True)
    mycat2.build_condition()
    new_rule.conditions.append(mycat.rule_condition)
    new_rule.conditions.append(mycat2.rule_condition)

    new_rule.build_rule()
    # print(json.dumps(new_rule.rule, sort_keys=True, separators=(',', ': '), indent=4))

    new_rule = DataPolicyRule(effect="Permit", desc="Test123")
    loc = LocationCondition(countries=["USA", "ARE"], isnot=True)
    loc.build_condition()
    new_rule.conditions.append(loc.rule_condition)
    new_rule.build_rule()
    # print(json.dumps(new_rule.rule, sort_keys=True, separators=(',', ': '), indent=4))
