from pydashboard.pydashboard.base import Base


class CSADownloadReviews(Base):
    """
    Perform operations on CSA Download Reviews
    """

    DEFAULT_LIMIT = 20

    def __init__(self, apiuser, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param refresh_on_init: <boolean> Whether to refresh tenants upon initialization
        :return:
        """
        self.apiuser = apiuser

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.reviews = []
        self.review_by_id = {}

        if refresh_on_init:
            self.refresh()

    def get_baseurl(self):
        return "%s/products/reviews" % self.resource_url

    def refresh(self):
        self.reviews_full = self.get_reviews()
        self.reviews = self.reviews_full.get("Resources")
        self.review__by_id = self.get_reviews_by_id()

    def request_get_reviews(self, params={"asc": True, "limit": 20, "skip": 0}):
        """
        Retrieve Download Review Information
        :return: <requests> response from GET
        """
        url = "%s/list" % self.get_baseurl()
        return self.session.post(url, data=params, should_wait=False)

    def get_reviews(self):
        """
        Retrieve Download Reviews
        :return: <dict> reviews if successful otherwise empty
        """
        response = self.request_get_reviews()
        return self.get_json_response(response=response)

    def get_allow(self):
        """
        Retrieve Download Reviews with allow decision
        :return: <dict> reviews if successful otherwise empty
        """
        response = self.request_get_reviews(params={"asc": True, "decision": "allow", "limit": 20, "skip": 0})
        return self.get_json_response(response=response)

    def get_deny(self):
        """
        Retrieve Download Reviews with deny decision
        :return: <dict> reviews if successful otherwise empty
        """
        response = self.request_get_reviews(params={"asc": True, "decision": "deny", "limit": 20, "skip": 0})
        return self.get_json_response(response=response)

    def get_reviews_by_id(self):
        """
        Retrieve all Download Reviews configured for the CSA by downloadReviewsID
        :return: <dict> all Download Reviews with id as the KEY if successful otherwise empty
        """
        download_review_id = {}
        for each_review in self.reviews:
            download_review_id[each_review["id"]] = each_review
        return download_review_id

    def request_update_review(self, review):
        """
        Request to update a download review
        :param review: <object> of the review object
        :return: <requests> response from UPDATE
        """
        url = "%s/%s" % (self.get_baseurl(), review["id"])
        return self.session.put(url, data=review)

    def update_review(self, review):
        """
        Updates download review
        :param review: <object> review object to update
        :return: <dict> updated_download if successful otherwise empty
        """
        response = self.request_update_review(review=review)
        return self.get_json_response(response=response)

    def update_decision_review(self, review):
        """
        Updates download review decision to review
        :param review: <object> review object to update
        :return: <dict> updated_download if successful otherwise empty
        """
        review["decision"] = "review"
        return self.update_review(review)

    def update_decision_allow(self, review):
        """
        Updates download review decision to allow
        :param review: <object> review object to update
        :return: <dict> updated_download if successful otherwise empty
        """
        review["decision"] = "allow"
        return self.update_review(review)

    def update_decision_deny(self, review):
        """
        Updates download review decision to deny
        :param review: <object> review object to update
        :return: <dict> updated_download if successful otherwise empty
        """
        review["decision"] = "deny"
        return self.update_review(review)

    def request_get_history(self, params={"asc": True, "limit": 20, "skip": 0}):
        """
        Retrieve History Download Review Information
        Retrieve History Download Review Information
        :return: <requests> response from GET
        """
        url = "%s/history/list" % (self.get_baseurl())
        return self.session.post(url, data=params, should_wait=False)

    def get_history(self):
        """
        Retrieve History Download Reviews
        :return: hist if successful, otherwise empty
        """
        response = self.request_get_history()
        return self.get_json_response(response=response)
