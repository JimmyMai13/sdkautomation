from pydashboard.pydashboard.base import Base


class CSATenants(Base):
    """
    Perform operations on Tenants
    """

    DEFAULT_POST_PARAMS = {"limit": 100}

    def __init__(self, apiuser, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param refresh_on_init: <boolean> Whether to refresh tenants upon initialization
        :return:
        """
        self.apiuser = apiuser

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.tenants = []
        self.tenants_by_name = {}

        if refresh_on_init:
            self.refresh()

    def get_baseurl(self):
        return "%s/tenants" % self.resource_url

    def get_baseurl_history(self):
        return "%s/tenants/history" % self.resource_url

    def refresh(self):
        self.tenants_full = self.get_tenants()
        self.tenants = self.tenants_full.get("Resources")
        self.tenants_by_name = self.get_tenants_by_name()

    def request_get_tenants(self, params=None):
        """
        Retrieve Tenant Information
        :return: <requests> response from GET
        """
        url = self.get_baseurl() + "/list"
        params = self.get_params(params=params, desired_params=self.DEFAULT_POST_PARAMS)
        return self.session.post(url, data=params)

    def get_tenants(self, params=None):
        """
        Retrieve Tenants
        :return: <dict> tenants if successful otherwise empty
        """
        response = self.request_get_tenants(params=params)
        return self.get_json_response(response=response)

    def get_tenants_by_name(self):
        """
        Return dict of tenants with the tenant name as the key
        :return: <dict> tenants with tenant name as KEY if successful otherwise empty
        """
        tenants_by_name = {}
        for each_tenant in self.tenants:
            tenants_by_name[each_tenant["name"]] = each_tenant
        return tenants_by_name

    def request_create_tenant(self, name, description, status, next_version, region):
        """
        Create a tenant
        :param name: <string> name of the tenant
        :param description: <string> description of the tenant
        :param status: <string> The status of the tenant. Currently leave as 'active'
        :return: <requests> response from PUT
        """
        url = "%s" % self.get_baseurl()
        payload = {
            "name": name,
            "status": status,
            "_next_version": next_version,
            "region": {
                "name": region,
                "id": region
            },
        }
        if description:
            payload["description"] = description
        return self.session.post(url, data=payload)

    def create_tenant(
            self,
            name,
            description=None,
            status="active",
            next_version=1,
            region="ionic_global",
    ):
        """
        Create a Tenant
        :return: <dict> New Tenant if successful other empty
        """
        response = self.request_create_tenant(
            name=name,
            description=description,
            status=status,
            next_version=next_version,
            region=region,
        )
        return self.get_json_response(response=response)

    def request_create_provision_tenant(self, name, givenName, familyName, email, description, region, enrollment_host):
        """
        Create a tenant
        :param name: <string> name of the tenant
        :param description: <string> description of the tenant
        :param status: <string> The status of the tenant. Currently leave as 'active'
        :return: <requests> response from PUT
        """
        url = "%s/provision" % self.get_baseurl()
        payload = {
            "tenant": {
                "name": name,
                "region": {
                    "id": region
                }
            },
            "user": {
                "name": {
            "givenName": givenName,
            "familyName": familyName
                },
                "emails": [
                    {
                        "primary": True,
                        "value": email
                    }
                ],
                "schemas": [
                    "urn:ietf:params:scim:schemas:core:2.0:User"
                ]
            },
            "enrollmentServerConfig":"disablelisting = true\nexternalhosturl = \"{0}\"\nport = \"443\"\n[logging]\nlevel = \"info\"\n[tenant]\n[idc.default]\nlistname = \"Ionic API Enrollment\"\nnamefield = \"name\"\ndefault = true\nemailfield = \"email\"\nglobaldefault = false\n[saml.default]\nlistname = \"SAML Enrollment\"\nenable = true\nnamefield = \"name\"\ndefault = true\nupnfield = \"upn\"\ncompress = false\nidppubpemb64 = \"LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUVnakNDQTJvQ0NIeGRFWDZXMGlnQU1BMEdDU3FHU0liM0RRRUJDd1VBTUlHRE1Rc3dDUVlEVlFRR0V3SlYKVXpFUU1BNEdBMVVFQ0JNSFIyVnZjbWRwWVRFUU1BNEdBMVVFQnhNSFFYUnNZVzUwWVRFT01Bd0dBMVVFQ2hNRgpTVzl1YVdNeEVEQU9CZ05WQkFzVEIzQnliMlJ2Y0hNeEREQUtCZ05WQkFNVEEyOXdjekVnTUI0R0NTcUdTSWIzCkRRRUpBUllSY0hKdlpHOXdjMEJwYjI1cFl5NWpiMjB3SGhjTk1UVXdPREk0TWpBd016TTVXaGNOTWpVd09ESTEKTWpBd016TTVXakNCZ2pFTE1Ba0dBMVVFQmhNQ1ZWTXhFREFPQmdOVkJBZ01CMGRsYjNKbmFXRXhFREFPQmdOVgpCQWNNQjBGMGJHRnVkR0V4RGpBTUJnTlZCQW9NQlVsdmJtbGpNUlV3RXdZRFZRUUxEQXhVWlhOMElFUmxjR3h2CmVYTXhLREFtQmdOVkJBTU1IMlJsZG1WdVp5MXBaSEF1YVc0dWFXOXVhV056WldOMWNtbDBlUzVqYjIwd2dnSWkKTUEwR0NTcUdTSWIzRFFFQkFRVUFBNElDRHdBd2dnSUtBb0lDQVFDeEpxYmlLdEJFY2hhcHJnQnliNGsxRytPLworS2ZHbFJQaXp6K05NT1J3M05MYXBMWlplUDViWFRqRWhPSTRQTktRTk5Cc1poT3JlYVV0UlJKWGFvVnQ5TU13CkpwMG0xSHF5VVBqdlB6ejNHQlp4ZkhYZzgzN3ozaVZ2YkVkMWNDcDlMczhwQ0tBMmVTazY4QW9lSDFlSGVNbEMKOFloN0cwTXJqVy9VK1Q1OWFYSlAvMHVDY0FkeEVBUnBpNzV5ZG0yOFJOdzhOamxQWnlXOTh0S3p0ZGQzKzJzTAo4M0E5Y0FnRFZWT3hPMS9zVTU3Vkc1NFMrNThCdEczN3kxazh4THYyaGdhTTAya24rU3ppU3JMY0FSZ3VIcXNjCkF0ZmJuRnFFN0Jnd3NZTG1OT1p6ZTNLcEhjeWQ3UjcyQkRZUHNVMGpCSGE0Vy9TdnZ4aUh2SXNrTmtZbXJoK0IKMkdoaGllWlFLT2svS3FSeTVqeUJWNC9YclpnMUlmZTFnZXExcVNsV0lsK21KWVl3enp4bkU3S1liTzY0QXpTQgp5Vk5DZHVBcjJWUzlkNW8xUkdZZFF6eEQ5NTNBMmNFR28rNDdTN05TUTVvQWlxV2ZES05TQjZnVmxVNDdzQmRwCnkyR1JpT1NoWlRCczhIZGMrdkd2TERMOTVqLzNtS0xrVWY0K29RR2dUeGpncFZBR0xMcHdwVDk2VlgvOG5pWEQKcmgybUlRbW12RUdVZ3B1MGF6bk80V0JIR01qN0pidytEN3BQTm5HZ0FxTDVGT09kSkppNitPWGkwWkp0UWFNbwpEN0hMSXo2QnhvWDdNQnU2eGRueUhEKzhXN0NJei8vT01hTHhjMlBWUmNraXJsUTlQZUVwQVhyNWdXK3MzaCtECkRCV2JuZi9MdGdlNmU5bVBaUUlEQVFBQk1BMEdDU3FHU0liM0RRRUJDd1VBQTRJQkFRQXJVOEUvZlkyVDFjMzYKcXRodHlIZFRxQnRSTCtiL3NRZnJNdkppd1crZkNnVG1DTzlCZUZYeDBZZWM5UkVLU3pvUFJEeDNCNHA4VjFSRQo2S0FERTVEYjZpNi9kREZiNm9LS2xCNUw0MVgvT3RwNnBzdWhUUm5VeHZvT2lDV3R4eVczUXNNTUltejVBNm0rCkVtTTJOUDc1aWluanFDOXVlZDdNUjdUb1EzQk5yTGdOaDBIOFg1NUVYdDM3dVZmWFd2c2JGa1RXWHNZcmpNdVgKTGx3Z2NlOGwyUk5yRW5FaUFVd0pBVlNXSkRQWUVNaUY2aGxOV0ZLaWo0TWdvWDA5dmY1NEpPeEdMUkhOWVEvWgordUJ1WHFVQnh2bjA3YU5Hb2pmU3JoWjdCbXdnd0tqRzNGNEhRampRcllFTjRFSmZLaCtoMGlaZWg3QVQ0bnIxCi9qRnZxV0JGCi0tLS0tRU5EIENFUlRJRklDQVRFLS0tLS0K\"\nemailfield = \"email\"\nhttpredirect = false\nglobaldefault = true\nissuer = \"ionic\"\n[saml.default.tenant]\n[idc.default.tenant]".format(enrollment_host)
        }
        if description:
            payload["description"] = description
        return self.session.post(url, data=payload)

    def create_provision_tenant(
            self,
            name,
            givenName,
            familyName,
            email,
            description=None,
            region="ionic_global",
    ):
        """
        Create a Tenant
        :return: <dict> New Tenant if successful other empty
        """
        response = self.request_create_provision_tenant(
            name=name,
            description=description,
            givenName = givenName,
            familyName = familyName,
            email = email,
            region=region,
        )
        return self.get_json_response(response=response)


    def request_update_tenant(self, tenant):
        """
        Update a @tenant
        :param tenant: <dict> tenant to update
        :return: <requests> response from PUT
        """
        url = "%s/%s" % (self.get_baseurl(), tenant["id"])
        return self.session.put(url, data=tenant)

    def update_tenant(self, tenant):
        """
        Update a @tenant
        :param tenant: <dict> tenant to update
        : _next_version will be added if it doesn't exist in the tenant object
        :return: <dict> updated tenant if successful other empty
        """
        if "_next_version" not in tenant:
            tenant["_next_version"] = int(tenant["_version"]) + 1
        response = self.request_update_tenant(tenant=tenant)
        return self.get_json_response(response=response)

    def request_delete_tenant(self, tenant):
        """
        Delete tenant
        :param tenant: <dict> tenant to delete
        :return: <requests> response from DELETE
        """
        do_not_delete_prefix = ["55", "56"]
        url = "%s/%s" % (self.get_baseurl(), tenant["id"])
        tenant_id_prefix = tenant["id"][0:2]
        if tenant_id_prefix in do_not_delete_prefix:
            raise Exception("Deleting old tenants (tenants that start with %s) via this API is not supported!" %
                            do_not_delete_prefix)
        return self.session.delete(url)

    def delete_tenant(self, tenant):
        """
        Delete tenant
        :param tenant: <dict> tenant to delete
        :return: <boolean> True if deletion is successful other False
        """
        response = self.request_delete_tenant(tenant=tenant)
        return self.get_bool_response(response=response)

    def update_description(self, tenant, description):
        tenant["description"] = description
        return self.update_tenant(tenant=tenant)

    def request_get_tenants_history(self, params=None):
        """
        Retrieve Tenant Information
        :return: <requests> response from GET
        """
        url = self.get_baseurl_history() + "/list"
        params = self.get_params(params=params, desired_params=self.DEFAULT_POST_PARAMS)
        return self.session.post(url, data=params)
