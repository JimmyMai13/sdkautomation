from pydashboard.pydashboard.base import Base


class JSSDK(Base):
    def __init__(self, apiuser, tenantid):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        :return:
        """

        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

    def get_baseurl(self):
        return "{}/jssdk".format(self.resource_url)

    def request_get_jssdk_url_config(self):
        """
        Get jssdk url config
        :return: <request>
        """
        url = self.get_baseurl()
        return self.session.get(url)

    def get_jssdk_url_config(self):
        """
        Get jssdk url config
        :return: <response>
        """
        response = self.request_get_jssdk_url_config()
        return self.get_json_response(response=response)
