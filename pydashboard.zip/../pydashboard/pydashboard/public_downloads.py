from pydashboard.pydashboard.base import Base


class PublicDownloads(Base):
    """
    This class allows you to access the public downloads page unauthenticated
    When creating the apiuser object - only the resource_url needs to be populated
    """

    def __init__(self, apiuser, tenantid, refresh_on_init=True):

        self.apiuser = apiuser
        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url
        self.tenantid = tenantid
        self.downloads_full = {}
        self.downloads = []
        self.downloads_by_name = {}
        if refresh_on_init:
            self.refresh()

    def get_baseurl(self):
        url = ""
        if self.tenantid:
            url = "%s/%s/downloads" % (self.resource_url, self.tenantid)
        else:
            url = "%s/downloads" % (self.resource_url, )
        return url

    def refresh(self):
        self.downloads_full = self.get_downloads()
        self.downloads = self.downloads_full.get("Resources")
        self.downloads_by_name = self.get_public_downloads_by_name()

    def request_get_downloads(self):
        """
        Request to retrieve public downloads page
        :return: <requests> response from GET
        """
        url = self.get_baseurl()
        return self.session.get(url)

    def get_downloads(self):
        """
        Retrieve public downloads page
        :return: <dict> public downloads page if successful or empty
        """
        response = self.request_get_downloads()
        return self.get_json_response(response=response)

    def get_public_downloads_by_name(self):
        downloads = {}
        # ensure there are products to loop through
        if self.downloads:
            for each_download in self.downloads:
                downloads[each_download["name"]] = each_download
        return downloads

    def request_create_screen(self, firstname, lastname, country, street, email, sourceip=None):
        url = "%s/screen" % self.get_baseurl()
        payload = {
            "firstName": firstname,
            "lastName": lastname,
            "country": country,
            "streetAddress": street,
            # "sourceIp": "38.140.48.58", # by default dashboard does not send this
            "email": email,
        }
        if sourceip:
            payload["sourceIp"] = sourceip
        return self.session.post(url=url, data=payload)

    def create_screen(self, firstname, lastname, country, street, email, sourceip=None):
        response = self.request_create_screen(
            firstname=firstname,
            lastname=lastname,
            country=country,
            street=street,
            email=email,
            sourceip=sourceip,
        )
        return self.get_json_response(response=response)

    def request_download_product(self, product, screen, target_location):
        product_id = product.get("download").get("value").split("/")[-1]
        url = "%s/%s?token=%s" % (self.get_baseurl(), product_id, screen["token"])
        return self.session.download_file(url, target_location=target_location)

    def download_product(self, product, screen, target_location):
        return self.request_download_product(product=product, screen=screen, target_location=target_location)
