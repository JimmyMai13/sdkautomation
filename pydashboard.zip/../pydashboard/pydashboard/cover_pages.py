from pydashboard.pydashboard.base import Base


class CoverPages(Base):
    """
    Perform operations on Cover Pages
    """

    DEFAULT_LIMIT = 20

    def __init__(self, apiuser, tenantid, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        :param refresh_on_init: <boolean> Whether to refresh data policies upon initialization
        :return:
        """
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.DEFAULT_POST_PARAMS = {
            "asc": True,
            "limit": 100,
            "orderBy": "name",
            "skip": 0
        }
        self.DEFAULT_GET_PARAMS = ("asc=true&limit=0&orderBy=name&skip=0")

        self.cover_pages_full = {}
        self.cover_pages = []
        # self.cover_pages_by_name = {}

        if refresh_on_init:
            self.refresh()

    #########################
    #
    #   HELPER
    #
    #########################

    def refresh(self):
        self.cover_pages_full = self.get_all_cover_pages()
        self.cover_pages = self.cover_pages_full.get("Resources")
        # self.cover_pages_by_name = self.get_cover_pages_by_name()

    def set_tenantid(self, tenantid, method="POST"):
        self.tenantid = tenantid
        if method == "POST":
            self.DEFAULT_POST_PARAMS["tenantid"] = tenantid
        else:
            self.DEFAULT_GET_PARAMS = ("asc=true&limit=0&orderBy=name&skip=0&tenantId=%s" % tenantid)

    def get_baseurl(self):
        return "%s/%s/cover-pages" % (self.resource_url, self.tenantid)

    def get_tenant_baseurl(self):
        return "%s/tenant/%s/cover-pages" % (self.resource_url, self.tenantid)

    #########################
    #
    #   LIST
    #
    #########################

    def request_get_all_cover_pages(self, params=None, method="POST", tenantid=None):
        """
        Retrieve cover pages
        :param params optional params
        :param method <string> request type
        :return: <requests> response from POST or GET
        """
        if tenantid is not None:
            self.set_tenantid(tenantid=tenantid, method=method)
        if method == "POST":
            params = self.get_params(params=params, desired_params=self.DEFAULT_POST_PARAMS)
            url = "%s/list" % self.get_baseurl()
            return self.session.post(url, data=params)
        else:
            params = self.get_params(params=params, desired_params=self.DEFAULT_GET_PARAMS)
            url = self.get_baseurl()
            return self.session.get(url, params=params)

    def get_all_cover_pages(self, params=None, method="POST", tenantid=None):
        """
        Retrieve cover pages
        :param params optional params
        :param method <string> request type
        :return: <dict> cover pages if successful otherwise empty
        """
        response = self.request_get_all_cover_pages(params=params, method=method, tenantid=tenantid)
        return self.get_json_response(response=response)

    def request_get_cover_page(self, cover_page, tenantid=None, params=None):
        """
        Get cover page resource
        :param cover_page: cover page to get
        :param tenantid: <string> cover page tenant id
        :param params: optional params
        :return: <requests> response from GET
        """
        if tenantid is None:
            self.set_tenantid(tenantid=tenantid, method="GET")
        url = "%s/%s" % (self.get_baseurl(), cover_page["id"])
        return self.session.get(url, params=self.DEFAULT_GET_PARAMS)

    def get_cover_page(self, cover_page, tenantid=None, params=None):
        """
        Get cover page resource
        :param cover_page: cover page to get
        :param tenantid: <string> cover page tenant id
        :param params: optional params
        :return: <dict> cover page if successful otherwise empty
        """
        response = self.request_get_cover_page(cover_page=cover_page, tenantid=tenantid, params=params)
        return self.get_json_response(response=response)

    #########################
    #
    #   UPLOAD
    #
    #########################

    def request_upload_cover_page(
            self,
            file_path,
            method="POST",
            cover_page_id="default-csv",
            file_name=None,
            tenantid=None,
    ):
        """
        Upload a coverpage file
        :param params: optional params
        :param method: <string> request type
        :return: <requests> response from PUT or POST
        """
        if file_name is None:
            file_name = "test_file_name.txt"
        self.set_tenantid(tenantid=tenantid)
        url = "%s/%s/file" % (self.get_baseurl(), cover_page_id)
        if method == "POST":
            return self.session.post_with_file(url=url, data={}, file_path=file_path, file_name=file_name)
        else:
            return self.session.put_with_file(url=url, data={}, file_path=file_path, file_name=file_name)

    def upload_cover_page(
            self,
            method="POST",
            cover_page_id="default-csv",
            file_path=None,
            file_name=None,
            tenantid=None,
    ):
        """
        Upload a coverpage file
        :param params: optional params
        :param method: <string> request type
        :return: <dict> created cover if successful otherwise empty
        """
        response = self.request_upload_cover_page(
            method=method,
            cover_page_id=cover_page_id,
            file_path=file_path,
            file_name=file_name,
            tenantid=tenantid,
        )
        return self.get_json_response(response=response)

    #########################
    #
    #   DOWNLOAD
    #
    #########################

    def download_cover_page(self, cover_page, target_location, tenantid=None):
        """
        Download cover page
        :param cover_page: <dict> coverpage to download
        :param target_location: location to download file
        :param tenantid: <string> tenantid
        :return: <requests> response from GET
        """
        self.set_tenantid(tenantid=tenantid)
        url = "%s/%s/file" % (self.get_baseurl(), cover_page["id"])
        return self.session.download_file(url, target_location=target_location)

    #########################
    #
    #   DELETE
    #
    #########################

    def request_delete_cover_page(self, cover_page, tenantid):
        """
        Delete coverpage file
        :param cover_page: <dict> coverpage to delete
        :return: <requests> response from DELETE
        """
        self.tenantid = tenantid
        url = "%s/%s" % (self.get_baseurl(), cover_page["id"])
        return self.session.delete(url)

    def delete_cover_page(self, cover_page, tenantid):
        """
        Delete coverpage file
        :param cover_page: <dict> coverpage to delete
        :return: <bool> True if successful, otherwise false
        """
        response = self.request_delete_cover_page(cover_page=cover_page, tenantid=tenantid)
        return self.get_bool_response(response=response)
