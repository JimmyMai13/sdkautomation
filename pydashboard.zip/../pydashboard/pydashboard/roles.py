from pydashboard.pydashboard.base import Base


class Roles(Base):
    """
    Perform operations on Roles
    """

    SCHEMA_CORE = "urn:scim:schemas:core:1.0"
    SCHEMA_EXTENSION = "urn:scim:schemas:extension:ionic:1.0"
    DEFAULT_PARAMS = {"limit": 100, "skip": 0, "asc": True}

    SCIM_ACCESS = "scim_access"
    APPLICATION_MANAGER = "application_manager"
    TENANT_ADMIN = "tenant_admin"
    DASHBOARD_READ = "dashboard_read"
    POLICY_MANAGER = "policy_manager"
    USER_MANAGER = "user_manager"
    ROLE_MANAGER = "role_manager"
    USER = "user"
    CUSTOMER_SUPPORT_ADMIN = "customer_support_admin"

    VALID_ROLES = [
        SCIM_ACCESS,
        APPLICATION_MANAGER,
        TENANT_ADMIN,
        DASHBOARD_READ,
        POLICY_MANAGER,
        USER_MANAGER,
        ROLE_MANAGER,
        USER,
        CUSTOMER_SUPPORT_ADMIN,
    ]

    def __init__(self, apiuser, tenantid, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        :param refresh_on_init: <boolean> Whether to refresh roles upon initialization
        :return:
        """
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.roles_full = {}
        self.roles = []
        self.roles_by_name = {}
        self.scim_version = "1"

        if refresh_on_init:
            self.refresh()

    def refresh(self):
        self.roles = self.get_roles().get("Resources")
        self.roles_by_name = self.get_roles_by_name()

    def set_scim_version(self, version):
        if not isinstance(version, str):
            raise Exception("Version must be a string")
        else:
            self.scim_version = version

    def get_baseurl(self):
        return "%s/%s/scim/v%s/Roles" % (
            self.resource_url,
            self.tenantid,
            self.scim_version,
        )

    def request_get_roles(self, params=None, method="POST", search=False):
        """
        Retrieve Roles Information
        :return: <requests> response from request
        """
        if method == "POST":
            if search:
                url = "%s/.search" % self.get_baseurl()
            else:
                url = "%s/list" % self.get_baseurl()
            if params is None:
                params = self.DEFAULT_PARAMS
            return self.session.post(url, data=params)
        else:
            url = self.get_baseurl()
            return self.session.get(url, params=params)

    def get_roles(self, params=None, method="POST"):
        """
        Retrieve Roles Information
        :return: <dict> roles information if successful otherwise empty
        """
        response = self.request_get_roles(params=params, method=method)
        return self.get_json_response(response=response)

    def request_get_role(self, role):
        """
        Retrieve Role information
        param role <dict> Role
        :return: <requests> response from GET
        """
        url = "%s/%s" % (self.get_baseurl(), role["id"])
        return self.session.get(url)

    def get_role(self, role):
        """
        Retrieve Role information
        :param role: <dict> Role
        :return: <dict> role information if successful otherwise empty
        """
        response = self.request_get_role(role=role)
        return self.get_json_response(response=response)

    def get_roles_by_name(self):
        """
        Retrieve Roles Information with the name as the KEY
        :return: <dict> roles information with name as KEY if successful otherwise empty
        """
        roles_by_name = {}
        if not self.roles:
            try:
                self.roles = self.get_roles()["Resources"]
            except KeyError:
                print("CHECK PERMISSIONS")
                return roles_by_name
        for each_role in self.roles:
            roles_by_name[each_role["name"]] = each_role
        return roles_by_name

    def request_get_scopes(self):
        """
        Retrieve Scopes
        :return: <requests> response from GET
        """
        url = "%s/%s/scim/Scopes" % (self.resource_url, self.tenantid)
        return self.session.get(url)

    def get_scopes(self, role):
        """
        Retrieve Scopes
        :return: <dict> scopes if successful otherwise empty
        """
        response = self.request_get_scopes()
        return self.get_json_response(response=response)

    def request_assignable_roles(self, params=None):
        if params is None:
            params = {}
        params.get("tenantId", self.tenantid)
        url = "%s/assignable/list" % (self.get_baseurl())
        return self.session.post(url, data=params)

    def get_assignable_roles(self, params={"tenantId": None}):
        response = self.request_assignable_roles(params=params)
        return self.get_json_response(response=response)

    def request_create_role(self, name, roles=None, display_name=None, desc=None):
        """
        Send request to create user role
        :param name: user's name
        :param roles: list of scopes for the user role
        :param display_name: display name for the role
        :param desc: role description
        :return: response from POST request
        """
        url = "%s" % self.get_baseurl()
        payload = {"schemas": [self.SCHEMA_CORE, self.SCHEMA_EXTENSION], "name": name}
        if roles is not None:
            payload["scopes"] = roles
        if display_name is not None:
            payload["displayName"] = display_name
        if desc is not None:
            payload["description"] = desc
        return self.session.post(url, data=payload)

    def create_role(self, name, roles=None, display_name=None, desc=None):
        """
        Send request to create user role
        :param name: user's name
        :param roles: list of scopes for the user role
        :param display_name: display name for the role
        :param desc: role description
        :return: created role data if successful otherwise empty dict
        """
        response = self.request_create_role(name=name, roles=roles, display_name=display_name, desc=desc)
        return self.get_json_response(response=response)

    def request_update_role(self, role):
        """
        Update role
        :param role: <dict> role to update
        :return: <requests> response from PUT
        """
        url = "%s/%s" % (self.get_baseurl(), role["id"])
        return self.session.put(url=url, data=role)

    def update_role(self, role):
        """
        Update role
        :param role: <dict> role to update
        :return: <dict> updated role if successful other empty
        """
        response = self.request_update_role(role=role)
        return self.get_json_response(response=response)

    def request_delete_role(self, role):
        """
        Deletes a Role
        :param role: <dict> role to delete
        :return: <requests> response from DELETE
        """
        url = "%s/%s" % (self.get_baseurl(), role["id"])
        return self.session.delete(url=url)

    def delete_role(self, role):
        """
        Deletes a Role
        :param role: <dict> role to delete
        :return: <boolean> True if deletion successful other False
        """
        response = self.request_delete_role(role=role)
        return self.get_bool_response(response=response)

    def request_clone_role(self, name, role_copy, display_name=None, desc=None):
        """

        :param name: <string>
        :param role_copy: <dict> Role to clone
        :param display_name: <string>
        :param desc: <string>
        :param tenantid:
        :return: <dict>
        """

        url = "%s" % self.get_baseurl()
        payload = {"schemas": [self.SCHEMA_CORE, self.SCHEMA_EXTENSION], "name": name}
        if desc:
            payload["description"] = desc
        if display_name:
            payload["displayName"] = display_name
        payload["scopes"] = role_copy["scopes"]
        return self.session.post(url, data=payload)

    def clone_role(self, name, role_copy, display_name=None, desc=None):
        response = self.request_clone_role(name=name, display_name=display_name, desc=desc, role_copy=role_copy)
        return self.get_json_response(response=response)
