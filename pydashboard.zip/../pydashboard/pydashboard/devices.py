from pydashboard.pydashboard.base import Base


class Devices(Base):
    """
    Perform operations on Devices
    """

    DEFAULT_LIMIT = 0
    DEFAULT_PARAMS = {
        "asc": False,
        "limit": 100,
        "orderBy": "_createdTs",
        "skip": 0
    }
    SCIM2_PATCH = "urn:ietf:params:scim:api:messages:2.0:PatchOp"

    def __init__(self, apiuser, tenantid, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        :param refresh_on_init: <boolean> Whether to refresh data policies upon initialization
        :return:
        """
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.devices_full = {}
        self.devices = []
        self.devices_by_deviceid = {}
        self.scim_version = "1"

        if refresh_on_init:
            self.refresh()

    def set_scim_version(self, version):
        if not isinstance(version, str):
            raise Exception("Version must be a string")
        else:
            self.scim_version = version

    def get_baseurl(self):
        return "{resource_url}/{tenantid}/scim/v{scim_version}/Devices".format(
            resource_url=self.resource_url,
            tenantid=self.tenantid,
            scim_version=self.scim_version,
        )

    def get_device_requests_baseurl(self):
        return "{resource_url}/{tenantid}/device-requests".format(
            resource_url=self.resource_url, tenantid=self.tenantid)

    def get_key_requests_baseurl(self):
        return "{resource_url}/{tenantid}/key-requests".format(resource_url=self.resource_url, tenantid=self.tenantid)

    def get_configs_baseurl(self):
        return "{resource_url}/{tenantid}/config".format(resource_url=self.resource_url, tenantid=self.tenantid)

    def get_enrollment_baseurl(self):
        return "{resource_url}/{tenantid}/deviceenrollments".format(
            resource_url=self.resource_url, tenantid=self.tenantid)

    def refresh(self):
        self.devices_full = self.get_devices()
        self.devices = self.devices_full.get("Resources")
        self.devices_by_deviceid = self.get_devices_by_deviceid()

    def get_tenant_id(self, tenantid):
        """
        Each request takes a tenantid.
        If tenantid is not provided, the default tenantid used when authenticating the user will be used
        :param tenantid: <string> - id of the tenant
        :return: id of the tenant
        """
        tenant_id_to_use = self.tenantid
        if tenantid:
            tenant_id_to_use = tenantid
        return tenant_id_to_use

    def request_get_configs(self, params=None):
        url = self.get_configs_baseurl()
        params = self.get_params(params=params, desired_params=self.DEFAULT_PARAMS)
        return self.session.get(url)

    def request_get_devices(self, params=None, method="POST", search=False):
        """
        Retrieve a subset of the devices
        :params <dict> optional params
        :return: <requests> response from request
        """
        if method == "POST":
            if search:
                url = "%s/.search" % self.get_baseurl()
            else:
                url = "%s/list" % self.get_baseurl()
            params = self.get_params(params=params, desired_params=self.DEFAULT_PARAMS)
            return self.session.post(url, data=params)
        else:
            url = self.get_baseurl()
            return self.session.get(url, params=params)

    def get_devices(self, params=None, method="POST", search=False):
        """
        Retrieve a subset of the devices
        :param limit: <int> number of devices to return
        :param skip: <int> number of devices to skip
        :return: <dict> devices if successful otherwise empty
        """
        response = self.request_get_devices(params=params, method=method, search=search)
        return self.get_json_response(response=response)

    def request_get_device(self, device):
        """
        Retrieve device info
        :param device: <dict> device
        :return: <requests> response from GET
        """
        url = "%s/%s" % (self.get_baseurl(), device["id"])
        return self.session.get(url)

    def get_device(self, device):
        """
        Retrieve device info
        :param device: <dict> device
        :return: <dict> device info if successful otherwise empty
        """

    def request_get_device_by_version(self, device, version):
        """
        Retrieve device info by version
        :param device: <dict> device
        :param version: <string> version to retrieve
        :return: <requests> response from GET
        """
        url = "%s/%s?version=%s" % (self.get_baseurl(), device["id"], version)
        return self.session.get(url)

    def get_device_by_version(self, device, version):
        """
        Retrieve device info by version
        :param device: <dict> device
        :param version: <string> version to retrieve
        :return: <dict> device info at specified version if successful, otherwise empty
        """
        response = self.request_get_device_by_version(device=device, version=version)
        return self.get_json_response(response=response)

    def get_devices_by_deviceid(self, limit=0):
        """
        Retrieve a subset of the devices with deviceID as the KEY
        :param limit: <int> number of devices to return
        :param skip: <int> number of devices to skip
        :return: <dict> devices with device ID as KEY if successful otherwise empty
        """
        devices_by_id = {}
        count = 0
        for each_device in self.devices:
            if count < (limit + 1):
                devices_by_id[each_device["sDeviceId"]] = each_device
            else:
                break
        return devices_by_id

    def request_get_device_request_logs(self, params=None, path="device-requests"):
        """
        Retrieve device request logs
        : param params: optional params
        :return: <requests> response from POST
        """
        if path not in ["device-requests", "key-requests"]:
            raise Exception("Only acceptable args are: device-requests OR key-requests")
        if path == "key-requests":
            url = "{url}/list".format(url=self.get_key_requests_baseurl())
        else:
            url = "{url}/list".format(url=self.get_device_requests_baseurl())
        params = self.get_params(params=params, desired_params=self.DEFAULT_PARAMS)
        return self.session.post(url, data=params)

    def get_device_request_logs(self, params=None, path="device-requests"):
        """
        Retrieve device request logs
        :param params: optional params
        :return: <dict> device request log if successful otherwise empty
        """
        response = self.request_get_device_request_logs(params=params, path=path)
        return self.get_json_response(response=response)

    def request_get_device_by_log_id(self, id):
        """
        Retrieve device request log by id
        :param id: <string> log id
        :return: <requests> response from GET
        """
        url = "%s/%s" % (self.get_device_requests_baseurl(), id)
        return self.session.get(url)

    def get_device_by_log_id(self, id):
        """
        Retrieve device request by log id
        :param id: <string> log id
        :return: <dict> device request log if successful, otherwise empty
        """
        response = self.request_get_device_by_log_id(id=id)
        return self.get_json_response(response=response)

    def request_get_device_enrollments(self, params=None, method="POST", search=False):
        """
        Retrieve device enrollments
        :params <dict> optional params
        :return: <requests> response from request
        """
        if method == "POST":
            if search:
                url = "%s/.search" % self.get_enrollment_baseurl()
            else:
                url = "%s/list" % self.get_enrollment_baseurl()
            params = self.get_params(params=params, desired_params=self.DEFAULT_PARAMS)
            return self.session.post(url, data=params)
        else:
            url = self.get_enrollment_baseurl()
            return self.session.get(url, params=params)

    def get_device_enrollments(self, params=None, method="POST", search=False):
        """
         Retrieve device enrollments
         :params <dict> optional params
         :return: <dict> device enrollments if successful, otherwise empty
         """
        response = self.request_get_device_enrollments(params=params, method=method, search=search)
        return self.get_json_response(response=response)

    # def request_create_device(self, device):
    #     """
    #     THIS IS FOR TESTING ONLY.
    #     A DEVICE CANNOT BE CREATED THIS WAY
    #     Create a @device
    #     :param device: <dict> device to create
    #     :return: <requests> response from POST
    #     """
    #     url = "%s" % self.get_baseurl()
    #     return self.session.post(url, data=device)
    #
    # def create_device(self, device={}):
    #     """
    #     Create a @device
    #     :param device: <dict> device to update
    #     :return: <dict> updated device if successful other empty
    #     """
    #     response = self.request_create_device(device=device)
    #     return self.get_json_response(response=response)

    def request_update_device(self, device):
        """
        Update a @device
        :param device: <dict> device to update
        :return: <requests> response from PUT
        """
        url = "%s/%s" % (self.get_baseurl(), device["id"])
        return self.session.put(url, data=device)

    def update_device(self, device):
        """
        Update a @device
        :param device: <dict> device to update
        :return: <dict> updated device if successful other empty
        """
        response = self.request_update_device(device=device)
        return self.get_json_response(response=response)

    def request_update_device_patch(self, device, operations=[]):
        """
        Update Device via Patch
        :param device: <dict> device object to update
        :param operations: <list> operations for scim 2
        :return: <requests> response from patch
        """
        url = "%s/%s" % (self.get_baseurl(), device["id"])
        if self.scim_version == "2":
            payload = {"schemas": [self.SCIM2_PATCH]}
            payload["Operations"] = operations
            return self.session.patch(url=url, data=payload)
        else:
            raise Exception("SCIM 2 operation only. Set scim version to 2")

    def update_device_patch(self, device, operations=[]):
        """
        Update Device via Patch
        :param device: <dict> device object to udpate
        :param operations: <list> operations for scim 2
        :return: <boolean> True if success, otherwise False
        """
        response = self.request_update_device_patch(device=device, operations=operations)
        return self.get_bool_response(response=response)

    def request_delete_device(self, device):
        """
        Deletes the provided @device
        :param device: <dict> Represents the device to delete
        """
        url = "%s/%s" % (self.get_baseurl(), device["id"])
        return self.session.delete(url)

    def delete_device(self, device):
        """
        Deletes the provided @device
        :param device: <dict> Represents the device to delete
        :return <boolean>: True if successful delete otherwise False
        """
        response = self.request_delete_device(device=device)
        return self.get_bool_response(response=response)

    def request_delete_bulk_devices(self, devices=[]):
        """
        Bulk delete devices
        :param devices: <list> dict of devices to delete
        :return: response from POST
        """
        url = "%s/delete" % self.get_baseurl()
        deviceIds = []
        for each_device in devices:
            deviceIds.append(each_device["id"])
        payload = {"tenantId": self.tenantid, "ids": deviceIds}
        return self.session.post(url=url, data=payload)

    def delete_bulk_devices(self, devices=[]):
        """
        Bulk delete devices
        :param devices:
        :return:
        """
        response = self.request_delete_bulk_devices(devices=devices)
        return self.get_json_response(response=response)

    def enable_device(self, device):
        """
        Enable a device
        :param device: <dict> device to enable
        :return: <dict> updated device
        """
        device["status"] = True
        return self.update_device(device=device)

    def disable_device(self, device):
        """
        Disable a device
        :param device: <dist> device to disable
        :return: <dict> updated device
        """
        device["status"] = False
        return self.update_device(device=device)

    def update_device_name(self, device, name):
        """
        Update the @name of the @device
        :param device: <device> to update
        :param name: <string> new name to set the device to
        :return: <dict> updated device
        """
        device["name"] = name
        return self.update_device(device=device)

    #######################################################
    #
    #
    # Search Bar
    #
    #
    #######################################################

    SEARCH_TYPE = {
        "Name": "device.displayName",
        "User": "device.user.display",
        "OS": "q",
        "Application Policy Version": "q",
    }

    def request_search_bar(self, values, params=None):
        """
        values = [('SEARCH_TYPE', 'SEARCH_BY'), (), ()]
        :param values:
        :return:
        """
        url = "%s/list" % self.get_baseurl()
        params = self.get_params(params=params, desired_params=self.DEFAULT_PARAMS)
        for each_value in values:
            params[self.SEARCH_TYPE[each_value[0]]] = each_value[1]
        return self.session.post(url, data=params)

    def search_bar(self, values, params=None):
        params = self.get_params(params=params, desired_params=self.DEFAULT_PARAMS)
        response = self.request_search_bar(values=values, params=params)
        return self.get_json_response(response=response)
