from pydashboard.pydashboard.base import Base


class CSAAppkb(Base):
    """
    Perform operations on Appkb
    """

    DEFAULT_POST_PARAMS = {"limit": 100}

    def __init__(self, apiuser, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param refresh_on_init: <boolean> Whether to refresh tenants upon initialization
        :return:
        """
        self.apiuser = apiuser

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.appkb = []

        if refresh_on_init:
            self.refresh()

    def get_baseurl(self):
        return "%s/appkb" % self.resource_url

    def refresh(self):
        self.appkb = self.get_appkb()

    def request_get_appkb(self, params=None):
        """
        Retrieve Appkb Information
        :return: <requests> response from POST
        """
        url = self.get_baseurl() + "/list"
        params = self.get_params(params=params, desired_params=self.DEFAULT_POST_PARAMS)
        return self.session.post(url, data=params)

    def get_appkb(self, params=None):
        """
        Retrieve Tenants
        :return: <dict> appkb if successful otherwise empty
        """
        response = self.request_get_appkb(params=params)
        return self.get_json_response(response=response)

    def request_reload_appkb(self, params=None):
        """
        Reload appkb
        :return: <requests> response from POST
        """
        url = self.get_baseurl() + "/reload"
        params = self.get_params(params=params, desired_params=self.DEFAULT_GET_PARAMS)
        return self.session.post(url, data=params)

    def reload_appkb(self, params=None):
        """
        Reload appkb
        :return: <dict> appkb
        """
        response = self.request_reload_appkb(params=params)
        return self.get_json_response(response=response)
