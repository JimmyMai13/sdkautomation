from pydashboard.pydashboard.base import Base


class Keyspaces(Base):
    """
    Retrieve Keyspace Information
    """

    DEFAULT_POST_PARAMS = {"asc": True, "limit": 100, "skip": 0}

    def __init__(self, apiuser, tenantid, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        :param refresh_on_init: <boolean> Whether to refresh data policies upon initialization
        :return:
        """
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.keyspaces = []
        self.keyservers = []
        self.keyservers_by_keyspace = {}

        if refresh_on_init:
            self.refresh()

    def get_baseurl(self):
        return "{}/{}/keyspaces".format(self.resource_url, self.tenantid)

    def get_baseurl_keyservers(self):
        return "{}/keyservers/{}".format(self.resource_url, self.tenantid)

    def get_public_baseurl(self):
        return "{}/keyspaces".format(self.resource_url)

    def refresh(self):
        self.keyspaces = self.get_keyspaces()
        self.keyservers = self.get_keysevers()
        self.keyservers_by_keyspace = self.get_keyservers_by_keyspace()

    def request_get_keyspaces(self, params=None, method="POST", search=False):
        """
        Retrieve keyspaces info
        :param params: <dict> optional params
        :return: <requests> response from request
        """
        if method == "POST":
            if search:
                url = "{}/.search".format(self.get_baseurl())
            else:
                url = "{}/list".format(self.get_baseurl())
            params = self.get_params(params=params, desired_params=self.DEFAULT_POST_PARAMS)
            return self.session.post(url, data=params)
        else:
            url = "{}".format(self.get_baseurl())
            return self.session.get(url, params=params)

    def get_keyspaces(self, params=None, method="POST", search=False):
        """
        Retrieve keyspaces info
        :return: <dict> keyspaces or empty
        """
        response = self.request_get_keyspaces(params=params, method=method, search=search)
        return self.get_json_response(response=response)

    def request_get_public_keyspace(self, keyspace):
        """
        Get keyspace info
        :param keyspace: <dict> keyspace
        :return: <requests> response from GET
        """
        keyspace_id = keyspace
        url = "{}/{}/public".format(self.get_public_baseurl(), keyspace_id)
        return self.session.get(url)

    def get_public_keyspace(self, keyspace):
        """
        Get keyspace info
        :param keyspace: <dict> keyspace
        :return: <dict> keyspace info if successful otherwise empty
        """
        response = self.request_get_public_keyspace(keyspace=keyspace)
        return self.get_json_response(response=response)

    def request_get_keyspace(self, keyspace):
        """
        Get keyspace info
        :param keyspace: <dict> keyspace
        :return: <requests> response from GET
        """
        keyspace_id = keyspace["Resources"][0]["keyspace"]
        url = "{}/{}".format(self.get_baseurl(), keyspace_id)
        return self.session.get(url)

    def request_get_keyservers_by_id(self, keyspace_name, keyserver_id):
        """
        Get keyspace info
        :param keyspace: <dict> keyspace
        :return: <requests> response from GET
        """
        url = "{}/{}/keyservers/{}".format(self.get_baseurl(), keyspace_name, keyserver_id)
        return self.session.get(url)

    def request_get_keyservers_status(self, keyspace_name, keyserver_id):
        """
        Get keyspace info
        :param keyspace: <dict> keyspace
        :return: <requests> response from GET
        """
        url = "{}/{}/keyservers/{}/status".format(self.get_baseurl(), keyspace_name, keyserver_id)
        return self.session.get(url)
    
    def get_keyspace(self, keyspace):
        """
        Get keyspace info
        :param keyspace: <dict> keyspace
        :return: <dict> keyspace info if successful otherwise empty
        """
        response = self.request_get_keyspace(keyspace=keyspace)
        return self.get_json_response(response=response)

    def request_create_keyspace(self, tenantId, displayname, description, enrollmenturl):
        url = self.get_baseurl()
        payload = {
            "tenantId": tenantId,
            "description": description,
            "displayName": displayname,
            "enrollmentUrl": enrollmenturl,
        }
        return self.session.post(data=payload)

    def create_keyspace(self, tenantid, displayname, description, enrollmenturl):
        response = self.request_create_keyspace(
            tenantId=tenantid,
            displayname=displayname,
            description=description,
            enrollmenturl=enrollmenturl,
        )

        return self.get_json_response(response=response)

    def request_update_keyspace(self, keyspace, id_or_name="id"):
        """
        Update Keyspace
        :param keyspace: <dict> keyspace
        :return: <request> response from PUT
        """
        if id_or_name == "id":
            url = "{}/{}".format(self.get_baseurl(), keyspace["id"])
        else:
            url = "{}/{}".format(self.get_baseurl(), keyspace["keyspace"])
        return self.session.put(url=url, data=keyspace)

    def update_keyspace(self, keyspace, id_or_name="id"):
        """
        Update Keyspace
        :param keyspace: <dict> keyspace
        :return: <dict> keyspace updated if successful otherwise empty
        """
        response = self.request_update_keyspace(keyspace=keyspace, id_or_name=id_or_name)
        return self.get_json_response(response=response)

    def request_patch_keyserver_status(self, keyspace_name, keyserver_id, requested):
        """
        Patch Keyserver Status
        :param keyspace_name: <dict> keyspace name
        :param id: <dict> keyserver id
        :param managed: <dict> keyserver status
        :return: <dict> keyspace updated if successful otherwise empty
        """
        payload = {"state": {
            "requested": requested
        }}
        url = "{}/{}/keyservers/{}/status".format(self.get_baseurl(), keyspace_name, keyserver_id)
        return self.session.patch(url=url, data=payload)

    def request_get_keyservers(self):
        """
        Retrieve keyserver information
        :return:
        """
        url = self.get_baseurl_keyservers()
        return self.session.get(url)

    def get_keysevers(self):
        response = self.request_get_keyservers()
        return self.get_json_response(response=response)

    def get_keyservers_by_keyspace(self):
        my_keyservers_by_keyspace = {}
        keyspaces = self.keyservers[0].get("Keyspaces")
        for each_keyspace in keyspaces:
            keyspace_value = each_keyspace["Keyspace"]
            my_keyservers_by_keyspace[keyspace_value] = each_keyspace["Keyservers"]
        return my_keyservers_by_keyspace

    def request_create_keyserver(self, keyspace, params=None):
        """
        Create a keyserver in the specified keyspace
        :param keyspace: The keyspace to create the keyserver in
        :return: response from POST
        """
        url = self.get_baseurl() + "/{}/keyservers".format(keyspace)
        return self.session.post(url, data=params)

    def create_keyserver(self, keyspace, params=None):
        """
        Create a keyserver in the specified keyspace
        :param keyspace: The keyspace to create the keyserver in
        :return: <dict> keyserver created if successful otherwise empty
        """
        response = self.request_create_keyserver(keyspace=keyspace, params=params)
        return self.get_json_response(response=response)

    def request_delete_keyserver(self, keyspace, keyserverid):
        """
        Delete specified keyserver from keyspace
        :param keyspace: Keyspace to delete keyserver from
        :param keyserverid: Id of the keyserver to delete
        :return: response from DELETE
        """
        url = self.get_baseurl() + "/{}/keyservers/{}".format(keyspace, keyserverid)
        return self.session.delete(url)

    def delete_keyserver(self, keyspace, keyserverid):
        """
        Delete specified keyserver from keyspace
        :param keyspace: Keyspace to delete keyserver from
        :param keyserverid: Id of the keyserver to delete
        :return: <boolean> True if deletion successful other False
        """
        response = self.request_delete_keyserver(keyspace=keyspace, keyserverid=keyserverid)
        return self.get_bool_response(response=response)

    def request_get_keyspace_enrollment_configs(self, keyspace, params=None):
        """
        Get Keyspace Enrollment configurations
        :param keyspace: <dict> keyspace
        :return: <requests> response from POST
        """
        url = self.get_baseurl() + "/{}/enrollmentcfgs/list".format(keyspace["keyspace"])
        if not params:
            params = {
                "limit": 100,
                "skip": 0,
                "asc": True,
                "keyspaceId": "{}".format(keyspace["id"]),
            }
        else:
            params["keyspaceId"] = keyspace["id"]
            params["tenantId"] = self.tenantid
        return self.session.post(url, data=params)

    def get_keyspace_enrollment_configs(self, keyspace, params=None):
        """
        Get Keyspace Enrollment configurations
        :param keyspace: <string> keyspace
        :return: <dict> enrollment configs is successful, otherwise empty
        """
        response = self.request_get_keyspace_enrollment_configs(keyspace=keyspace, params=params)
        return self.get_json_response(response=response)

    def request_get_keyspace_enrollment_configs_with_get(self, keyspace):
        """
        Get Keyspace Enrollment configurations
        :param keyspace: <string> keyspace
        :return: <requests> response from GET
        """
        url = self.get_baseurl() + "/enrollmentcfgs"
        params = {
            "limit": 100,
            "skip": 0,
            "asc": True,
            "keyspaceId": "{}".format(keyspace),
        }
        return self.session.get(url, params=params)

    def get_keyspace_enrollment_configs_with_get(self, keyspace):
        """
        Get Keyspace Enrollment configurations
        :param keyspace: <string> keyspace
        :return: <dict> enrollment configs is successful, otherwise empty
        """
        response = self.request_get_keyspace_enrollment_configs_with_get(keyspace=keyspace)
        return self.get_json_response(response=response)

    def request_get_all_enrollment_configs(self, params=None, method="POST"):
        """
        Get Enrollment configurations for all Keyspaces
        :param params: optional params
        :param method: <str> request method
        :return: <requests> response from request
        """
        baseurl = "{baseurl}/enrollmentcfgs".format(baseurl=self.get_baseurl())
        if method == "POST":
            url = "{baseurl}/list".format(baseurl=baseurl)
            params = self.get_params(params=params, desired_params=self.DEFAULT_POST_PARAMS)
            return self.session.post(url=url, data=params)
        else:
            url = baseurl
            return self.session.get(url=url, params=params)

    def get_all_enrollment_configs(self, params=None, method="POST"):
        """
        Get Enrollment configurations for all Keyspaces
        :param params: optional params
        :param method: <str> request method
        :return: <dict> all enrollment configs if successful, otherwise empty
        """
        response = self.request_get_all_enrollment_configs(params=params, method=method)
        return self.get_json_response(response=response)

    def request_get_enrollment_config_details(self, enrollment_config):
        """
        Get Keyspace Enrollment configuration details
        :pram enrollment_config: <dict> enrollment configs
        :return: <requests> response from GET
        """
        enrollment_id = enrollment_config["id"].replace("|", "%7C")
        keyspace = enrollment_config["keyspace"]
        url = self.get_baseurl() + "/{}/enrollmentcfgs/{}".format(keyspace, enrollment_id)
        return self.session.get(url)

    def get_enrollment_config_details(self, enrollment_config):
        """
        Get Keyspace Enrollment configuration details
        :param enrollment_config: <dict> enrollment configs
        :param version: <dict> specific version of config if successful otherwise empty
        :return: 
        """
        response = self.request_get_enrollment_configs_by_version(enrollment_config=enrollment_config)
        return self.get_json_response(response=response)

    def request_get_enrollment_configs_by_version(self, enrollment_config, version=1):
        """
        Get Keyspace Enrollment configurations by version
        :pram enrollment_config: <dict> enrollment configs
        :return: <requests> response from GET
        """
        enrollment_id = enrollment_config["id"].replace("|", "%7C")
        keyspace = enrollment_config["keyspace"]
        url = self.get_baseurl() + "/{}/enrollmentcfgs/{}?version={}".format(keyspace, enrollment_id, version)
        return self.session.get(url)

    def get_enrollment_configs_by_version(self, enrollment_config, version=1):
        """
        Get Keyspace Enrollment configurations by version
        :param enrollment_config: <dict> enrollment configs
        :param version: <dict> specific version of config if successful otherwise empty
        :return: 
        """
        response = self.request_get_enrollment_configs_by_version(enrollment_config=enrollment_config, version=version)
        return self.get_json_response(response=response)

    def request_update_enrollment_configuration(self, enrollment_config):
        """
        Update Keyspace Enrollment configuration
        :param enrollment_config: <dict> enrollment configs
        :return: <requests> response from PUT
        """
        enrollment_id = enrollment_config["id"].replace("|", "%7C")
        keyspace = enrollment_config["keyspace"]
        url = self.get_baseurl() + "/{}/enrollmentcfgs/{}".format(keyspace, enrollment_id)
        return self.session.put(url, data=enrollment_config)

    def update_enrollment_configuration(self, enrollment_config):
        """
        Update Keyspace Enrollment configuration
        :param enrollment_config: <dict> enrollment configs
        :return: <dict> updated enrollment configs if successful, otherwise empty
        """
        response = self.request_update_enrollment_configuration(enrollment_config=enrollment_config)
        return self.get_json_response(response=response)

    def request_keyspaces_history_with_id(self, keyspace, method="POST", search=False, params=None):
        """
        Request get keyspace history by id
        :param keyspace: <dict> keyspace
        :param method:
        :param search:
        :param params:
        :return:
        """
        if method == "POST":
            if search:
                url = "{url}/{id}/history/.search".format(url=self.get_baseurl(), id=keyspace["id"])
            else:
                url = "{url}/{id}/history/list".format(url=self.get_baseurl(), id=keyspace["id"])
            params = {
                "limit": 20,
                "skip": 0,
                "orderBy": "_createdTs",
                "asc": False
            }
            return self.session.post(url=url, data=params)
        else:
            self.refresh()
            url = "{url}/{id}/history".format(url=self.get_baseurl(), id=keyspace["id"])
            return self.session.get(url=url, params=params)

    def keyspaces_history_with_id(self, keyspace, method="POST", search=False, params=None):
        """
        Get keyspace history by id
        :param keyspace: <dict> keyspace
        :param method:
        :param search:
        :param params:
        :return:
        """
        response = self.request_keyspaces_history_with_id(
            keyspace=keyspace, method=method, search=search, params=params)
        return self.get_json_response(response=response)
