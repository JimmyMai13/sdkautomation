from pydashboard.pydashboard.base import Base


class LoginConfigs(Base):
    """
    Login Configs as CSA in Settings Page
    """

    DEFAULT_PARAMS = {"asc": True, "limit": 100, "skip": 0}

    def __init__(self, apiuser, tenantid, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        """

        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        if refresh_on_init:
            self.refresh()

    def refresh(self):
        self.login_configs_full = self.get_login_configs()
        self.login_configs = self.login_configs_full.get("Resources")

    def get_baseurl(self):
        return "{resource_url}/{tenant_id}/login-configs".format(
            resource_url=self.resource_url, tenant_id=self.tenantid)

    def request_get_login_configs(self, params=None, method="POST", search=False):
        """
        Get login configs
        :param params:
        :param method:
        :param search:
        :return:
        """
        if method == "POST":
            if search:
                url = "{}/.search".format(self.get_baseurl())
            else:
                url = "{}/list".format(self.get_baseurl())
            params = self.get_params(params=params, desired_params=self.DEFAULT_PARAMS)
            return self.session.post(url=url, data=params)
        else:
            url = self.get_baseurl()
            return self.session.get(url=url, params=params)

    def get_login_configs(self, params=None, method="POST", search=False):
        """
        Retrieve login-configs
        :param params:
        :param method:
        :param search:
        :return:
        """
        response = self.request_get_login_configs(params=params, method=method, search=search)
        return self.get_json_response(response=response)

    def request_get_login_config(self, login_config, params=None):
        """
        Retrieve login-config
        :param login_config:
        :param params:
        :return:
        """
        url = "{url}/{id}".format(url=self.get_baseurl(), id=login_config["id"])
        return self.session.get(url, params=params)

    def get_login_config(self, login_config, params=None):
        """
        Retrieve login-config
        :param login_config:
        :param params:
        :return:
        """

        response = self.request_get_login_config(login_config=login_config, params=params)
        return self.get_json_response(response=response)

    def request_get_active_login_configs(self, method="POST", params=None):
        """
        get active login configs
        :param method:
        :param params:
        :return: <request>
        """
        base_url = "{resource_url}/{tenant_id}/auth/login-configs".format(
            resource_url=self.resource_url, tenant_id=self.tenantid)
        if method == "POST":
            params = self.get_params(params=params, desired_params=self.DEFAULT_PARAMS)
            url = "{}/list".format(base_url)
            return self.session.post(url, params)
        else:
            return self.session.get(base_url)

    def get_active_login_configs(self, method="POST", params=None):
        """
        Get active login configs
        :param method:
        :param params:
        :return:
        """
        response = self.request_get_active_login_configs(method=method, params=params)
        return self.get_json_response(response=response)

    def request_create_login_config(
            self,
            name,
            client_id,
            client_secret,
            option="google",
            server_auth_url="https://accounts.google.com/o/oauth2/v2/auth",
            server_token_url="https://accounts.google.com/o/oauth2/token",
            user_identity_url="https://accounts.google.com/o/oauth2/user",
            scopes=["profile", "email"],
            description=None,
            type1="oauth",
            type2="oauth",
            geo_blocking=False,
            user_attr_jit_map={
                "email": {
                    "toUserFields": [
                        "emails[]/value",
                        "urn:scim:schemas:extension:ionic:1.0/domainUpn",
                    ]
                },
                "email_verified": {
                    "toUserFields": ["emails[]/verified"]
                },
                "name": {
                    "toUserFields": ["name/formatted"]
                },
                "given_name": {
                    "toUserFields": ["name/givenName"]
                },
                "family_name": {
                    "toUserFields": ["name/familyName"]
                },
            },
            active=True,
            jitusergroupid=[],
            jituserroleid=[],
    ):
        """
        Request create login config
        :param name:
        :param client_id:
        :param client_secret:
        :param option:
        :param server_auth_url:
        :param server_token_url:
        :param user_identity_url:
        :param scopes:
        :param description:
        :param type1:
        :param type2:
        :param geo_blocking:
        :param user_attr_jit_map:
        :param active:
        :param jitusergroupid:
        :param jituserroleid:
        :return:
        """

        payload = {
            "name": name,
            "description": description,
            "type": type1,
            "geoBlocking": geo_blocking,
            "allowUserJIT": True,
            "disableUserUpdate": False,
            "jitUserGroupIDs": jitusergroupid,
            "jitUserRoleIDs": jituserroleid,
            "active": active,
            "button": {
                "option": option
            },
            type2: {
                "clientId": client_id,
                "clientSecret": client_secret,
                "serverAuthURL": server_auth_url,
                "serverTokenURL": server_token_url,
                "userIdentityURL": user_identity_url,
                "scopes": scopes,
            },
            "userAttrJITMap": user_attr_jit_map,
        }

        return self.session.post(url=self.get_baseurl(), data=payload)

    def create_login_config(
            self,
            name,
            client_id,
            client_secret,
            option="google",
            server_auth_url="https://accounts.google.com/o/oauth2/v2/auth",
            server_token_url="https://accounts.google.com/o/oauth2/token",
            user_identity_url="https://accounts.google.com/o/oauth2/user",
            scopes=["profile", "email"],
            description=None,
            type1="oauth",
            type2="oauth",
            geo_blocking=False,
            user_attr_jit_map={
                "email": {
                    "toUserFields": [
                        "emails[]/value",
                        "urn:scim:schemas:extension:ionic:1.0/domainUpn",
                    ]
                },
                "email_verified": {
                    "toUserFields": ["emails[]/verified"]
                },
                "name": {
                    "toUserFields": ["name/formatted"]
                },
                "given_name": {
                    "toUserFields": ["name/givenName"]
                },
                "family_name": {
                    "toUserFields": ["name/familyName"]
                },
            },
            active=True,
            jitusergroupid=[],
            jituserroleid=[],
    ):
        """
        Create login config
        :param name:
        :param client_id:
        :param client_secret:
        :param option:
        :param server_auth_url:
        :param server_token_url:
        :param user_identity_url:
        :param scopes:
        :param description:
        :param type1:
        :param type2:
        :param geo_blocking:
        :param user_attr_jit_map:
        :param active:
        :param jitusergroupid:
        :param jituserroleid:
        :return:
        """

        response = self.request_create_login_config(
            name=name,
            client_id=client_id,
            client_secret=client_secret,
            option=option,
            server_auth_url=server_auth_url,
            server_token_url=server_token_url,
            user_identity_url=user_identity_url,
            scopes=scopes,
            description=description,
            type1=type1,
            type2=type2,
            geo_blocking=geo_blocking,
            user_attr_jit_map=user_attr_jit_map,
            active=active,
            jitusergroupid=jitusergroupid,
            jituserroleid=jituserroleid,
        )

        return self.get_json_response(response=response)

    def request_update_login_config(self, login_config):
        """
        Request update login config
        :param login_config:
        :return: <request>
        """
        url = "{url}/{login_config_id}".format(url=self.get_baseurl(), login_config_id=login_config["id"])
        return self.session.put(url, data=login_config)

    def update_login_config(self, login_config):
        """
        update login config
        :param login_config:
        :return: <response>
        """
        response = self.request_update_login_config(login_config=login_config)
        return self.get_json_response(response=response)

    def request_delete_login_config(self, login_config):
        """
        request delete login config
        :param login_config:
        :return: <request>
        """
        url = "{url}/{login_config_id}".format(url=self.get_baseurl(), login_config_id=login_config["id"])
        return self.session.delete(url)

    def delete_login_config(self, login_config):
        """
        Delete login config
        :param login_config:
        :return: <response>
        """
        response = self.request_delete_login_config(login_config=login_config)
        return self.get_bool_response(response=response)

    def request_log_config_history_with_id(self, login_config_id, method="POST", search=False, params=None):
        """
        Get login config history by id
        :param login_config_id:
        :param method:
        :param search:
        :param params:
        :return: <request>
        """
        if method == "POST":
            if search:
                url = "{url}/{id}/history/.search".format(url=self.get_baseurl(), id=login_config_id)
            else:
                url = "{url}/{id}/history/list".format(url=self.get_baseurl(), id=login_config_id)
            params = {
                "limit": 20,
                "skip": 0,
                "orderBy": "_createdTs",
                "asc": False
            }
            return self.session.post(url=url, data=params)
        else:
            self.refresh()
            url = "{url}/{id}/history".format(url=self.get_baseurl(), id=login_config_id)
            return self.session.get(url=url, params=params)

    def log_config_history_with_id(self, login_config_id, method="POST", search=False, params=None):
        """
        Get login config history by id
        :param login_config_id:
        :param method:
        :param search:
        :param params:
        :return: <response>
        """
        response = self.request_log_config_history_with_id(
            login_config_id=login_config_id, method=method, search=search, params=params)
        return self.get_json_response(response=response)
