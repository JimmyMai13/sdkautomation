from pydashboard.pydashboard.base import Base


class DataMarkings(Base):
    """
    Perform operations on Data Markings for a specific tenant
    """

    DEFAULT_MARKINGS = ["classification", "ionic-detect", "ionic-info-type"]
    DEFAULT_LIMIT = 0
    DEFAULT_PARAMS = {"asc": True, "limit": 100, "skip": 0}

    def __init__(self, apiuser, tenantid, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        :param refresh_on_init: <boolean> Whether to refresh data markings upon initialization
        :return:
        """
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.markings_full = []
        self.markings = []
        self.markings_by_name = {}

        if refresh_on_init:
            self.refresh()

    def get_baseurl(self):
        return "%s/%s/markings" % (self.resource_url, self.tenantid)

    def get_baseurl_values(self, marking_detail):
        return "%s/%s/markings/%s/values" % (
            self.resource_url,
            self.tenantid,
            marking_detail["id"],
        )

    def refresh(self):
        self.markings_full = self.get_data_markings()
        self.markings = self.markings_full.get("Resources")
        self.markings_by_name = self.get_data_markings_by_name()

    def get_tenant_id(self, tenantid):
        """
        Each request takes a tenantid.
        If tenantid is not provided, the default tenantid used when authenticating the user will be used
        :param tenantid: <string> - id of the tenant
        :return: id of the tenant
        """
        tenant_id_to_use = self.tenantid
        if tenantid:
            tenant_id_to_use = tenantid
        return tenant_id_to_use

    ######################################################################
    #
    #
    # Operations on Data Markings
    #
    #
    ######################################################################

    def request_get_data_markings(self, params=None, method="POST", search=False):
        """
        Request to return all data markings
        :param params: optional params
        :param search: <string> indicate whether to use ./search in url for POST
        :return: <requests> response from request
        """
        if method == "POST":
            if search:
                url = "%s/.search" % self.get_baseurl()
            else:
                url = "%s/list" % self.get_baseurl()
            params = self.get_params(params=params, desired_params=self.DEFAULT_PARAMS)
            return self.session.post(url, should_wait=True, data=params)
        else:
            url = self.get_baseurl()
            return self.session.get(url, params=params)

    def get_data_markings(self, params=None, method="POST", search=False):
        """
        Retrieve all data markings
        :return: <dict> all data markings if successful or empty
        """
        response = self.request_get_data_markings(params=params, method=method, search=search)
        return self.get_json_response(response=response)

    def request_get_data_marking(self, marking, params=None):
        """
        Get data marking
        :param marking: <dict> data marking
        :return: <request> response from GET
        """
        url = "%s/%s" % (self.get_baseurl(), marking["id"])
        return self.session.get(url=url, params=params)

    def get_data_marking(self, marking, params=None):
        """
        Get data marking
        :param marking: <dict> data marking
        :return: <dict> data marking if successful otherwise empty
        """
        response = self.request_get_data_marking(marking=marking, params=params)
        return self.get_json_response(response=response)

    def get_data_markings_by_name(self):
        """
        Retrieve all data markings
        :return: <dict> all data markings with name as KEY if successful or empty
        """
        markings_by_name = {}
        for each_marking in self.markings:
            markings_by_name[each_marking["name"]] = each_marking
        return markings_by_name

    def request_create_data_marking(self, name, display=None, desc=None, tenantid=None):
        """
        Create a Data Marking
        :param name: <string> name of the Data Marking
        :param display: <string> display name of the Data Marking
        :param desc: <string> desc of the Data Marking
        :param tenantid: <string> tenant id
        :return: <requests> response from POST
        """
        url = "%s" % (self.get_baseurl())
        payload = {"name": name, "detail": {}}
        if display:
            payload["detail"]["display"] = display
        if desc:
            payload["detail"]["description"] = desc
        return self.session.post(url=url, data=payload)

    def create_data_marking(self, name, display=None, desc=None, tenantid=None):
        """
        Create a Data Marking
        :param name: <string> name of the Data Marking
        :param display: <string> display name of the Data Marking
        :param desc: <string> desc of the Data Marking
        :param tenantid: <string> tenant id
        :return: <dict> data_marking if successful otherwise empty
        """
        response = self.request_create_data_marking(name=name, display=display, desc=desc, tenantid=tenantid)
        return self.get_json_response(response=response)

    def request_update_data_marking(self, marking):
        """
        Update @marking
        :param marking: <dict> marking to update
        :return: <requests> response from PUT
        """
        url = "%s/%s" % (self.get_baseurl(), marking["id"])
        return self.session.put(url, data=marking)

    def update_data_marking(self, marking):
        """
        Update @marking
        :param marking: <dict> marking to update
        :return: <dict> updated marking if sucessful otherwise empty
        """
        response = self.request_update_data_marking(marking=marking)
        return self.get_json_response(response=response)

    def request_update_marking_value(self, marking_value):
        """
        Updates marking value
        :param marking: <dict> marking value to update
        :return: <requests> response from PUT
        """
        url = "%s/%s/values/%s" % (
            self.get_baseurl(),
            marking_value["markingId"],
            marking_value["id"],
        )
        return self.session.put(url, data=marking_value)

    def update_marking_value(self, marking_value):
        """
        Update marking value
        :param marking_value: <dict> marking value to update 
        :return: <dict> updated value if successful otherwise empty
        """
        response = self.request_update_marking_value(marking_value=marking_value)
        return self.get_json_response(response=response)

    def request_delete_data_marking(self, marking):
        """
        Delete @marking
        :param marking: <dict> @marking to delete
        :return: <requests> response from DELETE
        """
        url = "%s/%s" % (self.get_baseurl(), marking["id"])
        return self.session.delete(url)

    def delete_data_marking(self, marking):
        response = self.request_delete_data_marking(marking=marking)
        return self.get_bool_response(response=response)

    def request_delete_data_marking_value(self, marking_value):
        """
        Delete marking value
        :param marking_value: <dict> data marking value to delete
        :return: <requests> response from DELETE
        """
        url = "%s/%s/values/%s" % (
            self.get_baseurl(),
            marking_value["markingId"],
            marking_value["id"],
        )
        return self.session.delete(url)

    def delete_data_marking_value(self, marking_value):
        """
        Delete marking value
        :param marking_value: <dict> data marking value to delete 
        :return: <bool> True if successful otherwise False
        """
        response = self.request_delete_data_marking_value(marking_value=marking_value)
        return self.get_bool_response(response=response)

    ######################################################################
    #
    #
    # Operations on Data Markings Values
    #
    #
    ######################################################################

    def request_create_data_marking_value(self, marking_detail, name, desc=None):
        url = self.get_baseurl_values(marking_detail=marking_detail)
        payload = {"name": name}
        if desc:
            payload["description"] = desc
        return self.session.post(url, data=payload)

    def create_data_marking_value(self, marking_detail, name, desc=None):
        """
        Create a Data Marking Value
        :param marking: <dict> data marking to create the new value for
        :param name: <string> name of the Data Marking Value
        :param desc: <string> desc of the Data Marking Value
        """
        response = self.request_create_data_marking_value(marking_detail=marking_detail, name=name, desc=desc)
        return self.get_json_response(response=response)

    def request_get_data_marking_detail(self, marking):
        """
        Request to return all data marking values for @marking
        :param marking: <dict> marking to retrieve
        :return: <requests> response from GET
        """
        url = "%s/%s" % (self.get_baseurl(), marking["id"])
        return self.session.get(url)

    def get_data_marking_detail(self, marking):
        """
        Get Data Marking Values for @marking
        :param marking: <dict> marking to retrieve
        :return: <dict> all data markings if successful or empty
        """
        response = self.request_get_data_marking_detail(marking=marking)
        return self.get_json_response(response=response)

    def request_get_data_marking_values(self, marking, params=None, method="POST", search=False):
        """
        Get Data Marking values
        :param marking: <dict> marking to retrieve values for
        :param params: optional params
        :param method: <string> request method
        :param search: <boolean> indicate whether to use ./search in url for POST
        :return: <requests> response from request
        """
        if method == "POST":
            if search:
                url = "%s/.search" % self.get_baseurl_values(marking_detail=marking)
            else:
                url = "%s/list" % self.get_baseurl_values(marking_detail=marking)
            params = self.get_params(params=params, desired_params=self.DEFAULT_PARAMS)
            params["dataMarkingId"] = marking["id"]
            return self.session.post(url, data=params)
        else:
            url = self.get_baseurl_values(marking_detail=marking)
            return self.session.get(url, params=params)

    def get_data_marking_values(self, marking, params=None, method="POST"):
        """
        Get Data Marking values
        :param marking: <dict> marking to retrieve values for
        :return: <dict> values if successful otherwise empty
        """
        response = self.request_get_data_marking_values(marking=marking, params=params, method=method)
        return self.get_json_response(response=response)

    def get_marking_values(self, marking_detail):
        values = []
        if "values" in marking_detail["detail"]:
            values = marking_detail["detail"]["values"]
        return values

    def get_data_marking_values_by_name(self, marking_detail):
        """
        Retrieve all data markings values with the marking value name as the KEY
        :return: <dict> all data markings with name as KEY if successful or empty
        """
        marking_values_by_name = {}
        for each_marking_value in self.get_marking_values(marking_detail=marking_detail):
            marking_values_by_name[each_marking_value["name"]] = each_marking_value
        return marking_values_by_name

    def delete_data_marking_value_detail(self, marking_detail, marking_value):
        """
        Delete Data Marking Value
        Update to the existing data marking - remove the marking value from the marking object values list
        :param marking: <dict> @marking where the marking_value lives
        :param marking_value: <dict> marking_value to delete
        :return: <requests> response from DELETE
        """
        marking_detail["detail"]["values"].remove(marking_value)
        return self.update_data_marking(marking=marking_detail)

    def order_data_marking_values(self, data_marking, order=None):
        """
        Order values for data marking values
        :param data_marking: <dict> Data marking to re-order data marking values
        :param order: <list>
        e.g. current order of values: red, blue, green.
        order = [3, 2, 1]
        new order of values: green, blue, red

        :return: <dict> updated data marking
        """
        if order is None:
            order = []
        myList = data_marking["detail"]["values"]
        myList = [myList[i] for i in order]
        data_marking["detail"]["values"] = myList
        self.update_data_marking(marking=data_marking)
        return data_marking

    #######################################################
    #
    #
    # Search Bar
    #
    #
    #######################################################

    SEARCH_TYPE = {"Name": "name__contains", "Description": "description__contains"}

    def request_search_bar(self, values, params=None):
        """
        values = [('SEARCH_TYPE', 'SEARCH_BY'), (), ()]
        :param values:
        :return:
        """
        url = "%s/list" % self.get_baseurl()
        params = self.get_params(params=params, desired_params=self.DEFAULT_PARAMS)
        for each_value in values:
            params[self.SEARCH_TYPE[each_value[0]]] = each_value[1]
        return self.session.post(url, data=params)

    def search_bar(self, values, params=None):
        params = self.get_params(params=params, desired_params=self.DEFAULT_PARAMS)
        response = self.request_search_bar(values=values, params=params)
        return self.get_json_response(response=response)
