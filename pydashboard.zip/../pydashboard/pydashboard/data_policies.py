from pydashboard.pydashboard.base import Base


class DataPolicies(Base):
    """
    Perform operations on Data Policies
    """

    DEFAULT_LIMIT = 0
    RULE_ALGORITHMS = {
        "apply all rules": {
            "value": "deny-overrides"
        },
        "rules in order": {
            "value": "first-applicable"
        },
    }
    DEFAULT_ALGORITHM = RULE_ALGORITHMS["apply all rules"]
    DEFAULT_PARAMS = {
        "asc": True,
        "limit": 100,
        "orderBy": "policy_id",
        "skip": 0
    }

    def __init__(self, apiuser, tenantid, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        :param refresh_on_init: <boolean> Whether to refresh data policies upon initialization
        :return:
        """
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.policies_full = {}  # Full response from GET /policies
        self.policies = {}  # policies object from the FULL response
        self.policies_by_name = {}  # policies object with name as KEY

        if refresh_on_init:
            self.refresh()

    def get_baseurl_policies(self):
        return "%s/%s/policies" % (self.resource_url, self.tenantid)

    def get_baseurl_countries(self):
        return "%s/%s/countries" % (self.resource_url, self.tenantid)

    def refresh(self):
        """
        Refresh Data Policies
        :return: None
        """
        self.policies_full = self.get_data_policies()
        self.policies = self.policies_full["Resources"]
        self.policies_by_name = self.get_data_policies_by_name()

    #######################################################
    #
    #
    # Search Bar
    #
    #
    #######################################################

    SEARCH_TYPE = {
        "Name": "policyId__contains",
        "Summary": "description__contains",
        "Data Marking": "marking",
    }

    def request_search_bar(self, values, params=None):
        """
        values = [('SEARCH_TYPE', 'SEARCH_BY'), (), ()]
        :param values:
        :return:
        """
        url = "%s/list" % self.get_baseurl_policies()
        params = self.get_params(params=params, desired_params=self.DEFAULT_PARAMS)
        for each_value in values:
            params[self.SEARCH_TYPE[each_value[0]]] = each_value[1]
        return self.session.post(url, data=params)

    def search_bar(self, values, params=None):
        params = self.get_params(params=params, desired_params=self.DEFAULT_PARAMS)
        response = self.request_search_bar(values=values, params=params)
        return self.get_json_response(response=response)

    def request_get_data_policies(self, params=None, method="POST", search=False):
        """
        Request to return all data policies
        :return: <requests> response from POST
        """
        if method == "POST":
            if search:
                url = "%s/.search" % self.get_baseurl_policies()
            else:
                url = "%s/list" % self.get_baseurl_policies()
            params = self.get_params(params=params, desired_params=self.DEFAULT_PARAMS)
            return self.session.post(url, data=params)
        else:
            url = self.get_baseurl_policies()
            return self.session.get(url, params=params)

    def get_data_policies(self, params=None, method="POST", search=False):
        """
        Retrieve all Data Policies configured for the tenant
        :return: <dict> all data policies if successful otherwise empty
        """
        response = self.request_get_data_policies(params=params, method=method, search=False)
        return self.get_json_response(response=response)

    def request_get_data_policy(self, data_policy, params=None):
        """
        Retrieve Data Policy
        :param data_policy: <dict> data_policy
        :param params: <dict> option params
        :return: <requests> response from GET
        """
        url = "{baseurl}/{policy_id}".format(baseurl=self.get_baseurl_policies(), policy_id=data_policy["id"])
        return self.session.get(url, params=params)

    def get_data_policy(self, data_policy, params=None):
        """
        Retrieve Data Policy
        :param data_policy: <dict> data_policy
        :param params: <dict> option params
        :return: <dict> data policy if successful otherwise empty
        """
        response = self.request_get_data_policy(data_policy=data_policy, params=params)
        return self.get_json_response(response=response)

    def request_get_data_policy_version(self, data_policy, params=None):
        """
        Retreive Data Policy version
        :param data_policy: <dict> data policy
        :param params: <dict> option params
        :return: <requests> response from GET
        """
        url = "{baseurl}/{policy_id}".format(baseurl=self.get_baseurl_policies(), policy_id=data_policy["id"])
        return self.session.get(url, params=params)

    def get_data_policy_version(self, data_policy, params=None):
        """
        Retrieve Data Policy version
        :param data_policy: <dict> data policy
        :param params: <dict> option params
        :return: <dict> policy version if successful otherwise empty
        """
        response = self.request_get_data_policy(data_policy=data_policy, params=params)
        return self.get_json_response(response=response)

    def request_get_data_policy_permissions(self, data_policy, method="POST", search=False):
        """
        Get Data Permissions list
        :param data_policy: <dict> Data Policy
        :return: <requests> response from POST
        """
        if method == "POST":
            if search:
                url = "%s/%s/permissions/.search" % (
                    self.get_baseurl_policies(),
                    data_policy["id"],
                )
            else:
                url = "%s/%s/permissions/list" % (
                    self.get_baseurl_policies(),
                    data_policy["id"],
                )
            params = {
                "limit": 100,
                "skip": 0,
                "orderBy": "manager",
                "asc": True,
                "dataPolicyId": data_policy["id"],
            }
            return self.session.post(url, data=params)
        else:
            url = "%s/%s/permissions" % (self.get_baseurl_policies(), data_policy["id"])
            return self.session.get(url)

    def get_data_policy_permissions(self, data_policy, method="POST", search=False):
        """
        Get Data Permissions list
        :param data_policy: <dict> Data Policy
        :return: <dict> permissions list if successful otherwise empty
        """
        response = self.request_get_data_policy_permissions(data_policy=data_policy, method=method, search=search)
        return self.get_json_response(response=response)

    def request_get_data_policy_permissions_details(self, permissions):
        """
        Get detail management information for a data policy
        :param permissions: <dict> permissions
        :return: <requests> response from GET
        """
        url = "%s/%s/permissions/%s" % (
            self.get_baseurl_policies(),
            permissions["resource"]["id"],
            permissions["id"],
        )
        return self.session.get(url)

    def get_data_policy_permissions_details(self, permissions):
        """
        Get detail management information for a data policy
        :param permissions: <dict> permissions
        :return: <dict> permission details if successful otherwise empty
        """
        response = self.request_get_data_policy_permissions_details(permissions=permissions)
        return self.get_json_response(response=response)

    def get_data_policies_by_name(self):
        """
        Retrieve all Data Policies configured for the tenant by policyID
        :return: <dict> all data policies with policyID as the KEY if successful otherwise empty
        """
        dp_by_policy_id = {}
        if not self.policies:
            self.policies = self.get_data_policies()["Resources"]
        try:
            for each_policy in self.policies:
                dp_by_policy_id[each_policy["policyId"]] = each_policy
            return dp_by_policy_id
        except TypeError:
            return dp_by_policy_id

    def request_all_countries(self):
        """
        Request to return all countries
        :return: <requests> response from GET
        """
        url = "%s" % (self.get_baseurl_countries(), )
        return self.session.get(url)

    def get_all_countries(self):
        """
        Retrieve all countries
        :return: <dict> countries if successful otherwise empty
        """
        response = self.request_all_countries()
        return self.get_json_response(response=response)

    #########################################################
    #
    # Operations on Data Policy Detail Page
    #
    #########################################################
    def request_policy_detail(self, policy):
        """
        Request to return policy data for specific policy
        :param policy: <dict> of the policy object
        :return: <requests> response from GET
        """
        url = "%s/%s" % (self.get_baseurl_policies(), policy["id"])
        return self.session.get(url)

    def get_policy_detail(self, policy):
        """
        Request to retrieve policy data for specific policy
        :param policy: <dict> of the policy object
        :return: <dict> policy detail if successful or empty
        """
        response = self.request_policy_detail(policy=policy)
        return self.get_json_response(response=response)

    def make_json_obj(
            self,
            name,
            desc="",
            target={},
            enabled=False,
            tenantid=None,
            rule_algorithm=DEFAULT_ALGORITHM["value"],
    ):

        payload = {
            "policyId": name,
            "description": desc,
            "target": target,
            # "tenantId": self.get_tenant_id(tenantid=tenantid),
            "ruleCombiningAlgId": rule_algorithm,
        }
        if enabled:
            payload["enabled"] = enabled
        if target == {}:
            if desc == "":
                payload["description"] = "All data."
        return payload

    def request_bulk_data_policy(self, policies=[]):
        """
        Bulk Create/Update Data Policies
        :param policies: <list> of make_json_obj dicts
        :return: request for POST
        """
        url = "%s" % (self.get_baseurl_policies())
        return self.session.post(url, data=policies)

    def bulk_data_policy(self, policies=[]):
        """
        Bulk Create/Update Data Policies
        :param policies: <list> of make_json_obj dicts
        :return:
        """
        response = self.request_bulk_data_policy(policies=policies)
        return self.get_json_response(response=response)

    def request_create_data_policy(
            self,
            name,
            desc="",
            target={},
            enabled=False,
            tenantid=None,
            rule_algorithm=DEFAULT_ALGORITHM["value"],
    ):
        url = "%s" % (self.get_baseurl_policies())
        payload = self.make_json_obj(
            name=name,
            desc=desc,
            target=target,
            enabled=enabled,
            tenantid=tenantid,
            rule_algorithm=rule_algorithm,
        )
        if enabled:
            payload["enabled"] = enabled
        return self.session.post(url, data=payload)

    def create_data_policy(
            self,
            name,
            desc="",
            target={},
            enabled=False,
            tenantid=None,
            rule_algorithm=DEFAULT_ALGORITHM["value"],
    ):
        if target == {}:
            desc = ("All data.")  # To create an All Data Policy desc must be set to 'All data."
        response = self.request_create_data_policy(
            name=name,
            desc=desc,
            target=target,
            enabled=enabled,
            tenantid=tenantid,
            rule_algorithm=rule_algorithm,
        )
        return self.get_json_response(response=response)

    def request_create_data_policy_permissions(self, data_policy, user):
        """
        Create new manager of a data policy
        :param data_policy: <dict> Data Policy
        :param user: <dict> User
        :return: <requests> response from POST
        """
        url = "%s/%s/permissions" % (self.get_baseurl_policies(), data_policy["id"])
        payload = {"manager": {"id": user["id"], "type": "users"}, "scopes": []}
        return self.session.post(url, data=payload)

    def create_data_policy_permissions(self, data_policy, user):
        """
        Create new manager of a data policy
        :param data_policy: <dict> Data Policy
        :param user: <dict> User
        :return: <dict> permission details if successful otherwise empty
        """
        response = self.request_create_data_policy_permissions(data_policy=data_policy, user=user)
        return self.get_json_response(response=response)

    def request_update_data_policy(self, policy):
        """
        Request to update a data policy
        :param policy: <dict> of the policy object
        :return: <requests> response from UPDATE
        """
        url = "%s/%s" % (self.get_baseurl_policies(), policy["id"])
        resp = self.session.put(url, data=policy)
        return resp

    def update_data_policy(self, policy):
        """
        Updates policy
        :param policy: <dict> policy object to update
        :return: <dict> updated_policy if successful otherwise empty
        """
        response = self.request_update_data_policy(policy=policy)
        return self.get_json_response(response=response)

    def request_update_data_policy_permissions(self, permissions):
        """
        Update Data Policy Permissions
        :param permissions: <dict> permissions to update
        :return: <requests> response from PUT
        """
        url = "%s/%s/permissions/%s" % (
            self.get_baseurl_policies(),
            permissions["resource"]["id"],
            permissions["id"],
        )
        payload = permissions
        return self.session.put(url, data=payload)

    def update_data_policy_permissions(self, permissions):
        """
        Update Data Policy Permissions
        :param permissions: <dict> permissions to update 
        :return: <dict> updated permissions if successful otherwise empty
        """
        response = self.request_update_data_policy_permissions(permissions=permissions)
        return self.get_json_response(response=response)

    def request_delete_data_policy(self, policy):
        """
        Deletes policy
        :param policy: <dict> policy object to delete
        :return: <requests> response from DELETE
        """
        url = "%s/%s" % (self.get_baseurl_policies(), policy["id"])
        return self.session.delete(url)

    def delete_data_policy(self, policy):
        """
        Deletes policy
        :param policy: <dict> policy object to delete
        :return: <boolean> True if deletion successful, otherwise False
        """
        response = self.request_delete_data_policy(policy=policy)
        return self.get_bool_response(response=response)

    def request_delete_data_policy_permissions(self, permissions):
        """
        Delete Data Policy Permissions
        :param permissions: <dict> permissions to delete
        :return: <requests> response from DELETE
        """
        url = "%s/%s/permissions/%s" % (
            self.get_baseurl_policies(),
            permissions["resource"]["id"],
            permissions["id"],
        )
        return self.session.delete(url)

    def delete_data_policy_permissions(self, permissions):
        """
        Delete Data Policy Permissions
        :param permissions: <dict> permissions to delete
        :return: <bool> True if successful otherwise False
        """
        response = self.request_delete_data_policy_permissions(permissions=permissions)
        return self.get_bool_response(response=response)

    def request_import_data_policy(self, json, merge_type=False):
        """
        Imports Policy
        :param json: <dict> policy JSON to import
        :return: <requests> response from POST
        """
        url = "%s/%s" % (self.get_baseurl_policies(), "?merge=%s" % merge_type)
        return self.session.post(url, data=json)

    def import_data_policy(self, json, merge_type=False):
        """
        Imports Policy
        :param json: <dict> policy JSON to import
        :return: <boolean> T if success, otherwise F
        """
        response = self.request_import_data_policy(json=json, merge_type=merge_type)
        return self.get_json_response(response=response)

    def request_export_data_policy(self, policy=None):
        """
        Export a single Policy or all
        :param policy: <dict> policy to export
        :return: <requests> response from GET
        """
        if policy:
            url = "%s/%s/export" % (self.get_baseurl_policies(), policy["id"])
        else:
            url = "%s/export" % self.get_baseurl_policies()
        return self.session.get(url=url)

    def export_data_policy(self, policy=None):
        """
        Export a single Policy or all
        :param policy: <dict> policy to export
        :return: <boolean> T if success, otherwise F
        """
        response = self.request_export_data_policy(policy=policy)
        return self.get_json_response(response=response)

    #########################################################
    #
    # Operations on Data Policy Rules
    #
    #########################################################

    def get_data_policy_rules(self, policy):
        rules = []
        if "rules" in policy:
            rules = policy["rules"]
        return rules

    def get_data_policy_rules_by_desc(self, policy):
        rules_by_desc = {}
        for each_rule in policy["rules"]:
            rules_by_desc[each_rule["description"]] = each_rule
        return rules_by_desc

    def request_create_data_policy_rule(self, policy, effect, desc, condition=None):
        """
        Create Data Policy Rule
        :param policy: <dict> policy to create rules on
        :param effect: <string> 'Permit' or 'Deny'
        :param desc:  <string> description of the policy rule
        :param condition: <dict> conditions to which the rules applies to
        :return: <requests> response from PUT
        """
        new_rule = {"effect": effect, "description": desc}
        if condition:
            new_rule["condition"] = condition
        if policy["rules"] is None:
            policy["rules"] = []

        policy["rules"].append(new_rule)
        return self.request_update_data_policy(policy=policy)

    def create_data_policy_rule(self, policy, effect, desc, condition=None):
        """
        Create Data Policy Rule
        :param policy: <dict> policy to create the rules on
        :param effect: <string> 'Permit' or 'Deny'
        :param desc: <string> description of the policy rule
        :param condition: <dict> conditions to which the rule applies to
        :return: <dict> updated policy if successful otherwise empty
        """
        response = self.request_create_data_policy_rule(policy=policy, effect=effect, desc=desc, condition=condition)
        return self.get_json_response(response=response)

    def append_data_policy_rule(self, policy, rules):
        """
        Appends a Data Policy Rule
        :param policy: <dict> policy to append rules to
        :param rules: list of <dict> to append to the policy
        :return: <dict> updated policy if successful other empty
        """
        if policy["rules"] is None:
            policy["rules"] = []

        for each_rule in rules:
            policy["rules"].append(each_rule)
        return self.update_data_policy(policy=policy)

    def delete_data_policy_rule(self, policy, rule):
        """
        Deletes a data policy rule
        :param policy: <dict> policy which the rule belongs to
        :param rule: <dict> rule to delete
        :return: <dict> updated policy with the deleted rule
        """
        policy["rules"].remove(rule)
        return self.update_data_policy(policy=policy)

    def create_data_policy_always_allow_rule(self, policy):
        """
        Creates an Always Allow Rule for the @policy provided
        :param policy: <dict> policy to create the Always Allow Rule on
        :return: <dict> policy with the new rule
        """
        return self.create_data_policy_rule(policy=policy, effect="Permit", desc="Always allow.")

    def create_data_policy_always_deny_rule(self, policy):
        """
        Creates an Always Deny Rule for the @policy provided
        :param policy: <dict> policy to create the Always Deny Rule on
        :return: <dict> policy with the new rule
        """
        return self.create_data_policy_rule(policy=policy, effect="Deny", desc="Always deny.")

    #########################################################
    #
    # Operations on Data Policy Acceptable Use Obligations
    #
    #########################################################

    def offline_key_storage(self, policy, enable="true", days=0, hours=0, minutes=0):
        """
        Offline Key Storage enable/disable
        :param policy: <dict> policy to enable/disable offline key storage
        :param days: <int>
        :param hours: <int>
        :param minutess: <int>
        :param enable: <string> "true"/"false"
        :return: policy with offline key storage
        """

        if days:
            days = days*86400
        if hours:
            hours = hours*3600
        if minutes:
            minutes = minutes*60
        total_seconds = days + hours + minutes
        ionic_offline_key_storage_outer = [{
            "obligationId":
            "offline-key-storage",
            "appliesTo":
            "Permit",
            "attributes": [{
                "id": "ionic-offline-enabled",
                "attributeValue": {
                    "dataType": "string",
                    "value": enable
                },
            }],
        }]

        if enable == "true":
            ionic_offline_key_storage_inner = {
                "id": "ionic-offline-duration-seconds",
                "attributeValue": {
                    "value": total_seconds,
                    "dataType": "number"
                }
            }
            ionic_offline_key_storage_outer[0]["attributes"].append(ionic_offline_key_storage_inner)

        try:
            '''
             if policy has existing conditional protection or labeling we want to retain
             and add conditional protection
            '''
            policy["obligationExpressions"].append(ionic_offline_key_storage_outer[0])
        except KeyError:
            '''
            if no acceptable use obligation exists, we want to create this object
            '''
            policy["obligationExpressions"] = ionic_offline_key_storage_outer

        return self.update_data_policy(policy=policy)

    def conditional_protection_and_tracking(self, policy, content_protection="allow"):
        """
        Conditional Protection and Tracking allow/tracking/prefer/always
        :param policy: <dict> policy to set Conditional Protection and Tracking
        :param content_protection: <string> "allow/tracking/prefer/always"
        :return: policy with conditional protection and tracking
        """
        ionic_conditional_protection_outer = [{
            "obligationId":
            "conditional-protection",
            "appliesTo":
            "Permit",
            "attributes": [{
                "id": "ionic-content-encrypt",
                "attributeValue": {
                    "dataType": "string",
                    "value": content_protection,
                },
            }],
        }]

        try:
            '''
             if policy has existing offline keystorage or labeling we want to retain
             and add conditional protection
            '''
            policy["obligationExpressions"].append(ionic_conditional_protection_outer[0])
        except KeyError:
            '''
            if no acceptable use obligation exists, we want to create this object
            '''
            policy["obligationExpressions"] = ionic_conditional_protection_outer
        return self.update_data_policy(policy=policy)

    def labeling(self, policy, enable="true", attributes=None):
        """
        Labeling
        :param policy: <dict> policy to set acceptable use obligations
        :param enable: <string> "true"/"false"
        :param attributes: <dict>
        {"datamarking1": ["markingvalue1", "markingvalue2", .....],
        "datamarking2": ["markingvalue1", ....],
        "datamarking3": ["markingvalue1", "markingvalue2", "markingvalue3",
        ..................]
        }
        :return: policy with acceptable use obligations labeling configured
        """
        ionic_labeling_attributes_outer = [{
            "obligationId": "labeling",
            "appliesTo": "Permit",
            "attributes": [{
                "id": "ionic-labeling-enabled",
                "attributeValue": {
                    "dataType": "string",
                    "value": enable
                }
            }]
        }]

        if enable == "true":
            ionic_labeling_attributes_inner = {
                "id": "ionic-labeling-attributes",
                "attributeValue": {
                    "dataType": "string",
                    "value": []
                }
            }
            for each in attributes:
                ionic_labeling_attributes_inner["attributeValue"]["value"].append(dict(
                    {"id": each,
                     "value": attributes[each]}
                ))
            ionic_labeling_attributes_outer[0]["attributes"].append(ionic_labeling_attributes_inner)

        try:
            '''
             if policy has existing offline keystorage or conditional protection we want to retain
             and add labeling
            '''
            policy["obligationExpressions"].append(ionic_labeling_attributes_outer[0])
        except KeyError:
            '''
            if no acceptable use obligation exists, we want to create this object
            '''
            policy["obligationExpressions"] = ionic_labeling_attributes_outer

        return self.update_data_policy(policy=policy)


    #########################################################
    #
    # Helper Operations on Data Policies
    #
    #########################################################

    def enable_data_policy(self, policy):
        """
        Enable a Data Policy
        :param policy: <dict> policy to enable
        :return: <dict> policy with the new status
        """
        policy["enabled"] = True
        return self.update_data_policy(policy=policy)

    def disable_data_policy(self, policy):
        """
        Disable a Data Policy
        :param policy: <dict> policy to disable
        :return: <dict> policy with the new status
        """
        policy["enabled"] = False
        return self.update_data_policy(policy=policy)

    ########################################
    #
    #  Retrieve the policy version which a device would receive
    #  -
    #
    ########################################
    def request_version_in_effect(self, params=None):
        """
        :param params: dict optional parameters like 'cache:False'
        :return: object response from the request
        """
        url = self.get_baseurl_policies() + "/version"
        return self.session.get(url, params=params)

    def version_in_effect(self, params=None):
        """
        :return: <dict> Empty dict or the applications configured for the tenant
        """
        response = self.request_version_in_effect(params=params)
        return self.get_json_response(response=response)

    ########################################
    #
    #  Rollback to a previous data policy
    #  -
    #
    ########################################
    def request_rollback(self, policy_version):
        """
        :param params: policy version number
        :return: object response from the request
        """
        url = self.get_baseurl_policies()
        payload = {"version": policy_version}
        return self.session.patch(url, data=payload)

    def rollback(self, policy_version):
        """
        Rollback to previous Data Policy
        :param policy: policy version number
        :return: <dict> data policy that has been selected to rollback to
        """
        response = self.request_rollback(policy_version=policy_version)
        return self.get_json_response(response=response)

    def request_rollback_with_post(self, policy_version):
        """
        Rollback Policy version
        :param policy_version: <string> policy rollback version
        :return: <request> response from POST
        """
        url = "%s/rollback" % self.get_baseurl_policies()
        payload = {"version": policy_version}
        return self.session.post(url, data=payload)

    def rollback_with_post(self, policy_version):
        """
        Rollback Policy version
        :param policy_version: <string> policy rollback version
        :return: <dict> rollback data policy if successful otherwise empty
        """
        response = self.request_rollback_with_post(policy_version=policy_version)
        return self.get_json_response(response=response)

    def request_rollback_policy(self, policy, policy_version):
        """
        Rollback Policy
        :param policy: <dict> data policy
        :param policy_version: <string> rollback version
        :return: <requests> response from POST
        """
        url = "%s/%s/rollback" % (self.get_baseurl_policies(), policy["id"])
        payload = {"version": policy_version}
        return self.session.post(url, data=payload)

    def rollback_policy(self, policy, policy_version):
        """
        Rollback Policy
        :param policy: <dict> data policy
        :param policy_version: <string> rollback version
        :return: <dict> rollback data policy if successful otherwise empty
        """
        response = self.request_rollback_policy(policy=policy, policy_version=policy_version)
        return self.get_json_response(response=response)

    ########################################
    #
    #  Simulate a data policy
    #  -
    #
    ########################################
    def request_get_simulations(self, params=None):
        """
        Retrieve list of simulations
        :param params: optional params
        :return: response from POST request
        """
        if params is None:
            params = self.DEFAULT_PARAMS
        params.get("tenantId", self.tenantid)
        url = "%s/simulations/list" % self.get_baseurl_policies()
        return self.session.post(url, data=params)

    def get_simulations(self):
        """
        retrieve list of simulations
        :return:
        """
        response = self.request_get_simulations()
        return self.get_json_response(response=response)

    def get_simulations_by_name(self):
        """
        Create dict of simulations by name
        NOTE: 'name' is not a unique field. Therefore simulations with the same name will only appear once in the list
        :return: <dict> of simulations with 'name' as the key
        """
        simulations = {}
        for each_simulation in self.get_simulations()["Resources"]:
            simulations[each_simulation["name"]] = each_simulation
        return simulations

    def request_create_simulation(self, simulation_payload):
        """
        Create a simulation
        :param simulation_payload: <dict> use policy_simulator class to create this payload
        :return: <requests> response from creating simulation
        """
        url = "%s/simulations" % self.get_baseurl_policies()
        return self.session.post(url, data=simulation_payload)

    def create_simulation(self, simulation_payload):
        """
        Create a simulation
        :param simulation_payload: <dict> use policy_simulator class to create this payload
        :return: <dict> the result from the simulation
        """
        response = self.request_create_simulation(simulation_payload=simulation_payload)
        return self.get_json_response(response=response)

    def request_delete_simulation(self, simulation):
        """
        Deletes simulation
        :param simulation: <dict> simulation object to delete
        :return: <requests> response from DELETE
        """
        url = "%s/simulations/%s" % (self.get_baseurl_policies(), simulation["id"])
        return self.session.delete(url)

    def delete_simulation(self, simulation):
        """
        Deletes simulation
        :param simulation: <dict> simulation object to delete
        :return: <boolean> True if deletion successful, otherwise False
        """
        response = self.request_delete_simulation(simulation=simulation)
        return self.get_bool_response(response=response)

    ########################################
    #
    #  POST /policies/validate
    #  POLICY-6832
    #  -
    #
    ########################################

    def request_validate_policies(self, condition=None, rule=None, policy=None):
        """
        Validate Policies
        :param condition: <dict> condition object from json viewer tab in dashboard
        :param rule: <dict> rule object from api
        :param policy: <dict> policy object from api
        :return:
        """
        if not (condition or rule or policy):
            raise ValueError("Atleast one argument is required")
        url = "%s/validate" % (self.get_baseurl_policies())
        payload = {"condition": condition, "rule": rule, "policy": policy}
        return self.session.post(url, data=payload)

    def validate_policies(self, condition=None, rule=None, policy=None):
        """
       Validate Policies
       :param condition: <dict> condition object from json viewer tab in dashboard
       :param rule: <dict> rule object from api
       :param policy: <dict> policy object from api
       :return:
       """
        if not (condition or rule or policy):
            raise ValueError("Atleast one argument is required")
        response = self.request_validate_policies(condition=condition, rule=rule, policy=policy)
        return self.get_json_response(response=response)

    #######################################################
    #
    #
    # Policy Request Context APIs for Simulator
    # POLICY-7101
    #
    #######################################################

    def request_policy_context_for_user(self, user_id, resource=False):
        """

        :param user_id: <string>
        :param resource: <boolean>
        :return: <requests> response from GET
        """
        if resource:
            url = "{}/context/user/{}?category=resource".format(self.get_baseurl_policies(), user_id)
        else:
            url = "{}/context/user/{}".format(self.get_baseurl_policies(), user_id)
        return self.session.get(url)

    def policy_context_for_user(self, user_id, resource=False):
        """

        :param user_id: <string>
        :param resource: <boolean>
        :return: <dict> policy context if successful otherwise empty
        """
        response = self.request_policy_context_for_user(user_id=user_id, resource=resource)
        return self.get_json_response(response=response)

    def request_policy_context_for_device(self, device_id, resource=False):
        """

        :param device_id: <string>
        :param resource: <boolean>
        :return: <requests> response from GET
        """
        if resource:
            url = "{}/context/device/{}?category=resource".format(self.get_baseurl_policies(), device_id)
        else:
            url = "{}/context/device/{}".format(self.get_baseurl_policies(), device_id)
        return self.session.get(url)

    def policy_context_for_device(self, device_id, resource=False):
        """

        :param device_id: <string>
        :param resource: <boolean>
        :return: <dict> policy context if successful otherwise empty
        """
        response = self.request_policy_context_for_device(device_id=device_id, resource=resource)
        return self.get_json_response(response=response)

    def request_policy_context_for_ipaddress(self, ipaddress, resource=False):
        """

        :param ipaddress: <string>
        :param resource: <boolean>
        :return: <requests> response from GET
        """
        if resource:
            url = "{}/context/ip/{}?category=resource".format(self.get_baseurl_policies(), ipaddress)
        else:
            url = "{}/context/ip/{}".format(self.get_baseurl_policies(), ipaddress)
        return self.session.get(url)

    def policy_context_for_upaddress(self, ipaddress, resource=False):
        """

        :param ipaddress: <string>
        :param resource: <boolean>
        :return: <dict> policy context if successful otherwise empty
        """
        response = self.request_policy_context_for_ip(ipaddress=ipaddress, resource=resource)
        return self.get_json_response(response=response)
