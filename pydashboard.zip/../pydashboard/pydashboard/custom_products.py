from pydashboard.pydashboard.base import Base


class CustomProducts(Base):
    """
    Perform operations on Custom Products API
    """

    def __init__(self, apiuser, tenantid, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        :param refresh_on_init: <boolean> Whether to refresh data policies upon initialization
        :return:
        """
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.DEFAULT_GET_PARAMS = ("asc=true&limit=0&orderBy=name&skip=0&tenantId=%s" % self.tenantid)
        self.DEFAULT_POST_PARAMS = {
            "asc": True,
            "limit": 100,
            "orderBy": "last_name",
            "skip": 0
        }

        if refresh_on_init:
            self.refresh()

    #########################
    #
    #   HELPER
    #
    #########################

    def refresh(self):
        self.custom_products_full = self.get_all_custom_products()
        self.custom_products = self.custom_products_full.get("Resources")

    def get_baseurl(self):
        """
        get base URL for Custom Products
        :return:
        """
        return "{resource_url}/{tenantid}/custom-products".format(
            resource_url=self.resource_url, tenantid=self.tenantid)

    def get_keyspace(self):
        """
        Retrieve keyspaces info
        :param params: <dict> optional params
        :return: <requests> response from request
        """
        return self.session.get("{resource_url}/{tenantid}/keyspaces".format(
            resource_url=self.resource_url, tenantid=self.tenantid))

    def set_tenantid(self, tenantid, method="POST"):
        self.tenantid = tenantid
        if method == "POST":
            self.DEFAULT_POST_PARAMS["tenantid"] = tenantid
        else:
            self.DEFAULT_GET_PARAMS = ("asc=true&limit=0&orderBy=name&skip=0&tenantId=%s" % tenantid)

    #########################
    #
    #   GET/LIST
    #
    #########################

    def request_get_all_custom_products(self, tenantid=None, params=None, method="POST"):
        """
        Retrieve all custom products
        :param method: method by which to get custom products
        :param params: optional parameters
        :return: <requests> response from POST or GET
        """
        if tenantid is not None:
            self.set_tenantid(tenantid=tenantid)
        if params is None:
            params = {"limit": 20, "skip": 0, "asc": True}
        if method == "POST":
            url = "{baseurl}/list".format(baseurl=self.get_baseurl())
            return self.session.post(url, data=params)
        else:
            url = self.get_baseurl()
            return self.session.get(url, params=params)

    def get_all_custom_products(self, params=None):
        """
        Retrieve all custom products
        :param params optional params
        :param method <string> request type
        :return: <dict> custom products if successful otherwise empty
        """
        response = self.request_get_all_custom_products(params=params)
        return self.get_json_response(response=response)

    def request_get_custom_product_by_id(self, customProductId):
        """
        Get custom product resource
        :param customProductId: unique custom product to get
        :return: <requests> response from GET
        """
        url = "{baseurl}/{customProductId}".format(baseurl=self.get_baseurl(), customProductId=customProductId)
        return self.session.get(url)

    def get_custom_product_by_id(self, customProductId):
        """
        Get custom product resource
        :param customProductId: unique custom product ID
        :return: <dict> custom product if successful otherwise empty
        """
        response = self.request_get_custom_product_by_id(customProductId=customProductId)
        return self.get_json_response(response=response)

    def request_get_custom_product_history_by_id(self, product, method="POST"):
        """
        Get custom product history resource
        :param customProductId: unique custom product ID to get
        :param method: request method to use
        :return: <requests> response from GET
        """
        params = {"limit": 20, "skip": 0, "asc": True}
        if method == "POST":
            url = "{baseurl}/{id}/history/list".format(baseurl=self.get_baseurl(), id=product["id"])
            return self.session.post(url, data=params)
        else:
            url = self.get_baseurl()
            return self.session.get(url)

    def get_custom_product_history_by_id(self, customProductId, method="POST"):
        """
        Get custom product history resource
        :param customProductId: unique custom product ID by which to fetch history
        :param method: request method to use
        :return: <dict> custom product history if successful otherwise empty
        """
        response = self.request_get_custom_product_history_by_id(method=method, customProductId=customProductId)
        return self.get_json_response(response=response)

    def request_get_custom_product_activity_logs(self, method="POST", params=None):
        """
        Get custom product history resource
        :param customProductId: unique custom product ID to get
        :param params: optional parameters
        :return: <requests> response from GET
        """
        if method == "POST":
            if params is None:
                params = self.DEFAULT_POST_PARAMS
            url = "{baseurl}/history/list".format(baseurl=self.get_baseurl())
            return self.session.post(url, data=params)
        else:
            if params is None:
                params = self.DEFAULT_GET_PARAMS
            url = "{baseurl}/history".format(baseurl=self.get_baseurl())
            return self.session.get(url, params=params)

    def get_custom_product_activity_logs(self, method="POST", params=None):
        """
        Get custom product activity logs
        :param method: request method to use
        :param params: optional parameters
        :return: <requests> response from GET
        """
        response = self.request_get_custom_product_activity_logs(method=method, params=params)
        return self.get_json_response(response=response)

    def request_get_custom_product_version(self, customProductId, params=None, version=None):
        """
        Get custom product specific to version
        :param customProductId: unique custom product to get
        :param params: optional parameters
        :param version: optional version to GET
        :return: <requests> response from GET
        """
        if version is None:
            url = "{baseurl}/{customProductId}/version".format(
                baseurl=self.get_baseurl(), customProductId=customProductId)
        else:
            url = "{baseurl}/{customProductId}?version={version}".format(
                baseurl=self.get_baseurl(),
                customProductId=customProductId,
                version=version,
            )
        return self.session.get(url)

    def get_custom_product_version(self, params=None):
        response = self.request_get_custom_product_version(params=params)
        return self.get_json_response(response=response)

    #########################
    #
    #   CREATE
    #
    #########################

    def request_create_custom_product(self, keyspace, url, name, desc=None):
        """
        Create a Custom Product
        :param keyspace: keyspace to use in request payload
        :param url: url to use in request payload
        :param name: name to use in request payload
        :param desc: optional description to use in request payload
        :return: <requests> response POST
        """
        payload = {"keyspace": keyspace, "url": url, "name": name, "description": desc}
        url = "{baseurl}".format(baseurl=self.get_baseurl())
        return self.session.post(url=url, data=payload)

    def create_custom_product(self, keyspace, url, name, desc=None):
        """
        Create a Custom Product
        :param keyspace: keyspace to use in request payload
        :param url: url to use in request payload
        :param name: name to use in request payload
        :param keyspace: optional description to use in request payload
        :return: <dict> created custom product if successful otherwise empty
        """
        response = self.request_create_custom_product(keyspace=keyspace, url=url, name=name, desc=desc)
        return self.get_json_response(response=response)

    #########################
    #
    #   UPDATE
    #
    #########################

    def request_update_custom_product(self, product):
        """
        Update branding image
        :param product: <dict> product object to update
        :return: <requests> response from PUT
        """

        url = "{baseurl}/{customProductId}".format(baseurl=self.get_baseurl(), customProductId=product["id"])
        return self.session.put(url, data=product)

    def update_custom_product(self, product):
        """
        Update custom product by ID
        :param product: <dict> product object to update
        :return: <bool> True if successful, otherwise false
        """
        response = self.request_update_custom_product(product=product)
        return self.get_json_response(response=response)

    #########################
    #
    #   DELETE
    #
    #########################

    def request_delete_custom_product(self, product):
        """
        Delete branding image file
        :param product: <dict> product object to delete
        :return: <requests> response from DELETE
        """
        url = "{baseurl}/{id}".format(baseurl=self.get_baseurl(), id=product["id"])
        return self.session.delete(url)

    def delete_custom_product(self, product):
        """
        Delete custom product by ID
        :param product: <dict> product object to delete
        :return: <bool> True if successful, otherwise false
        """
        response = self.request_delete_custom_product(product=product)
        return self.get_bool_response(response=response)
