from pydashboard.pydashboard.base import Base


class KeyTransactions(Base):
    """
    Retrieve Key Transactions
    """

    DEFAULT_PARAMS = {
        "limit": 20,
        "skip": 0,
        "orderBy": "createdTs",
        "asc": True
    }

    def __init__(self, apiuser, tenantid, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        :param refresh_on_init: <boolean> Whether to refresh data policies upon initialization
        :return:
        """
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.keytransactions = {}

        if refresh_on_init:
            self.refresh()

    def get_baseurl(self):
        return "%s/%s/key-requests" % (self.resource_url, self.tenantid)

    def refresh(self):
        self.keytransactions = self.get_key_transactions()
        self.keytransactions_by_cid = self.get_key_transactions_by_cid()

    def request_get_key_transactions(self, params=None):
        """
        Retrieve key transactions
        :return: <requests> response from POST
        """
        url = "{baseurl}/list".format(baseurl=self.get_baseurl())
        self.get_params(params=params, desired_params=self.DEFAULT_PARAMS)
        return self.session.post(url, data=params)

    def get_key_transactions(self, params=None):
        """
        Retrieve key transactions
        :return: <dict> key transactions or empty
        """
        response = self.request_get_key_transactions(params=params)
        return self.get_json_response(response=response)

    def request_get_key_transaction(self):
        """
        Retrieve key transactions
        :return: <requests> response from GET
        """
        url = self.get_baseurl()
        return self.session.get(url)

    def get_key_transaction(self):
        """
        Retrieve key transactions
        :return: <dict> key transactions or empty
        """
        response = self.request_get_key_transaction()
        return self.get_json_response(response=response)

    def get_key_transactions_by_cid(self):
        kt_by_cid = {}
        for each_kt in self.keytransactions["Resources"]:
            kt_by_cid[each_kt["conversationId"]] = each_kt
        return kt_by_cid
