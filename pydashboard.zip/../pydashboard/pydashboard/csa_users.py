from pydashboard.pydashboard.base import Base


class CSAUsers(Base):

    SCHEMA_CORE = "urn:scim:schemas:core:1.0"
    SCHEMA_EXTENSION = "urn:scim:schemas:extension:ionic:1.0"
    DEFAULT_LIMIT = 0
    DEFAULT_PARAMS = {
        "asc": True,
        "limit": 200,
        "orderBy": "last_name",
        "skip": 0
    }

    def __init__(self, apiuser, tenantid, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param refresh_on_init: <boolean> Whether to refresh tenants upon initialization
        :return:
        """
        self.apiuser = apiuser
        self.tenantid = tenantid
        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.users_full = {}
        self.users = []
        self.users_by_username = {}

        if refresh_on_init:
            self.refresh()

    def refresh(self):
        self.users_full = self.get_users()
        self.users = self.users_full.get("Resources")
        self.users_by_username = self.get_users_by_username()

    def get_baseurl(self):
        return "%s/%s/scim/Users" % (self.resource_url, self.tenantid)

    def get_bulk_baseurl(self):
        return "%s/%s/scim/Bulk" % (self.resource_url, self.tenantid)

    def request_get_users(self, params=None):
        """
        Retrieve users
        :param limit: <int> number of users to retrieve
        :param options: <list> additional options to append to the query
        :return: <requests> response from GET
        """
        url = "%s/list" % (self.get_baseurl())
        params = self.get_params(params=params, desired_params=self.DEFAULT_PARAMS)
        return self.session.post(url=url, should_wait=False, data=params)

    def get_users(self, params=None):
        """
        Retrieve users
        :return: <dict> users if successful otherwise empty
        """
        response = self.request_get_users(params=params)
        return self.get_json_response(response=response)

    def get_users_by_username(self):
        """
        Retrieve users with username as KEY
        :return: <dict> users with the username as KEY if successful otherwise empty
        """
        users_by_username = {}
        for each_user in self.users:
            users_by_username[each_user["userName"]] = each_user
        return users_by_username

    def request_update_user(self, user):
        """
        Update a user
        :param user: <dict> user to update
        :return: <requests> response from PUT
        """
        url = "%s/%s" % (self.get_baseurl(), user["id"])
        return self.session.put(url, data=user)

    def update_user(self, user):
        """
        Update a user
        :param user: <dict> user to update
        :return: <dict> updated user if successful otherwise empty
        """
        response = self.request_update_user(user=user)
        return self.get_json_response(response=response)

    def request_create_user(
            self,
            firstname="",
            lastname="",
            emails=None,
            userName="",
            domainUpn="",
            mergeby="none",
            acct_type=None,
            password="",
            externalid="",
            groupids=None,
    ):

        # Check for None arguments
        if emails is None:
            emails = []
        if acct_type is None:
            acct_type = []
        if groupids is None:
            groupids = []

        roles = []
        for each_acct_type in acct_type:
            # assert each_acct_type in self.VALID_ROLES, "%s is not a valid user role" % each_acct_type
            roles_inner = {}
            roles_inner["value"] = each_acct_type
            roles.append(roles_inner)

        schema_ext = {"groups": []}
        for each_group_id in groupids:
            schema_ext["groups"].append({"type": "group", "value": each_group_id})

        if domainUpn:
            schema_ext["domainUpn"] = domainUpn

        if mergeby:
            schema_ext["mergeBy"] = mergeby

        payload = {
            "schemas": [self.SCHEMA_CORE, self.SCHEMA_EXTENSION],
            "name": {
                "givenName": firstname,
                "familyName": lastname,
                "formatted": firstname + " " + lastname,
            },
            "externalId": externalid,
            "emails": emails,
            "roles": roles,
            self.SCHEMA_EXTENSION: schema_ext,
            "userName": userName,
        }
        if password:
            payload["password"] = password
        return self.session.post(url=self.get_baseurl(), data=payload)

    def create_user(
            self,
            firstname="",
            lastname="",
            emails=None,
            userName="",
            domainUpn="",
            mergeby="none",
            acct_type=None,
            password="",
            externalid="",
            groupids=None,
    ):
        """
        :param domainUpn:
        :param email:
        :param firstname:
        :param lastname:
        :param acct_type: if "ta": tenant_admin will be created. If "csa": csa will be created
        :param externalid:
        :param groupids
        :return:
        """
        response = self.request_create_user(
            firstname=firstname,
            lastname=lastname,
            emails=emails,
            userName=userName,
            externalid=externalid,
            domainUpn=domainUpn,
            groupids=groupids,
            mergeby=mergeby,
            acct_type=acct_type,
            password=password,
        )
        return self.get_json_response(response=response)

    def request_delete_user(self, user):
        """
        Delete user
        :param user: <dict> user to delete
        :return: <requests> response from DELETE
        """
        url = "%s/%s" % (self.get_baseurl(), user["id"])
        return self.session.delete(url)

    def delete_user(self, user):
        """
        Delete user
        :param user: <dict> user to delete
        :return: <boolean> True if deletion is successful other False
        """
        response = self.request_delete_user(user=user)
        return self.get_bool_response(response=response)

    def get_baseurl_unlock(self):
        return "%s/%s/scim/Users/{}/unlock" % (self.resource_url, self.tenantid)

    def request_unlock_account(self, user):
        """
        :param user: User Object to unlock
        :return: <requests> response from POST
        """
        url = self.get_baseurl_unlock().format(user["id"])
        payload = {"email": user["userName"], "id": user["id"]}
        return self.session.post(url=url, data=payload)

    def unlock_account(self, user):
        """
        Unlock the user account for specified user
        :param user: User Object to Unlock
        :return: <dict> if successful otherwise empty dict
        """
        response = self.request_unlock_account(user=user)
        return self.get_json_response(response=response)

    def request_create_api_key(self, user, name, scopes=None):
        """
        Create API Key for user
        :param user: <dict> user to create key for
        :param name: <string> key name
        :param scopes: <list> list of scopes
        :return: <request> response from POST
        """
        url = "%s/%s/apikeys" % (self.get_baseurl(), user["id"])
        payload = {"name": name}
        if scopes is not None:
            payload["scopes"] = scopes

        return self.session.post(url, data=payload)

    def create_api_key(self, user, name, scopes=None):
        """
        Create API Key for user
        :param user: <dict> user to create key for
        :param name: <string>
        :param scopes: <list> list of scopes
        :return: <dict> created key if successful, otherwise empty
        """
        if scopes is None:
            scopes = []
        response = self.request_create_api_key(user=user, name=name, scopes=scopes)
        return self.get_json_response(response=response)
