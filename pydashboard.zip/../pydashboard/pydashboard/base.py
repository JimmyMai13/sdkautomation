import json
import warnings


class Base:
    def __init__(self, apiuser, tenantid=None):
        self.apiuser = apiuser
        self.tenantid = tenantid

    def get_json_response(self, response):
        """
        Return json response if the 'status_code' of the response is 'good'
        :param response: requests response object
        :return: dict
        """
        # if response.status_code in self.apiuser.session.GOOD_STATUSES:
        #     return response.json()
        # else:
        #     return {}

        #  ~NOTE~ --> This line of code is equivalent to the if/else logic above

        return response.json() if response.status_code in self.apiuser.session.GOOD_STATUSES else {}

    def set_tenantid(self, tenantid):
        """
        Set the tenantid
        :param tenantid: tenantid
        :type: str
        """
        # TODO --> validate tenantid being passed in a string
        #assert isinstance(tenantid, str)
        self.tenantid = tenantid

    def get_bool_response(self, response):
        """
        Return boolean if the 'status_code' of the response is good (used for deletes which have no content (no json)
        :param response: boolean
        :return:
        """
        return response.status_code in self.apiuser.session.GOOD_STATUSES

    # TODO --> update this to 'get_payload' and start using the correct terms for each request
    def get_params(self, params=None, desired_params=None):
        if params is None:
            params = dict()
        if desired_params is not None:  # this should be a dictionary always
            params = desired_params
        return params

    @staticmethod
    def warn_for_possible_invalid_payload(payload):
        """
        Warn user about potential invalid payload for POST request
        :param payload: data payload
        :type: dict
        """
        if not isinstance(payload, dict):
            warnings.warn("The payload for this POST request may be invalid")

    @staticmethod
    def warn_for_possible_invalid_params(params):
        """
        Warn user about potential invalid request params for GET request
        :param params: query params for request
        :type: str
        """
        if not isinstance(params, str):
            warnings.warn("The query params for for this GET request may be invalid")

    # @staticmethod
    # def verify_valid_data_type_for_argument(argument, valid_data_type_list):

    @staticmethod
    def set_get_params(params, url):
        options = "?"
        for key, val in params.items():
            options += key + "=" + str(val) + "&"
        # remove last '&' from options
        options = options[:-1]
        return url + options

    @staticmethod
    def get_mongo_search_string(search_items):
        """
        returns something like: [json.dumps({'external_id': {'$regex': '^(?i).*some_externalid.*'}})]
        :param search_items: list of dicts e.g. [{'external_id': 123}, {'external_id': 456}, ]
        :return:
        """

        search_params = []
        for each_search_item_dict in search_items:
            search_key = list(each_search_item_dict.keys())[0]
            search_value = each_search_item_dict[search_key]
            search_string = json.dumps({search_key: {"$regex': '^(?i).*{}.*".format(search_value)}})
            search_params.append(search_string)
        return {"q": search_params}.copy()
