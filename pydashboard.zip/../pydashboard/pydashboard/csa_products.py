from pydashboard.pydashboard.base import Base


class CSAProducts(Base):
    """
    Perform operations on CSA Products
    """

    SCHEMA_CORE = "urn:scim:schemas:core:1.0"
    SCHEMA_EXTENSION = "urn:scim:schemas:extension:ionic:1.0"
    DEFAULT_POST_PARAMS = {"asc": True, "limit": 100, "orderBy": "name", "skip": 0}

    def __init__(self, apiuser, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param refresh_on_init: <boolean> Whether to refresh tenants upon initialization
        :return:
        """
        self.apiuser = apiuser

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.products = []
        self.products_by_name = {}

        if refresh_on_init:
            self.refresh()

    def get_baseurl(self):
        return "%s/products" % self.resource_url

    def get_baseurl_screen_history(self):
        return "%s/products/screen/history" % self.resource_url

    def get_baseurl_downloads_history(self):
        return "%s/products/downloads/history" % self.resource_url

    def refresh(self):
        self.products = self.get_products().get("Resources")
        self.products_by_name = self.get_products_by_name()

    def request_get_products(self, method="POST", params=None):
        """
        Retrieve Product Information
        :param params: options params
        :param method: <str> request method
        :return: <requests> response from POST
        """
        if method == "POST":
            url = "%s/list" % self.get_baseurl()
            params = self.get_params(params=params, desired_params=self.DEFAULT_POST_PARAMS)
            return self.session.post(url=url, data=params)
        else:
            url = self.get_baseurl()
            return self.session.get(url=url, params=params)

    def get_products(self, method="POST", params=None):
        """
        Retrieve Products
        :return: <dict> products if successful otherwise empty
        """
        response = self.request_get_products(method=method, params=params)
        return self.get_json_response(response=response)

    def request_get_product_detail(self, product):
        """
        Request to return product data for specific product
        :param product: <dict> of the product object
        :return: <requests> response from GET
        """
        url = "%s/%s" % (self.get_baseurl(), product["id"])
        return self.session.get(url)

    def get_product_detail(self, product):
        """
        Request to retrieve product data for specific product
        :param product: <object> of the product object
        :return: <dict> product detail if successful or empty
        """
        response = self.request_get_product_detail(product=product)
        return self.get_json_response(response=response)

    def request_get_product_by_version(self, product, version):
        """
        Retrieve product information by version
        :param product: <dict> product
        :param version: <string> version to retrieve
        :return: <requests> response from GET
        """
        url = "%s/%s?version=%s" % (self.get_baseurl(), product["id"], version)
        return self.session.get(url)

    def get_product_by_version(self, product, version):
        """
        Retrieve product information by version
        :param product: <dict> product
        :param version: <string> version to retrieve
        :return: <dict> product at specified version if successful, otherwise empty
        """
        response = self.request_get_product_by_version(product=product, version=version)
        return self.get_json_response(response=response)

    def get_products_by_name(self):
        """
        Retrieve all Products configured for the CSA by name
        :return: <dict> all products with name as the KEY if successful otherwise empty
        """
        product_by_name = {}
        for each_product in self.products:
            product_by_name[each_product["name"]] = each_product
        return product_by_name

    def request_create_product(self, name, architecture=None, desc=None, os=None, public=False, mergeby="none"):
        """
        Creates a product in CSA account
        :param name: <string> name of the product
        :param desc: <string> description of the product
        :param architecture: <string> architecture of the product
        :param os: <string> OS of the product
        :param public: <boolean> public or not
        :param mergeby:
        :return: <request> response from post
        """
        url = "%s/products" % (self.resource_url)
        payload = {"schemas": [self.SCHEMA_CORE, self.SCHEMA_EXTENSION], "name": name}
        if architecture:
            payload["architecture"] = architecture
        if desc:
            payload["description"] = desc
        if os:
            payload["os"] = os
        if public:
            payload["access"] = {"public": True, "tenants": []}
        if mergeby:
            payload[self.SCHEMA_EXTENSION] = {"mergeBy": mergeby}
        return self.session.post(url, data=payload, should_wait=False)

    def create_product(self, name, desc=None, architecture=None, os=None, public=False, mergeby="none"):
        """
        Creates a product in CSA account
        :param name: <string> name of the product
        :param desc: <string> description of the product
        :param architecture: <string> architecture of the product
        :param os: <string> OS of the product
        :param public: <boolean> public or not
        :param mergeby:
        :return: <dict> product if successful otherwise empty
        """
        product = {}
        response = self.request_create_product(
            name=name,
            desc=desc,
            architecture=architecture,
            os=os,
            public=public,
            mergeby=mergeby,
        )
        return self.get_json_response(response=response)

    def request_update_product(self, product, tenants=[]):
        """
        Request to update a product
        :param product: <dict> of the product object
        :param tenants: <list> of tenant objects
        :return: <requests> response from UPDATE
        """
        url = "%s/%s" % (self.get_baseurl(), product["id"])
        if tenants:
            product["access"] = {"tenants": tenants, "public": False}
        return self.session.put(url, data=product)

    def update_product(self, product, tenants=[]):
        """
        Updates product
        :param product: <dict> product object to update
        :param tenants: <list> of tenant objects
        :return: <dict> updated_product if successful otherwise empty
        """
        response = self.request_update_product(product=product, tenants=tenants)
        return self.get_json_response(response=response)

    def request_delete_product(self, product):
        """
        Deletes product
        :param product: <dict> product object to delete
        :return: <requests> response from DELETE
        """
        url = "%s/%s" % (self.get_baseurl(), product["id"])
        return self.session.delete(url)

    def delete_product(self, product):
        """
        Deletes product
        :param product: <dict> product object to delete
        :return: <boolean> True if deletion successful, otherwise False
        """
        response = self.request_delete_product(product=product)
        return self.get_bool_response(response=response)

    def enable_product(self, product):
        """
        Enable a Product
        :param product: <dict> product to enable
        :return: <dict> product with the new status
        """
        product["status"] = True
        return self.update_product(product=product)

    def disable_product(self, product):
        """
        Disable a Product
        :param product: <dict> product to disable
        :return: <dict> product with the new status
        """
        product["status"] = False
        return self.update_product(product=product)

    def request_create_external_version(self, product, name, external_url, desc=None, mergeby="none"):
        """
        Retrieve response to create a version
        :param product: <object> product object to create version
        :param name: <string>
        :param external_url: <string>
        :param desc: <string>
        :param mergeby:
        :return: Response status code
        """
        url = "%s/%s/versions" % (self.get_baseurl(), product["id"])
        payload = {
            "schemas": [self.SCHEMA_CORE, self.SCHEMA_EXTENSION],
            "url": external_url,
            "name": name,
            "productId": product["id"],
            "status": True,
        }
        if desc:
            payload["description"] = desc
        if mergeby:
            payload[self.SCHEMA_EXTENSION] = {"mergeBy": mergeby}
        return self.session.post(url, data=payload, should_wait=False)

    def create_external_version(self, product, name, external_url, desc=None, mergeby="none"):
        """
        Create an external hosted version for products
        :param product: <object>
        :param name: <string>
        :param external_url: <string>
        :param desc: <string>
        :param mergeby:
        :return: version
        """
        response = self.request_create_external_version(
            product=product,
            name=name,
            external_url=external_url,
            desc=desc,
            mergeby=mergeby,
        )
        return self.get_json_response(response=response)

    def request_create_version(self, name, product, desc=None, mergeby="none", enabled=False):
        url = "%s/%s/versions" % (self.get_baseurl(), product["id"])
        payload = {
            "schemas": [self.SCHEMA_CORE, self.SCHEMA_EXTENSION],
            "name": name,
            "status": enabled,
        }
        if desc:
            payload["description"] = desc
        if mergeby:
            payload[self.SCHEMA_EXTENSION] = {"mergeBy": mergeby}
        return self.session.post(url, data=payload, should_wait=False)

    def create_version(self, name, product, desc=None, mergeby="none", enabled=False):
        response = self.request_create_version(name=name, product=product, desc=desc, mergeby=mergeby, enabled=enabled)
        return self.get_json_response(response=response)

    def request_create_ionic_version(self, version, product, name, file_path, file_name, desc=None):
        """
        Create an ionic hosted version for products
        :param product: <object>
        :param name: <string>
        :param file_path: <string> - location of the file including the filename
        :param file_name: <string> - the desired name of the file when it is downloaded
        :param desc: <string>
        :return: version
        """
        url = "%s/%s/versions/%s/file" % (
            self.get_baseurl(),
            product["id"],
            version["id"],
        )
        payload = {"name": name}
        if desc:
            payload["description"] = desc

        return self.session.post_with_file(
            url,
            data=payload,
            file_path=file_path,
            file_name=file_name,
            should_wait=False,
        )

    def create_ionic_version(self, product, version, name, file_path, file_name, desc=None):
        """
        Create an ionic hosted version for products
        :param product: <object>
        :param name: <string>
        :param file_path: <string> - location of the file including the filename
        :param file_name: <string> - the desired name of the file when it is downloaded
        :param desc: <string>
        :return: version
        """
        response = self.request_create_ionic_version(
            product=product,
            version=version,
            name=name,
            file_path=file_path,
            file_name=file_name,
            desc=desc,
        )
        return self.get_json_response(response=response)

    def request_update_version(self, version, product):
        """
        Request to update a version
        :param product: <object> product object
        :param version: <object> of the version object
        :return: <requests> response from UPDATE
        """

        url = "%s/%s/versions/%s" % (self.get_baseurl(), product["id"], version["id"])
        return self.session.put(url, data=version)

    def update_version(self, version, product):
        """
        Updates version
        :param product: <object> product object
        :param version: <object> version object to update
        :return: <dict> update)version if successful otherwise empty
        """
        response = self.request_update_version(version=version, product=product)
        return self.get_json_response(response=response)

    def request_delete_version(self, product, version):
        """
        Deletes version
        :param product: <object> product object
        :param version: <object> version object to delete
        :return: <requests> response from DELETE
        """
        url = "%s/%s/versions/%s" % (self.get_baseurl(), product["id"], version["id"])
        return self.session.delete(url)

    def delete_version(self, product, version):
        """
        Deletes version
        :param product: <object> product object
        :param version: <object> version object to delete
        :return: <boolean> True if deletion successful, otherwise False
        """
        response = self.request_delete_version(product=product, version=version)
        return self.get_bool_response(response=response)

    def enable_version(self, version, product):
        """
        Enable a version
        :param product: <object> product object
        :param version: <object> version to enable
        :return: <dict> version with the new status
        """
        version["status"] = True
        return self.update_version(version=version, product=product)

    def disable_version(self, version, product):
        """
        Disable a version
        :param product: <object> product object
        :param version: <object> version to disable
        :return: <dict> version with the new status
        """
        version["status"] = False
        return self.update_version(version=version, product=product)

    def set_product_stable_version(self, product, version=None):
        """
        Set the product version to the latest stable version
        If you want to set the version to stable, provide the version parameter
        If you want to un-set the version to stable, dont provide it
        :param product: <object> product to update
        :param version: <object> the product version to update
        :return: updated product with stable version status
        """
        if version:
            prod = product.get("releases").get("stable")
            prod["versionId"] = version["id"]
        else:
            prod = product.get("releases").get("stable")
            prod["versionId"] = ""
        return self.update_product(product=product)

    def get_product_versions(self, product):
        """
        Request to retrieve product versions for specific product
        :param product: <object> of the product
        :return: <dict> product version if successful or empty
        """
        return product.get("versions")

    def get_product_versions_by_name(self, product):
        """
        Request to retrieve a specific product versions for a specific product by name
        :param product: <object> of the product
        :return: <dict> product version if successful or empty
        """
        product_versions = self.get_product_versions(product=product).get("Resources")
        product_versions_by_name = {}
        for each_pv in product_versions:
            product_versions_by_name[each_pv["name"]] = each_pv
        return product_versions_by_name

    def request_get_screen_history(self, params=None):
        """
        Retrieve Screen History Information
        :return: <requests> response from POST
        """
        url = "%s/list" % self.get_baseurl_screen_history()
        return self.session.post(url, data=params)

    def request_get_download_history(self, params=None):
        """
        Retrieve Screen History Information
        :return: <requests> response from POST
        """
        url = "%s/list" % self.get_baseurl_downloads_history()
        return self.session.post(url, data=params)
