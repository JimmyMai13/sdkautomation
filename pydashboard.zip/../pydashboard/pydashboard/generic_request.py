from pydashboard.pydashboard.base import Base


class GenericRequest(Base):
    """
    This class allows you to make generic requests
    """

    def __init__(self, apiuser, tenantid):
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.dashboard_url = self.apiuser.dashboard_url
        self.url = ""

    def get_baseurl(self):
        return "%s/%s" % (self.resource_url, self.tenantid)

    def request_get(self, endpoint, limit):
        self.url = "%s/%s/?limit=%d" % (self.get_baseurl(), endpoint, limit)
        return self.session.get(self.url)

    def request_put(self, endpoint, data):
        self.url = "%s/%s" % (self.get_baseurl(), endpoint)
        return self.session.put(self.url, data=data)

    def request_post(self, endpoint, data):
        self.url = "%s/%s" % (self.get_baseurl(), endpoint)
        return self.session.post(self.url, data=data)

    def request_delete(self, endpoint):
        self.url = "%s/%s" % (self.get_baseurl(), endpoint)
        return self.session.delete(self.url)

    def request_options(self, endpoint):
        self.url = "%s/%s" % (self.get_baseurl(), endpoint)
        return self.requests_session.options(url=self.url)
