import base64
import datetime
import hmac
from hashlib import sha1

from requests.auth import AuthBase


class HmacAuth(AuthBase):

    DEFAULT_ORGANIZATION = "IONIC"
    DEFAULT_CONTENT_TYPE_VALUE = "application/json;charset=UTF-8"

    def __init__(
            self,
            api_key,
            api_secret,
            organization=DEFAULT_ORGANIZATION,
            content_md5_value="",
            content_type_value="",
    ):
        """
        :param api_key: <str> API Key ID
        :param api_secret: <str> API Key Secret
        :param organization: <str> Organization for request header
        :param content_md5_value: <str> Content-MD5 value
        :param content_type_value: <str> Content-Type value
        """
        self.api_key = api_key
        self.api_secret = self.decode_secret(api_secret)
        self.organization = organization
        self.content_md5_value = content_md5_value
        self.content_type_value = content_type_value
        self.date = self.get_timestamp()

    def __call__(self, request):
        self.encode(request)
        return request

    def encode(self, request):
        signature = self.create_signature(request=request, date=self.date)
        self.create_headers(request=request, signature=signature)
        return request

    def create_signature(self, request, date):
        # Remove version prefix from url path
        path = "/v2/%s" % "/".join(request.path_url.split("/")[2:])
        method = request.method
        if method == "POST" or method == "PATCH":
            if not self.content_type_value:
                # Set default content-type value if not set
                # POST and PATCH requests use default
                self.content_type_value = self.DEFAULT_CONTENT_TYPE_VALUE

        string_to_sign = "%s\n%s\n%s\n%s\n%s" % (
            method,
            self.content_md5_value,
            self.content_type_value,
            date,
            path,
        )
        # Encode the string to sign
        encoded_string_to_sign = string_to_sign.encode("utf-8")
        unencoded_signature = hmac.new(key=self.api_secret, msg=encoded_string_to_sign, digestmod=sha1).digest()
        return base64.b64encode(unencoded_signature).decode("utf-8")

    def create_headers(self, request, signature):
        request.headers["Authorization"] = "%s %s:%s" % (
            self.organization,
            self.api_key,
            signature,
        )
        request.headers["Date"] = self.date
        request.headers["Content-MD5"] = self.content_md5_value
        request.headers["Content-Type"] = self.content_type_value

    def decode_secret(self, secret):
        return base64.standard_b64decode(secret)

    def get_timestamp(self):
        # Return formatted UTC time. Ex: 'Fri, 19 May 2017 19:38:46 +0000'
        return datetime.datetime.utcnow().strftime("%a, %d %b %Y %H:%M:%S +0000")
