from pydashboard.pydashboard.base import Base


class SubjectAttributes(Base):

    DEFAULT_LIMIT = 20
    DEFAULT_PARAMS = {"limit": 100, "skip": 0}

    def __init__(self, apiuser, tenantid, refresh_on_init=True):
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.subject_attributes_full = {}
        self.subject_attributes = []
        self.subject_attributes_by_name = {}

        if refresh_on_init:
            self.refresh()

    def refresh(self):
        self.subject_attributes_full = self.get_subject_attributes()
        self.subject_attributes = self.subject_attributes_full.get("Resources")
        self.subject_attributes_by_name = self.get_subject_attributes_by_name()

    def get_baseurl(self):
        return "{}/{}/subject-attributes".format(self.resource_url, self.tenantid)

    def request_get_subject_attributes(self, params=None, method="POST", search=False):
        if method == "POST":
            if search:
                url = "{}/.search".format(self.get_baseurl())
            else:
                url = "{}/list".format(self.get_baseurl())
            params = self.get_params(params=params, desired_params=self.DEFAULT_PARAMS)
            return self.session.post(url, data=params)
        else:
            url = self.get_baseurl()
            return self.session.get(url, params=params)

    def get_subject_attributes(self, params=None, method="POST", search=False):
        response = self.request_get_subject_attributes(params=params, method=method, search=search)
        return self.get_json_response(response=response)

    def get_subject_attributes_by_name(self):
        subject_attributes_by_name = {}
        if not self.subject_attributes:
            try:
                self.subject_attributes = self.get_subject_attributes()["Resources"]
            except KeyError:
                print("CHECK PERMISSIONS")
                return subject_attributes_by_name
        for each in self.subject_attributes:
            subject_attributes_by_name[each["name"]] = each
        return subject_attributes_by_name

    def request_create_subject_attributes(self, name, datatype="string", desc=None, collect_values=False):
        url = "{}".format(self.get_baseurl())
        payload = {
            "name": name,
            "dataType": datatype,
            "description": desc,
            "collectValues": collect_values,
        }
        return self.session.post(url, data=payload)

    def create_subject_attributes(self, name, datatype="string", desc=None, collect_values=False):
        resp = self.request_create_subject_attributes(
            name=name, datatype=datatype, desc=desc, collect_values=collect_values)
        return self.get_json_response(response=resp)

    def request_update_subject_attributes(self, subject_attribute):
        url = "{}/{}".format(self.get_baseurl(), subject_attribute["id"])
        return self.session.put(url=url, data=subject_attribute)

    def update_subject_attributes(self, subject_attribute):
        resp = self.request_update_subject_attributes(subject_attribute=subject_attribute)
        return self.get_json_response(response=resp)

    def request_delete_subject_attribute(self, subject_attribute):
        url = "{}/{}".format(self.get_baseurl(), subject_attribute["id"])
        return self.session.delete(url=url)

    def delete_subject_attribute(self, subject_attribute):
        resp = self.request_delete_subject_attribute(subject_attribute=subject_attribute)
        return self.get_bool_response(response=resp)

    #########################################
    #
    #
    # Subject Attribute Value
    #
    #
    ##########################################

    def request_get_subject_attribute_values(self, subject_attribute, params=None, method="POST", search=False):
        if method == "POST":
            if search:
                url = "{}/{}/values/.search".format(self.get_baseurl(), subject_attribute["id"])
            else:
                url = "{}/{}/values/list".format(self.get_baseurl(), subject_attribute["id"])
            params = self.get_params(params=params, desired_params=self.DEFAULT_PARAMS)
            return self.session.post(url, data=params)
        else:
            url = "{}/{}/values".format(self.get_baseurl(), subject_attribute["id"])
            return self.session.get(url, params=params)

    def get_subject_attribute_values(self, subject_attribute, params=None, method="POST", search=False):
        response = self.request_get_subject_attribute_values(
            subject_attribute=subject_attribute,
            params=params,
            method=method,
            search=search,
        )
        return self.get_json_response(response=response)

    def request_create_subject_attribute_value(self, subject_attribute, name, desc=None):
        url = "{}/{}/values".format(self.get_baseurl(), subject_attribute["id"])
        payload = {"name": name, "description": desc}
        return self.session.post(url, data=payload)

    def create_subject_attribute_value(self, subject_attribute, name, desc=None):
        resp = self.request_create_subject_attribute_value(subject_attribute=subject_attribute, name=name, desc=desc)
        return self.get_json_response(response=resp)

    def request_update_subject_attribute_value(self, subject_attribute, subject_attribute_value):
        url = "{}/{}/values/{}".format(self.get_baseurl(), subject_attribute["id"], subject_attribute_value["id"])
        return self.session.put(url=url, data=subject_attribute_value)

    def update_subject_attribute_value(self, subject_attribute, subject_attribute_value):
        resp = self.request_update_subject_attribute_value(
            subject_attribute=subject_attribute,
            subject_attribute_value=subject_attribute_value,
        )
        return self.get_json_response(response=resp)

    def request_delete_subject_attribute_value(self, subject_attribute, subject_attribute_value):
        url = "{}/{}/values/{}".format(self.get_baseurl(), subject_attribute["id"], subject_attribute_value["id"])
        return self.session.delete(url=url)

    def delete_subject_attribute_value(self, subject_attribute, subject_attribute_value):
        resp = self.request_delete_subject_attribute_value(
            subject_attribute=subject_attribute,
            subject_attribute_value=subject_attribute_value,
        )
        return self.get_bool_response(response=resp)
