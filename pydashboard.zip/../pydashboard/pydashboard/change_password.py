from pydashboard.pydashboard.base import Base


class ChangePassword(Base):
    """
    This class allows you to change a tenant admin or csa password
    You can also request a forgot password email
    """

    def __init__(self, apiuser, tenantid):
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.ERROR_INVALID_CURRENT_PWD = {"error": "USER_PASSWORD_INVALID_CURRENT", "code": 10106}

    def get_baseurl(self, user_id):
        base_url = "{}/{}/scim/Users/{}/password".format(self.resource_url, self.tenantid, user_id)
        return base_url

    def request_change_password(self, user, old_pwd, new_pwd, repeat_failed_request=False):
        url = self.get_baseurl(user_id=user["id"])
        payload = {"old_password": old_pwd, "password": new_pwd}
        return self.session.post(url=url, data=payload, repeat_failed_request=repeat_failed_request)

    def change_password(self, user, old_pwd, new_pwd, repeat_failed_request=False):
        response = self.request_change_password(
            user=user,
            old_pwd=old_pwd,
            new_pwd=new_pwd,
            repeat_failed_request=repeat_failed_request,
        )
        return response
