from pydashboard.pydashboard.base import Base


class Products(Base):
    """
    Retrieve Products
    """

    def __init__(self, apiuser, tenantid, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        :param refresh_on_init: <boolean> Whether to refresh data policies upon initialization
        :return:
        """
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url
        self.products = {}
        self.products_by_name = {}

        if refresh_on_init:
            self.refresh()

    def get_baseurl(self):
        return "%s/%s/products" % (self.resource_url, self.tenantid)

    def refresh(self):
        self.products_full = self.get_products()
        self.products = self.products_full.get("Resources")
        self.products_by_name = self.get_products_by_name()

    def get_tenant_id(self, tenantid):
        """
        Each request takes a tenantid.
        If tenantid is not provided, the default tenantid used when authenticating the user will be used
        :param tenantid: <string> - id of the tenant
        :return: id of the tenant
        """
        tenant_id_to_use = self.tenantid
        if tenantid:
            tenant_id_to_use = tenantid
        return tenant_id_to_use

    def request_get_products(self, params={"limit": 100, "skip": 0, "status": True}):
        """
        Retrieve product information
        :return: <requests> response from GET
        """
        url = "%s/list" % (self.get_baseurl())
        params["tenantId"] = self.get_tenant_id(tenantid=params.get("tenantId"))
        return self.session.post(url, should_wait=False, data=params)

    def get_products(self):
        """
        Retrieve Prodicts
        :return: <dict> products or empty
        """
        response = self.request_get_products()
        return self.get_json_response(response=response)

    def get_products_by_name(self):
        """
        Retrieve all Products configured for the tenant by productID
        :return: <dict> all products with id as the KEY if successful otherwise empty
        """
        product_name = {}
        for each_product in self.products:
            product_name[each_product["name"]] = each_product
        return product_name

    def get_product_versions(self, product):
        return product.get("versions")

    def get_product_versions_by_name(self, product):
        product_versions = self.get_product_versions(product=product).get("Resources")
        product_versions_by_name = {}
        for each_pv in product_versions:
            product_versions_by_name[each_pv["name"]] = each_pv
        return product_versions_by_name
