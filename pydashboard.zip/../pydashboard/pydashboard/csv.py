import base64
import json

import requests

from pydashboard.pydashboard.base import Base
from pydashboard.pydashboard.hmac_auth import HmacAuth


class CSV(Base):
    """
    The CSV endpoint allows you to perform API listing operations
    to obtain listed objects in CSV format rather than JSON
    """

    DEFAULT_PARAMS_USERS = {"limit": 20, "skip": 0, "orderBy": "lastName", "asc": True}
    DEFAULT_PARAMS_GROUPS = {"asc": True, "limit": 100, "orderBy": "name", "skip": 0}

    def __init__(self, apiuser, tenantid):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        """
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

    def get_baseurl(self):
        return "{resource_url}/{tenantid}/csv".format(resource_url=self.resource_url, tenantid=self.tenantid)

    def request_export_csv(self, columns, path, params=None):
        """
        Request to get CSV for specified list
        :param columns: <list> list of json objects specifying column names
        :param path: <str> path of resource list
        :param params: <dict> optional params
        :return: <requests> response from POST
        """
        url = self.get_baseurl()
        payload = {"columns": columns, "path": path}
        if params:
            payload["params"] = params

        # return self.session.post(url=url, data=params)
        request_data = json.dumps(payload)
        if self.apiuser.login_type == "hmac":
            auth = HmacAuth(api_key=self.apiuser.usr, api_secret=self.apiuser.pwd)
            return requests.post(url=url, data=request_data, auth=auth)
        else:
            headers = {}
            if self.apiuser.login_type == "oauth":
                auth = "Bearer {token}".format(token=self.apiuser.pwd)
                headers["Authorization"] = auth
                headers["Content-Type"] = "application/json"
                req = requests.Request(method="POST", url=url, headers=headers)
                prepared = req.prepare()
                s = requests.Session()
            if self.apiuser.login_type == "dashboard":
                headers["Content-Type"] = "application/json"
                req = requests.Request(method="POST", url=url, headers=headers)
                prepared = req.prepare()
                s = requests.Session()
            if self.apiuser.login_type == "api":
                login_format = self.apiuser.usr + ":" + self.apiuser.pwd
                auth = "Basic {signature}".format(
                    signature=base64.b64encode(bytes(login_format, encoding="utf-8")).decode("utf-8"))
                headers["Authorization"] = auth
                headers["Content-Type"] = "application/json"
                req = requests.Request(
                    method="POST",
                    url=url,
                    headers={
                        "Authorization": auth,
                        "Content-Type": "application/json"
                    },
                    data=request_data,
                )
                prepared = req.prepare()
                s = requests.Session()
            return s.send(prepared)

    def export_csv(self, columns, path, params=None):
        """
        Request to get CSV for specified list
        :param columns: <list> list of json objects specifying column names
        :param path: <str> path of resource list
        :param params: <dict> optional params
        :return: csv object
        """
        response = self.request_export_csv(column=columns, path=path, params=params)
        return response
