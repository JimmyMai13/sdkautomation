from pydashboard.pydashboard.base import Base


class SystemMessages(Base):
    def __init__(self, apiuser, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        :return:
        """
        self.apiuser = apiuser

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.messages = []

        if refresh_on_init:
            self.refresh()

    def get_baseurl(self):
        return "%s/system-messages" % self.resource_url

    def refresh(self):
        self.messages = self.get_system_messages()

    def request_get_system_messages(self, params=None, method="POST"):
        """
        Retrieve system messages
        :param params: optional params
        :return: <request> response from POST
        """
        if method not in ["GET", "POST"]:
            raise Exception("Unacceptable request type")
        if method == "POST":
            url = "{baseurl}/list".format(baseurl=self.get_baseurl())
            return self.session.post(url=url, data=params)
        else:
            url = self.get_baseurl()
            return self.session.get(url=url, params=params)

    def get_system_messages(self, params=None, method="POST"):
        """
        Retrieve system messages
        :param params: optional params
        :return: <dict> system messages if successful, otherwise empty
        """
        response = self.request_get_system_messages(params=params, method=method)
        return self.get_json_response(response=response)
