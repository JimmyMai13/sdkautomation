from pydashboard.pydashboard.base import Base


class CSAServices(Base):
    """
    Perform operations on Services
    """

    DEFAULT_POST_PARAMS = {"limit": 100}

    def __init__(self, apiuser, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param refresh_on_init: <boolean> Whether to refresh tenants upon initialization
        :return:
        """
        self.apiuser = apiuser

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.services = []

        if refresh_on_init:
            self.refresh()

    def get_baseurl(self):
        return "%s/services" % self.resource_url

    def refresh(self):
        self.services = self.get_services()

    def request_get_services(self):
        """
        Retrieve Services Information
        :return: <requests> response from GET
        """
        url = self.get_baseurl()
        return self.session.get(url)

    def get_services(self):
        """
        Retrieve Services
        :return: <dict> services if successful otherwise empty
        """
        response = self.request_get_services()
        return self.get_json_response(response=response)
