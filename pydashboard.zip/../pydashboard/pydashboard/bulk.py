from pydashboard.pydashboard.base import Base


class Bulk(Base):
    def __init__(self, apiuser, tenantid):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        :return:
        """
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

    def get_baseurl(self, scim=False):
        if scim:
            url = "%s/%s/scim/Bulk" % (self.resource_url, self.tenantid)
        else:
            url = "%s/%s/bulk" % (self.resource_url, self.tenantid)
        return url

    def request_bulk_api(self, operations, response_type="always", scim=False, fail_on_errors=None):
        """
        Send Bulk API Request
        :param operations: <list> list of operations
        :param response_type: <string> defines how each operation's response is returned
        :return: <requests> response from POST
        """

        url = self.get_baseurl(scim=scim)
        payload = {"Operations": operations}
        if not scim:
            payload["responseType"] = response_type
        if scim:
            payload["schemas"] = ["urn:scim:schemas:core:1.0"]
            if fail_on_errors is not None:
                payload["failOnErrors"] = fail_on_errors
        return self.session.post(url, data=payload)

    def bulk_api(self, operations, response_type="always", scim=False, fail_on_errors=None):
        """
        Send Bulk API
        :param operations: <list> list of operations
        :param response_type: <string> defines how each operation's response is returned
        :return: <dict> bulk api responses if successful, otherwise empty
        """
        response = self.request_bulk_api(operations=operations, response_type=response_type)
        return self.get_json_response(response=response)
