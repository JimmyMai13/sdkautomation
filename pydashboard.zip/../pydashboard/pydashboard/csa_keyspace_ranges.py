from pydashboard.pydashboard.base import Base


class CSAKeyspaceRanges(Base):
    """
    Perform operations on CSA Keyspace Ranges
    """

    DEFAULT_POST_PARAMS = {"limit": 100}

    def __init__(self, apiuser, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param refresh_on_init: <boolean> Whether to refresh tenants upon initialization
        :return:
        """
        self.apiuser = apiuser
        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.keyspace_ranges_full = {}
        self.keyspace_ranges = []
        self.keyspace_ranges_by_name = {}

        if refresh_on_init:
            self.refresh()

    def get_baseurl(self):
        return "%s/keyspace-ranges" % self.resource_url

    def refresh(self):
        self.keyspace_ranges_full = self.get_keyspace_ranges()
        if self.keyspace_ranges_full.get("Resources"):
            self.keyspace_ranges = self.keyspace_ranges_full["Resources"]
        else:
            self.keyspace_ranges = {
                "totalResults": 0,
                "skip": 0,
                "limit": 100,
                "Resources": [],
            }["Resources"]
        self.keyspace_ranges_by_name = self.get_keyspace_range_by_name()

    def request_get_keyspace_ranges(self, params=None):
        """
        Retrieve Keyspace Ranges Information
        :return: <requests> response from GET
        """
        url = "%s/list" % self.get_baseurl()
        params = self.get_params(params=params, desired_params=self.DEFAULT_POST_PARAMS)
        return self.session.post(url=url, data=params)

    def get_keyspace_ranges(self, params=None):
        """
        Retrieve Keyspace Ranges
        :return: <dict> Keyspace Ranges if successful otherwise empty
        """
        resp = self.request_get_keyspace_ranges(params=params)
        return self.get_json_response(response=resp)

    def request_get_keyspace_range_detail(self, keyspace_range):
        """
        Request to return Keyspace Range Data for Specific Keyspace Range
        :param keyspace_range: <dict> of the keyspace range object
        :return: <requests> response from GET
        """
        url = "%s/%s" % (self.get_baseurl(), keyspace_range["id"])
        return self.session.get(url)

    def get_keyspace_range_detail(self, keyspace_range):
        """
        Request to retrieve Keyspace Range data for specific Keyspace Range
        :param keyspace_range: <object> of the keyspace range
        :return: <dict> keyspace range detail if successful otherwise empty
        """
        resp = self.request_get_keyspace_range_detail(keyspace_range=keyspace_range)
        return self.get_json_response(response=resp)

    def get_keyspace_range_by_name(self):
        """
        Retrieve all keyspace ranges configured for the CSA by name
        :return: <dict> all keyspace ranges with name as the KEY if successful otherwise empty
        """
        keyspace_range_by_name = {}
        for each_keyspace in self.keyspace_ranges:
            keyspace_range_by_name[each_keyspace["min"]] = each_keyspace
        return keyspace_range_by_name

    def request_create_keyspace_range(self, min, max, exclusion=[], available=True):
        """
        Creates a keyspace range for CSA
        :param min: <int> keyspace range min
        :param max: <int> keyspace range max
        :param exclusion: <list> list of excluded keyspace ranges
        :param available: <boolean> T or F for status available
        :return: <request> response from POST
        """
        url = "%s" % self.get_baseurl()
        payload = {
            "available": available,
            "max": max,
            "min": min,
            "excluded": exclusion,
            "counter": min,
        }
        return self.session.post(url, data=payload, should_wait=False)

    def create_keyspace_range(self, min, max, exclusion=[], available=True):
        """
        Creates a keyspace range for CSA
        :param min: <int> keyspace range min
        :param max: <int> keyspace range max
        :param exclusion: <list> list of excluded keyspace ranges
        :param available: <boolean> T or F for status available
        :return: <request> response from POST
        """
        keyspace_range = {}
        resp = self.request_create_keyspace_range(max=max, min=min, exclusion=exclusion, available=available)
        return self.get_json_response(response=resp)

    def request_update_keyspace_range(self, keyspace_range):
        """
        Request to update a keyspace range
        :param keyspace_range: <dict> of the keyspace range object
        :return: <requests> response from PUT
        """
        url = "%s/%s" % (self.get_baseurl(), keyspace_range["id"])
        return self.session.put(url, data=keyspace_range)

    def update_keyspace_range(self, keyspace_range):
        """
        Update keyspace ramge
        :param keyspace_range: <dict> keyspace range object to update
        :return: <dict> updated keyspace range if successful otherwise empty
        """
        resp = self.request_update_keyspace_range(keyspace_range=keyspace_range)
        return self.get_json_response(response=resp)

    def request_delete_keyspace_range(self, keyspace_range):
        """
        Request to delete a keyspace range
        :param keyspace_range: <dict> keyspace range to delete
        :return: <requests> response from DELETE
        """
        url = "%s/%s" % (self.get_baseurl(), keyspace_range["id"])
        return self.session.delete(url)

    def delete_keyspace_range(self, keyspace_range):
        """
        Delete a keyspace range
        :param keyspace_range: <dict> keyspace range to delete
        :return: <boolean> T if successful otherwise F
        """
        resp = self.request_delete_keyspace_range(keyspace_range=keyspace_range)
        return self.get_bool_response(response=resp)
