from pydashboard.pydashboard.base import Base


class Users(Base):
    """
    This class allows you to add / edit / delete users for a specific tenant
    """

    SCHEMA_CORE = "urn:scim:schemas:core:1.0"
    SCHEMA_EXTENSION_IONIC = "urn:scim:schemas:extension:ionic:1.0"
    SCHEMA_EXTENSION_ENTERPRISE = "urn:scim:schemas:extension:enterprise:1.0"
    SCIM2_PATCH = "urn:ietf:params:scim:api:messages:2.0:PatchOp"
    DEFAULT_LIMIT = 100
    DEFAULT_PARAMS = {
        "asc": True,
        "limit": 100,
        "orderBy": "last_name",
        "skip": 0
        }

    SCIM_ACCESS = "scim_access"
    APPLICATION_MANAGER = "application_manager"
    TENANT_ADMIN = "tenant_admin"
    DASHBOARD_READ = "dashboard_read"
    POLICY_MANAGER = "policy_manager"
    USER_MANAGER = "user_manager"
    ROLE_MANAGER = "role_manager"
    USER = "user"
    CUSTOMER_SUPPORT_ADMIN = "customer_support_admin"

    VALID_ROLES = [
        SCIM_ACCESS,
        APPLICATION_MANAGER,
        TENANT_ADMIN,
        DASHBOARD_READ,
        POLICY_MANAGER,
        USER_MANAGER,
        ROLE_MANAGER,
        USER,
        CUSTOMER_SUPPORT_ADMIN,
    ]

    def __init__(self, apiuser, tenantid, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        :param refresh_on_init: <boolean> Whether to refresh data policies upon initialization
        :return:
        """
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.users_full = {}
        self.users = []
        self.users_by_username = {}
        self.scim_version = "1"

        if refresh_on_init:
            self.refresh()

    def refresh(self):
        self.users_full = self.get_users()
        self.users = self.users_full.get("Resources")
        self.users_by_username = self.get_users_by_email()

    def set_scim_version(self, version):
        if not isinstance(version, str):
            raise Exception("Version must be a string")
        else:
            self.scim_version = version

    def get_baseurl(self):
        return "%s/%s/scim/v%s/Users" % (
            self.resource_url,
            self.tenantid,
            self.scim_version,
        )

    def get_api_user_baseurl(self):
        return "%s/%s/api-users" % (self.resource_url, self.tenantid)

    def get_baseurl2(self):
        return "%s/%s/scim/Users" % (self.resource_url, self.tenantid)

    ##########################
    #
    #  GET USER RESOURCES
    #
    ##########################

    def request_get_users(self, params=None, method="POST", search=False):
        """
        Retrieve users
        :param params: additional options to append to the query
        :param method: <str> request type
        :param search: <boolean> indicate to use /.search in url for POST request
        :return: <requests> response from requests
        """
        if method == "POST":
            if params is None:
                params = self.DEFAULT_PARAMS
            if search:
                url = "%s/.search" % self.get_baseurl()
            else:
                url = "%s/list" % self.get_baseurl()
            return self.session.post(url=url, data=params)
        else:
            url = self.get_baseurl()
            return self.session.get(url=url, params=params)

    def get_users(self, params=None, method="POST", search=False):
        """
        Retrieve users
        :return: <dict> users if successful otherwise empty
        """
        response = self.request_get_users(params=params, method=method, search=search)
        return self.get_json_response(response=response)

    def request_get_user(self, user, params=None):
        """
        Retrieve user
        :param user: <dict> user
        :param params: optional params
        :return: <requests> response from GET
        """
        url = "%s/%s" % (self.get_baseurl(), user["id"])
        return self.session.get(url, params=params)

    def get_user(self, user, params=None):
        """
        Retrieve user
        :param user: <dict> user
        :param params: optional params
        :return: <dict> User if successful otherwise empty
        """
        response = self.request_get_user(user=user, params=params)
        return self.get_json_response(response=response)

    def request_get_user_groups(self, user, params=None, method="POST"):
        """
        Retrieve user groups
        :param user: <dict> user
        :return: <requests> response from POST
        """
        if method == "POST":
            url = "%s/%s/groups/list" % (self.get_baseurl(), user["id"])
            return self.session.post(url, data=params)
        else:
            url = "%s/%s/groups" % (self.get_baseurl(), user["id"])
            return self.session.get(url, params=params)

    def get_user_groups(self, user, params=None, method="POST"):
        """
        Retrieve user groups
        :param user: <dict> user
        :return: <dict> groups if successful otherwise empty 
        """
        response = self.request_get_user_groups(user=user, params=params, method=method)
        return self.get_json_response(response=response)

    def get_users_by_email(self):
        """
        Retrieve users by email
        :return: <dict> users with the email as KEY if successful otherwise empty
        """
        users_by_email = {}
        try:
            self.users = self.get_users()["Resources"]
        except KeyError:
            return users_by_email
        for each_user in self.users:
            try:
                users_by_email[each_user["emails"][0]["value"]] = each_user
            except (IndexError, KeyError):
                continue

        return users_by_email

    def get_users_by_username(self):
        """
        Retrieve users by username
        :return: <dict> users with the username as KEY if successful otherwise empty
        """
        users_by_username = {}
        try:
            self.users = self.get_users()["Resources"]
        except KeyError:
            return users_by_username
        users_without_username = 0
        for each_user in self.users:
            if each_user["userName"]:
                users_by_username[each_user["userName"]] = each_user
            else:
                users_without_username += 1
        return users_by_username

    def get_primary_email(self, user):
        try:
            email = user["emails"][0]["value"]
            return email
        except:
            return None

    def get_domainupn(self, user):
        return user[self.SCHEMA_EXTENSION_IONIC]["domainUpn"]

    # def request_all_deleted_users(self, limit=0):
    #     """
    #     Request all Deleted Users
    #     :param limit: <int> number of users to r
    #     :return:
    #     """
    #     return self.request_all_users(limit=limit, options=["showDeleted=True"])
    #
    # def get_all_deleted_users(self, limit=0):
    #     response = self.request_all_deleted_users(limit=limit)
    #     return self.get_json_response(response=response)

    # def find_user(self, email):
    #     return self.users_by_email[email.lower()]

    def request_update_user(self, user):
        """
        Update a user
        :param user: <dict> user to update
        :return: <requests> response from PUT
        """
        url = "%s/%s" % (self.get_baseurl(), user["id"])
        return self.session.put(url, data=user)

    def update_user(self, user):
        """
        Update a user
        :param user: <dict> user to update
        :return: <dict> updated user if successful otherwise empty
        """
        response = self.request_update_user(user=user)
        return self.get_json_response(response=response)

    def request_update_user2(self, user):
        """
        Update a user to PUT /scim/Users, see POLICY_6747
        :param user: can accept either single object or body array requests
        :return:
        """
        url = "%s" % (self.get_baseurl2())
        return self.session.put(url, data=user)

    def request_update_user_patch(self, user, operations=[]):
        """
        Update User
        :param user: <dict> user to update
        :param operations: <list> operations for scim 2
        :return: <requests> response from Patch
        """
        if self.scim_version == "2":
            url = "%s/%s" % (self.get_baseurl(), user["id"])
            payload = {"schemas": [self.SCIM2_PATCH]}
            payload["Operations"] = operations
            return self.session.patch(url=url, data=payload)
        else:
            raise Exception("SCIM 2 operation only. Set scim version to 2")

    def update_user_patch(self, user, operations=[]):
        """
        Update User
        :param user: <dict> user to update
        :param operations: <list> operations for scim 2
        :return: <boolean> True if update successful, otherwise False
        """
        response = self.request_update_user_patch(user=user, operations=operations)
        return self.get_bool_response(response=response)

    def request_user_managed_resources(self, user, method="POST"):
        """
        Retrieve resources being managed by a user
        :param user: <dict> user
        :return: <requests> response from POST
        """
        if method == "POST":
            url = "%s/%s/permitted-resources/list" % (self.get_baseurl(), user["id"])
            params = {
                "limit": 100,
                "skip": 0,
                "orderBy": "resource",
                "asc": True,
                "userId": user["id"]
            }
            return self.session.post(url, data=params)
        else:
            url = "%s/%s/permitted-resources" % (self.get_baseurl(), user["id"])
            return self.session.get(url)

    def get_user_managed_resources(self, user):
        """
        Retrieve resources being managed by a user
        :param user: <dict> user
        :return: <dict> resources if successful otherwise empty
        """
        response = self.request_user_managed_resources(user=user)
        return self.get_json_response(response=response)

    def request_user_history(self):
        """
        Retrieve all user history
        :return: <requests> response from POST
        """
        url = "%s/history/list" % self.get_baseurl()
        params = {
            "limit": 20,
            "skip": 0,
            "orderBy": "_createdTs",
            "asc": False
        }
        return self.session.post(url=url, data=params)

    def get_user_history(self):
        """
        Retrieve all user history
        :return: <dict> users history if successful otherwise empty
        """
        response = self.request_user_history()
        return self.get_json_response(response=response)

    def request_get_user_activity_log(self, user, method="POST", params=None):
        """
        Retrieve user activity logs
        :return: <requests> response from POST
        """
        url = "{baseurl}/{userid}/activity-logs".format(baseurl=self.get_baseurl(), userid=user["id"])
        if method == "POST":
            url = "{url}/list".format(url=url)
            return self.session.post(url=url, data=params)
        else:
            return self.session.get(url=url, params=params)

    def get_user_activity_log(self, user, method="POST", params=None):
        """
        Retrieve all user activity
        :return: <dict> users activity if successful otherwise empty
        """
        response = self.request_get_user_activity_log(user=user, method=method, params=params)
        return self.get_json_response(response=response)

    def request_user_history_with_id(self, userid):
        """
        Retrieve user history
        :param userid: user ID
        :return: <requests> response from POST
        """
        url = "%s/%s/history/list" % (self.get_baseurl(), userid)
        params = {
            "limit": 20,
            "skip": 0,
            "orderBy": "_createdTs",
            "asc": False
        }
        return self.session.post(url=url, data=params)

    def get_user_history_with_id(self, userid):
        """
        Retrieve user history
        :return: <dict> user history if successful otherwise empty
        """
        response = self.request_user_history_with_id(userid=userid)
        return self.get_json_response(response=response)

    ########################################
    #
    #  CREATE, UPDATE, & DELETE OPERATIONS
    #
    ########################################

    def request_create_api_user(self, userName, password):
        payload = {"userName": userName, "password": password}
        return self.session.post(url=self.get_api_user_baseurl(), data=payload)

    def create_api_user(self, userName, password):
        response = self.request_create_api_user(userName=userName, password=password)
        return self.get_json_response(response=response)

    def make_user_json(
            self,
            firstname="",
            lastname="",
            emails=[],
            domainUpn="",
            userName="",
            mergeby="none",
            acct_type=[],
            externalid="",
            groupids=[],
            employee_number="",
            manager_id="",
            manager_name="",
            department="",
            division="",
            organization="",
            cost_center="",
            subject_attributes=[],
    ):
        """
        Create request body to create user
        :param firstname: <str> first name
        :param lastname: <str< last name
        :param emails: <list> list of emails
        :param domainUpn: <str> domain UPN
        :param userName: <str> username
        :param mergeby: <str> mergeby field
        :param acct_type: <list> user role
        :param externalid: <str> external ID
        :param groupids: <list> list of group id's to add user to
        :param employee_number: <str> employee number
        :param manager_id: <str> manager id
        :param manager_name: <str> manager name
        :param department: <str> department
        :param division: <str> division
        :param organization: <str> organization
        :param cost_center: <str> cost center
        :param subject_attributes: <tuple> tuple [(type, value), (type2, value2)]
        :return: <dict> request body for create user
        """
        roles = []
        for each_acct_type in acct_type:
            # assert each_acct_type in self.VALID_ROLES, "%s is not a valid user role" % each_acct_type
            roles_inner = {}
            roles_inner["value"] = each_acct_type
            roles.append(roles_inner)

        schema_ionic = {"groups": []}
        for each_group_id in groupids:
            schema_ionic["groups"].append({"type": "group", "value": each_group_id})
        if domainUpn:
            schema_ionic["domainUpn"] = domainUpn
        if mergeby:
            schema_ionic["mergeBy"] = mergeby
        subAttr = []
        if subject_attributes:
            for each in subject_attributes:
                inner = {"type": each[0], "value": each[1]}
                subAttr.append(inner)
            schema_ionic["subjectAttributes"] = subAttr

        schema_enterprise = {}
        if employee_number:
            schema_enterprise["employeeNumber"] = employee_number
        if manager_id or manager_name:
            schema_enterprise["manager"] = {}
            if manager_id:
                schema_enterprise["manager"]["value"] = manager_id
            if manager_name:
                schema_enterprise["manager"]["display"] = manager_name
        if department:
            schema_enterprise["department"] = department
        if division:
            schema_enterprise["division"] = division
        if organization:
            schema_enterprise["organization"] = organization
        if cost_center:
            schema_enterprise["costCenter"] = cost_center

        payload = {
            "schemas": [
                self.SCHEMA_CORE,
                self.SCHEMA_EXTENSION_IONIC,
                self.SCHEMA_EXTENSION_ENTERPRISE,
            ],
            "name": {
                "givenName": firstname,
                "familyName": lastname,
                "formatted": (firstname + " " + lastname).strip(),
            },
            "emails": emails,
            "roles": roles,
            self.SCHEMA_EXTENSION_IONIC: schema_ionic,
            self.SCHEMA_EXTENSION_ENTERPRISE: schema_enterprise,
        }
        if externalid:
            payload["externalId"] = externalid
        if userName:
            payload["userName"] = userName
        return payload

    def request_create_user(
            self,
            firstname="",
            lastname="",
            emails=[],
            domainUpn="",
            userName="",
            mergeby="none",
            acct_type=[],
            externalid="",
            groupids=[],
            employee_number="",
            manager_id="",
            manager_name="",
            department="",
            division="",
            organization="",
            cost_center="",
            subject_attributes=[],
    ):
        """
        Request to create user
        :param firstname: <str> first name
        :param lastname: <str> last name
        :param emails: <list> list of <dict>emails e.g. [{value:"<email>"}]
        :param domainUpn: <str> domain UPN
        :param userName: <str> username
        :param mergeby: <str> mergeby field
        :param acct_type: <list> user role
        :param externalid: <str> external ID
        :param groupids: <list> list of group id's to add user to
        :param employee_number: <str> employee number
        :param manager_id: <str> manager id
        :param manager_name: <str> manager name
        :param department: <str> department
        :param division: <str> division
        :param organization: <str> organization
        :param cost_center: <str> cost center
        :param subject_attributes: <tuple> tuple [(type, value), (type2, value2)]
        :return: <requests> response from POST
        """
        payload = self.make_user_json(
            firstname=firstname,
            lastname=lastname,
            emails=emails,
            domainUpn=domainUpn,
            userName=userName,
            mergeby=mergeby,
            acct_type=acct_type,
            externalid=externalid,
            groupids=groupids,
            employee_number=employee_number,
            manager_id=manager_id,
            manager_name=manager_name,
            department=department,
            division=division,
            organization=organization,
            cost_center=cost_center,
            subject_attributes=subject_attributes,
        )
        return self.session.post(url=self.get_baseurl(), data=payload)

    def create_user(
            self,
            firstname="",
            lastname="",
            emails=[],
            domainUpn="",
            userName="",
            mergeby="none",
            acct_type=[],
            externalid="",
            groupids=[],
            employee_number="",
            manager_id="",
            manager_name="",
            department="",
            division="",
            organization="",
            cost_center="",
            subject_attributes=[],
    ):
        """
        Create user
        :param firstname: <str> first name
        :param lastname: <str> last name
        :param emails: <list> list of <dict>emails e.g. [{value:"<email>"}]
        :param domainUpn: <str> domain UPN
        :param userName: <str> username
        :param mergeby: <str> mergeby field
        :param acct_type: <list> user role
        :param externalid: <str> external ID
        :param groupids: <list> list of group id's to add user to
        :param employee_number: <str> employee number
        :param manager_id: <str> manager id
        :param manager_name: <str> manager name
        :param department: <str> department
        :param division: <str> division
        :param organization: <str> organization
        :param cost_center: <str> cost center
        :param subject_attributes: <tuple> tuple [(type, value), (type2, value2)]
        :return: <dict> user resource if successful, otherwise empty
        """
        response = self.request_create_user(
            firstname=firstname,
            lastname=lastname,
            emails=emails,
            domainUpn=domainUpn,
            userName=userName,
            mergeby=mergeby,
            acct_type=acct_type,
            externalid=externalid,
            groupids=groupids,
            employee_number=employee_number,
            manager_id=manager_id,
            manager_name=manager_name,
            department=department,
            division=division,
            organization=organization,
            cost_center=cost_center,
            subject_attributes=subject_attributes,
        )
        return self.get_json_response(response=response)

    def request_delete_user(self, user):
        """
        Delete user
        :param user: <dict> user to delete
        :return: <requests> response from DELETE
        """
        url = "%s/%s" % (self.get_baseurl(), user["id"])
        return self.session.delete(url)

    def delete_user(self, user):
        """
        Delete user
        :param user: <dict> user to delete
        :return: <boolean> True if deletion is successful other False
        """
        response = self.request_delete_user(user=user)
        return self.get_bool_response(response=response)

    def enable_user(self, user):
        """
        Enable a user
        :param user: <dict> user to enable
        :return: <dict> updated user
        """
        user["active"] = True
        return self.update_user(user=user)

    def disable_user(self, user):
        """
        Disable a user
        :param user: <dict> user to disable
        :return: <dict> updated user
        """
        user["active"] = False
        return self.update_user(user=user)

    ##########################
    #
    #  USER GROUPS
    #
    ##########################

    def get_group_ids_from_user(self, user):
        """
        Retrieve group Ids associated with the user
        :param user: <dict> user to get the group IDs from
        :return: <list> Group IDs
        """
        groupids = []
        if "groups" in user:
            for each_group in user["groups"]:
                groupids.append(each_group["value"])
        return groupids

    def request_add_groups_to_user(self, user, groups):
        """
        Add @groups to the @user
        :param user: <dict> uer to add groups to
        :param groups: <list> of <dict> groups to add to user
        :return: <requests> response from PUT
        """
        current_group_ids = self.get_group_ids_from_user(user=user)
        group_ids = []
        for each_grp in groups:
            group_ids.append(each_grp["id"])
        user[self.SCHEMA_EXTENSION_IONIC]["groups"] = []
        for each_group_id in set(current_group_ids + group_ids):
            user[self.SCHEMA_EXTENSION_IONIC]["groups"].append({"type": "group", "value": each_group_id})
        return self.request_update_user(user=user)

    def add_groups_to_user(self, user, groups):
        """
        Add @groups to the @user
        :param user: <dict> user to add groups to
        :param groups: <list> of <dict> groups to add to user
        :return: <dict> updated user
        """
        response = self.request_add_groups_to_user(user=user, groups=groups)
        return self.get_json_response(response=response)

    def remove_groups_from_user(self, user, groups):
        """
        Add @groups to the @user
        :param user: <dict> user to add groups to
        :param groups: <dict> groups to add to user
        :return: <dict> updated user
        """
        current_group_ids = self.get_group_ids_from_user(user=user)
        group_ids = []
        for each_grp in groups:
            group_ids.append(each_grp["id"])
        new_groups = set(current_group_ids) - set(group_ids)
        user[self.SCHEMA_EXTENSION_IONIC]["groups"] = []
        for each_group_id in new_groups:
            user[self.SCHEMA_EXTENSION_IONIC]["groups"].append({"type": "group", "value": each_group_id})
        return self.update_user(user=user)

    def remove_all_groups_from_user(self, user):
        """
        Remote all groups from user
        :param user: <dict> user to remove groups from
        :return: <dict> updated user
        """
        user[self.SCHEMA_EXTENSION_IONIC]["groups"] = []
        return self.update_user(user=user)

    ##########################
    #
    #  LOGIN & EMAIL HISTORY
    #
    ##########################

    def request_get_user_login_history(self, params=None):
        url = "%s/login-history/list" % (self.get_baseurl())
        default_params = {"asc": True, "limit": 100, "skip": 0}
        params = self.get_params(params=params, desired_params=default_params)
        return self.session.post(url=url, data=params)

    def get_user_login_history(self, params=None):
        """
        Retrieve user login history
        :return: <dict> user login history if successful otherwise empty
        """
        response = self.request_get_user_login_history(params=params)
        return self.get_json_response(response=response)

    def request_get_user_email_history(self, params=None):
        default_params = {"asc": True, "limit": 100, "skip": 0}
        params = self.get_params(params=params, desired_params=default_params)
        url = "%s/emails/list" % (self.get_baseurl())
        return self.session.post(url=url, should_wait=False, data=params)

    def request_get_user_id_email_history(self, user_id, params=None):
        url = "%s/%s/emails/list" % (self.get_baseurl(), user_id)
        default_params = {"asc": True, "limit": 100, "skip": 0}
        params = self.get_params(params=params, desired_params=default_params)
        return self.session.post(url=url, data=params)

    def get_user_email_history(self, params=None):
        """
        Retrieve user email history
        :return: <dict> user email history if successful otherwise empty
        """
        response = self.request_get_user_email_history(params=params)
        return self.get_json_response(response=response)

    def get_user_id_email_history(self, user_id, params=None):
        """
        Retrieve user email history
        :return: <dict> user email history if successful otherwise empty
        """
        response = self.request_get_user_id_email_history(user_id=user_id, params=params)
        return self.get_json_response(response=response)

    ##########################
    #
    #  IMPORT
    #
    ##########################

    def request_get_user_import_history(self, params=None):
        url = "%s/%s/scim/import-summaries/list" % (self.resource_url, self.tenantid)
        default_params = {
            "activity": "csvFileImport",
            "asc": True,
            "limit": 100,
            "skip": 0
        }
        params = self.get_params(params=params, desired_params=default_params)
        return self.session.post(url=url, should_wait=False, data=params)

    def get_user_import_history(self, params=None):
        """
        Retrieve user import history
        :return: <dict> user import history if successful otherwise empty
        """
        response = self.request_get_user_import_history(params=params)
        return self.get_json_response(response=response)

    ##########################
    #
    #  API KEYS
    #
    ##########################

    def request_create_api_key(self, user, name, scopes=[]):
        """
        Create API Key for user
        :param user: <dict> user to create key for
        :param name: <string> key name
        :param scopes: <list> list of scopes
        :return: <request> response from POST
        """
        url = "%s/%s/apikeys" % (self.get_baseurl(), user["id"])
        payload = {"name": name}
        if scopes:
            payload["scopes"] = scopes

        return self.session.post(url, data=payload)

    def create_api_key(self, user, name, scopes=[]):
        """
        Create API Key for user
        :param user: <dict> user to create key for
        :param name: <string>
        :param scopes: <list> list of scopes
        :return: <dict> created key if successful, otherwise empty
        """
        response = self.request_create_api_key(user=user, name=name, scopes=scopes)
        return self.get_json_response(response=response)

    def request_get_all_api_keys(self, params=None):
        """
        List All API Keys for tenant
        :return: <requests> response from POST
        """
        url = "%s/apikeys/list" % self.get_baseurl()
        return self.session.post(url=url, data=params)

    def get_all_api_keys(self, params=None):
        """
        List All API Keys for tenant
        :return: <dict> all api keys
        """
        response = self.request_get_all_api_keys(params=params)
        return self.get_json_response(response=response)

    def request_get_api_keys(self, user, method="POST", search=False):
        """
        Get all API keys for user
        :param user: <dict> user
        :param method: <string> request method
        :return: <requests> response from request
        """
        if method == "POST":
            if search:
                url = "%s/%s/apikeys/.search" % (self.get_baseurl(), user["id"])
            else:
                url = "%s/%s/apikeys/list" % (self.get_baseurl(), user["id"])
            params = {
                "limit": 100,
                "skip": 0,
                "asc": True,
                "userId": user["id"]
            }
            return self.session.post(url, data=params)
        else:
            url = "%s/%s/apikeys" % (self.get_baseurl(), user["id"])
            params = {
                "limit": 100,
                "skip": 0,
                "asc": True,
                "userId": user["id"]
            }
            return self.session.get(url, params=params)

    def get_api_keys(self, user, method="POST"):
        """
        Get all API keys for user
        :param user: <dict> user
        :return: <dict> api keys if successful, otherwise empty
        """
        response = self.request_get_api_keys(user=user, method=method)
        return self.get_json_response(response=response)

    def request_get_api_key_by_id(self, api_key):
        """
        Get API Key by ID
        :param api_key: <dict> API Key
        :return: <requests> response from GET
        """
        url = "%s/%s/apikeys/%s" % (
            self.get_baseurl(),
            api_key["userId"],
            api_key["id"],
        )
        return self.session.get(url)

    def get_api_key_by_id(self, api_key):
        """
        Get API Key by ID
        :param api_key: <dict> API Key
        :return: <dict> api key if successful, otherwise empty
        """
        response = self.request_get_api_key_by_id(api_key=api_key)
        return self.get_json_response(response=response)

    def request_get_api_key_access_logs(self, user, params=None):
        """
        Get API Keys Access logs
        :param: <dict> user
        :params: <dict> optional params
        :return: <requests> response from POST
        """
        url = "%s/%s/apikeys/access-logs/list" % (self.get_baseurl(), user["id"])
        if params is None:
            params = {"limit": 20, "skip": 0, "orderBy": "_createdTs", "asc": False}
        return self.session.post(url, data=params)

    def get_api_key_access_logs(self, user, params=None):
        """
        Get API Keys Access logs
        :param user: <dict> user
        :param params: <dict> optional params
        :return: <dict> api key access logs
        """
        response = self.request_get_api_key_access_logs(user=user, params=params)
        return self.get_json_response(response=response)

    def request_update_api_key(self, api_key):
        """
        Update API Key
        :param api_key: <dict> API Key 
        :return: <requests> response from PUT
        """
        url = "%s/%s/apikeys/%s" % (
            self.get_baseurl(),
            api_key["userId"],
            api_key["id"],
        )
        return self.session.put(url, data=api_key)

    def update_api_key(self, api_key):
        """
        Update API Key
        :param api_key: <dict> API Key 
        :return: <dict> updated api key if successful, otherwise empty
        """
        response = self.request_update_api_key(api_key=api_key)
        return self.get_json_response(response=response)

    def request_delete_api_key(self, api_key):
        """
        Delete API Key
        :param api_key: <dict> API Key
        :return: <requests> response from DELETE 
        """
        url = "%s/%s/apikeys/%s" % (
            self.get_baseurl(),
            api_key["userId"],
            api_key["id"],
        )
        return self.session.delete(url)

    def delete_api_key(self, api_key):
        """
        Delete API Key
        :param api_key: <dict> API Key 
        :return: <bool> True if successful, otherwise False
        """
        response = self.request_delete_api_key(api_key=api_key)
        return self.get_bool_response(response=response)

    def request_reset_secret_api_key(self, api_key):
        """
        Reset Secret for API key
        :param api_key: <dict> API Key
        :return: <requests> response from PUT
        """
        url = "%s/%s/apikeys/%s/reset-secret" % (
            self.get_baseurl(),
            api_key["userId"],
            api_key["id"],
        )
        return self.session.put(url, data=api_key)

    def reset_secret_api_key(self, api_key):
        """
        Reset Secret for API Key
        :param api_key: <dict> API Key
        :return: <dict> updated API Key if successful, otherwise empty
        """
        response = self.request_reset_secret_api_key(api_key=api_key)
        return self.get_json_response(response=response)

    ##########################
    #
    #  DEVICES
    #
    ##########################

    def request_get_user_devices(self, user, method="POST", params=None, search=False):
        """
        Get User's devices
        :param user: <dict> user resource
        :param method: <str> request method
        :param params: optional params
        :param search: <boolean> indicate to use /.search in url for POST request
        :return: <requests> response from request
        """
        url = "{base_url}/{id}/devices".format(base_url=self.get_baseurl(), id=user["id"])
        if method == "POST":
            if search:
                url = "{url}/.search".format(url=url)
            else:
                url = "{url}/list".format(url=url)
            return self.session.post(url=url, data=params)
        else:
            return self.session.get(url=url, params=params)

    def get_user_devices(self, user, method="POST", params=None, search=False):
        """
        Get User's devices
        :param user: <dict> user resource
        :param method: <str> request method
        :param params: optional params
        :param search: <boolean> indicate to use /.search in url for POST request
        :return: <dict> user's devices
        """
        response = self.request_get_user_devices(user=user, method=method, params=params, search=search)
        return self.get_json_response(response=response)

    ##########################
    #
    #  VERIFY EMAIL
    #
    ##########################

    def request_send_email_verification(self, email):
        """
        Send request to send email verification
        :param email: <str> email address to send verification email
        :return: <requests> response from POST
        """
        url = "{}/{}/verify-email/send".format(self.resource_url, self.tenantid)
        data = {"email": email}
        return self.session.post(url=url, data=data)

    def send_email_verification(self, email):
        """
        Send request to send email verification
        :param email: <str> email address to verify
        :return: <bool> True if successful, otherwise False
        """
        response = self.request_send_email_verification(email=email)
        return self.get_bool_response(response=response)

    def request_verify_email(self, email, code):
        """
        Send request to verify email
        :param email: <str> email address to verify
        :param code: <str> code in email
        :return: <requests> response from POST
        """
        url = "{}/{}/verify-email".format(self.resource_url, self.tenantid)
        data = {"email": email, "code": code}
        return self.session.post(url=url, data=data)

    def verify_email(self, email, code):
        """
        Send request to verify email
        :param email: <str> email address to verify
        :param code: <str> code in email
        :return: <bool> True if successful, otherwise False
        """
        response = self.request_verify_email(email=email, code=code)
        return self.get_bool_response(response=response)

    def request_send_email_verification_to_user(self, email, user):
        """
        Send request to send email verification to user
        :param email: <str> email address to send verification email
        :return: <requests> response from POST
        """
        url = "{}/{}/verify-email/send".format(self.get_baseurl(), user["id"])
        data = {"email": email}
        return self.session.post(url=url, data=data)

    def send_email_verification_to_user(self, email, user):
        """
        Send request to send email verification to user
        :param email: <str> email address to send verification email
        :return: <bool> True if successful, otherwise False
        """
        response = self.request_send_email_verification_to_user(email=email, user=user)
        return self.get_bool_response(response=response)

    ##########################
    #
    #  /Me alias
    #  POLICY-6808
    #
    ##########################

    def request_get_user_me(self, params=None):
        """
        The /Me alias is a way to reference a user for the authenticated user
        without needing to know the ID of that resource.
        :param params:
        :return:
        """
        url = "{}/Me".format(self.get_baseurl())
        params = self.get_params(params=params, desired_params=self.DEFAULT_PARAMS)
        return self.session.get(url=url, params=params)

    def get_user_me(self, params=None):
        """
        The /Me alias is a way to reference a user for the authenticated user
        without needing to know the ID of that resource.
        :param params:
        :return:
        """
        response = self.request_get_user_me(params=params)
        return self.get_json_response(response=response)

    def request_update_user_me(self, user):
        """
        The /Me alias is a way to reference a user for the authenticated user
        without needing to know the ID of that resource.
        :param user: <dict> user object
        :return:
        """
        url = "{}/Me".format(self.get_baseurl())
        return self.session.put(url, data=user)

    def update_user_me(self, user):
        """
        The /Me alias is a way to reference a user for the authenticated user
        without needing to know the ID of that resource.
        :param user: <dict> user object
        :return:
        """
        response = self.request_update_user_me(user=user)
        return self.get_json_response(response=response)

    def request_update_user_patch_me(self, user, operations=[]):
        """
        The /Me alias is a way to reference a user for the authenticated user
        without needing to know the ID of that resource.
        :param user: <dict> user to update
        :param operations: <list> operations for scim 2
        :return: <requests> response from Patch
        """
        if self.scim_version == "2":
            url = "{}/Me".format(self.get_baseurl())
            payload = {"schemas": [self.SCIM2_PATCH]}
            payload["Operations"] = operations
            return self.session.patch(url=url, data=payload)
        else:
            raise Exception("SCIM 2 operation only. Set scim version to 2")

    def update_user_patch_me(self, user, operations=[]):
        """
        Update User
        :param user: <dict> user to update
        :param operations: <list> operations for scim 2
        :return: <boolean> True if update successful, otherwise False
        """
        response = self.request_update_user_patch_me(user=user, operations=operations)
        return self.get_bool_response(response=response)

    def request_delete_user_me(self, user):
        """
        Delete user
        :param user: <dict> user to delete
        :return: <requests> response from DELETE
        """
        url = "{}/Me".format(self.get_baseurl())
        return self.session.delete(url)

    def delete_user_me(self, user):
        """
        Delete user
        :param user: <dict> user to delete
        :return: <boolean> True if deletion is successful other False
        """
        response = self.request_delete_user_me(user=user)
        return self.get_bool_response(response=response)

    ##########################
    #
    # USER FEEDBACK
    #
    ##########################

    def request_submit_user_feedback(self, userid, message=None):
        """
        Submit user feedback
        :param message: feedback from the user
        :return: 204 No Content response
        """
        url = "{base_url}/{userid}/feedback".format(base_url=self.get_baseurl(), userid=userid)
        payload = dict(message=message)
        return self.session.post(url, data=payload)
