from pydashboard.pydashboard.base import Base
import warnings
import time


class ApplicationPolicies(Base):
    """
    Perform CRUD operations on Application Policies for a specific tenant
    """

    DEFAULT_POST_PARAMS = {
        "asc": True,
        "limit": 100,
        "orderBy": "name",
        "skip": 0
    }
    DEFAULT_GET_PARAMS = "asc=True&limit=0&orderBy=name&skip=0"

    def __init__(self, apiuser, tenantid, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        :param refresh_on_init: <boolean> Whether to refresh applications upon initialization
        :return:
        """
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url
        self.applications_full = {}  # Full response from GET /applications
        self.applications = []  # applications object from the FULL response
        self.applications_by_appuri = {}  # applications objects with appuri as key

        if refresh_on_init:
            self.refresh()

    def get_baseurl(self):
        return "%s/%s/applications" % (self.resource_url, self.tenantid)

    def refresh(self):
        """
        Retrieve the latest Application Policies configured
        :return: None
        """
        self.applications_full = self.get_applications()
        self.applications = self.applications_full.get("Resources")
        self.applications_by_appuri = self.get_applications_by_uri()


    ###############################
    #
    # LIST APPLICATIONS
    #
    ###############################

    def request_get_applications(self, params=None, method="POST", search=False):
        """
        :param params: <dict> optional paramaters such as asc
        :param method: <string> request method
        :param search: <boolean> indicate whether to use ./search in url for POST
        :return: <requests> response from the request
        """
        if method == "POST":
            params = self.get_params(params=params, desired_params=self.DEFAULT_POST_PARAMS)
            if search:
                url = "%s/.search" % self.get_baseurl()
            else:
                url = "%s/list" % self.get_baseurl()
            return self.session.post(url, data=params)
        else:
            url = self.get_baseurl()
            return self.session.get(url, params=params)

    def get_applications(self, params=None, method="POST", search=False):
        """
        :param params: <dict> optional paramaters such as asc
        :param method: <string> request method
        :param search: <boolean> indicate whether to use ./search in url for POST
        :return: <dict> all applications for tenant
        """
        time.sleep(1)
        response = self.request_get_applications(params=params, method=method, search=search)
        return self.get_json_response(response=response)

    def request_get_application(self, application, params=None):
        """
        Get Application
        :param application: <dict> application
        :param params: <dict> option params
        :return: <requests> response from request
        """

        url = "%s/%s" % (self.get_baseurl(), application["id"])
        params = self.get_params(params=params, desired_params=self.DEFAULT_GET_PARAMS)
        return self.session.get(url, params=params)

    def get_application(self, application, params=None):
        """
        Get Application
        :param application: <dict> application
        :param params: <dict> option params
        :return: <dict> Empty dict or the application with the param id
        """
        response = self.request_get_application(application=application, params=params)
        return self.get_json_response(response=response)

    def request_get_application_version(self, application, params=None):
        """
        Get Application version
        :param application: <dict> application
        :param params: <dict> option parameters like 'cache:False'
        :return: <dict> response from request
        """

        url = "%s/%s/version" % (self.get_baseurl(), application["id"])
        params = self.get_params(params=params, desired_params=self.DEFAULT_GET_PARAMS)
        return self.session.get(url, params=params)

    def get_application_version(self, application, params=None):
        """
        :param appid: application id
        :return: <dict> Empty dict or the application with the param id
        """
        response = self.request_get_application_version(application=application, params=params)
        return self.get_json_response(response=response)

    def get_applications_by_uri(self):
        """
        Iterate over applications and return a dict with the appuri as the key.
        :return: <dict> Application Payloads with 'appUri' as the key
        """
        apps_by_uri = {}
        for each_app in self.applications:
            apps_by_uri[each_app["appUri"]] = each_app
        return apps_by_uri

    def get_application_id(self, appuri):
        """
        :param appuri: <string> uri of the application that we want to obtain the ID for
        :return: <string> Returns the ID of the application if it is found, otherwise return empty string
        """
        appid = "COULD NOT FIND APPID"
        app = self.applications_by_appuri.get(appuri)
        if app:
            appid = app["id"]
        return appid

    #  Retrieve the policy version which a device would receive
    def request_version_in_effect(self, params=None):
        """
        :param params: dict optional parameters like 'cache:False'
        :return: object response from the request
        """
        url = self.get_baseurl() + "/version"
        params = self.get_params(params=params, desired_params=self.DEFAULT_GET_PARAMS)
        return self.session.get(url, params=params)

    def version_in_effect(self, params=None):
        """
        :return: <dict> Empty dict or the applications configured for the tenant
        """
        response = self.request_version_in_effect(params=params)
        return self.get_json_response(response=response)

    ###############################
    #
    #   CREATE APPLICATION
    #
    ###############################

    def make_json_obj(self, appname, appuri, appkbid, altappuri=None, description=None):
        if altappuri is None:
            altappuri = []
        payload = {
            "name": appname,
            "appUri": appuri,
            "kbId": appkbid,
            "altAppUri": altappuri,
        }
        if description is not None:
            payload["description"] = description
        return payload

    def request_create_application(self, appname, appuri, appkbid, altappuri=None, description=None):
        """
        Creates an application
        :param appname <string> name of the application
        :param appuri <string> unique appuri of the application
        :param appkbid <string> appkb ID for the appuri
        :param altappuri <string> Alternate Application URIs
        :param description <string> Description of the application
        :returns application <dict> Represents the application
        """
        url = "%s" % (self.get_baseurl())
        payload = self.make_json_obj(
            appname=appname,
            appuri=appuri,
            appkbid=appkbid,
            altappuri=altappuri,
            description=description,
        )
        return self.session.post(url, data=payload)

    def create_application(self, appname, appuri, appkbid, altappuri=None, description=None):
        """
        Creates an application
        :param appname <string> name of the application
        :param appuri <string> unique appuri of the application
        :param appkbid <string> appkb ID for the appuri
        :param altappuri <string> Alternate Application URIs
        :param description <string> Description of the application
        :returns application <dict> Represents the application or an empty dict
        """
        response = self.request_create_application(
            appname=appname,
            appuri=appuri,
            appkbid=appkbid,
            altappuri=altappuri,
            description=description,
        )
        return self.get_json_response(response=response)

    ###############################
    #
    #   UPDATE APPLICATION
    #
    ###############################

    def request_update_application(self, application):
        """
        Update Application with data defined in the @application
        :param application: <dict> represents the application to update
        :return:
        """
        url = "%s/%s" % (self.get_baseurl(), application["id"])
        return self.session.put(url, data=application)

    def update_application(self, application):
        """
        Update Application with data defined in the @application
        :param application: <dict> Represents the application to update
        :return: application
        """
        response = self.request_update_application(application=application)
        return self.get_json_response(response=response)

    def enable_application(self, application):
        """
        Change the status of an @application to enabled
        :param application: <dict> application to change status
        """
        application["enabled"] = True
        return self.update_application(application=application)

    def disable_application(self, application):
        """
        Change the status of an @application to disabled
        :param application: <dict> application to change status
        """
        application["enabled"] = False
        return self.update_application(application=application)

    ###############################
    #
    #   DELETE APPLICATION
    #
    ###############################

    def request_delete_application(self, application):
        """
        Deletes the provided @application
        :param application: <dict> Represents the application to delete
        """
        url = "%s/%s" % (self.get_baseurl(), application["id"])
        return self.session.delete(url)

    def delete_application(self, application):
        """
        Deletes the provided @application
        :param application: <dict> Represents the application to delete
        :return <boolean>: True if successful delete otherwise False
        """
        response = self.request_delete_application(application=application)
        return self.get_bool_response(response=response)

    ###############################
    #
    #   LIST APPLICATION GROUPS
    #
    ###############################

    GROUP_PARAMS = {
        "asc": True,
        "default": True,
        "limit": 100,
        "managedAppId": False,
        "skip": 0
    }

    def request_get_application_groups(self, application, params=None):
        """
        :param application: <dict> application that we want to obtain policy group information for
        :return: <requests> Returns all group settings if they are found
        For instance, if appuri is "jiveon.com" this request will return each policy group along with the ALLOW/DENY
        settings for all the groups for all the features of the application
        """
        url = "%s/%s/groups/list" % (self.get_baseurl(), application["id"])
        if params is None:
            params = self.GROUP_PARAMS
        if not params.get("managedAppId"):
            params["managedAppId"] = application["id"]
        return self.session.post(url, should_wait=False, data=params)

    def get_application_groups(self, application, params=None):
        """
        Gets all the policy groups configured for the @application
        :param application: <dict> application
        :return: <dict> Application Groups
        """
        response = self.request_get_application_groups(application=application, params=params)
        return self.get_json_response(response=response)

    def get_application_groups_by_name(self, application):
        """
        Gets all the policy groups by name configured for the application
        :param applicationL: <dict> application
        :return: <dict> Application Groups with the Application Group Name as the key
        """
        application_groups = {}
        # Get Default Group
        DEFAULT_GRP = self.GROUP_PARAMS
        DEFAULT_GRP["default"] = True
        application_groups_full = self.get_application_groups(application=application, params=DEFAULT_GRP)
        for each_app_grp in application_groups_full.get("Resources"):
            application_groups[each_app_grp["name"]] = each_app_grp
        OTHER_GRP = self.GROUP_PARAMS
        OTHER_GRP["default"] = False
        application_groups_full = self.get_application_groups(application=application, params=OTHER_GRP)
        for each_app_grp in application_groups_full.get("Resources"):
            application_groups[each_app_grp["name"]] = each_app_grp
        return application_groups

    ###############################
    #
    #   CREATE APPLICATION GROUP
    #
    ###############################

    def request_create_application_group(self, application, name, user_group_ids, desc="", tenantid=None):
        """
        Creates Policy Group for an Application
        :param application: <dict> application
        :param name: <string> name of the policy group application
        :param user_group_ids: <list> list of group IDs ['<grp_id1>', '<grp_id2'>]
        :param desc: <string> The description for the policy group
        :param tenantid: <string> Tenant Id
        :return: <requests> Return requests object for the application policy group creation
        """
        if tenantid is None:
            warnings.warn("The argument 'tenantid' was passed into the request to create application group \n"
                          "Defaulting to current authenticated user's tenant id: '{}'".format(self.tenantid))
            tenantid = self.tenantid
        url = "%s/%s/groups" % (self.get_baseurl(), application["id"])
        criteria_dict = dict(category="subject", operator="equals", property="group", values=user_group_ids)
        criteria = [criteria_dict]
        payload = dict(
            managedAppId=application["id"], tenantId=tenantid, name=name, description=desc, criteria=criteria)
        return self.session.post(url, data=payload)

    def create_application_group(self, application, name, user_group_ids, desc="", tenantid=None):
        """
        Create Policy Group for an @application
        :param application: <dict> application
        :param name: <string> name of the policy group application
        :param user_group_ids: <list> list of group IDs ['<grp_id1>', '<grp_id2'>]
        :param desc: <string> The description for the policy group
        :param tenantid: <string> Tenant Id
        :return: <dict> If successful return new application_group otherwise return empty dict
        """
        response = self.request_create_application_group(
            application=application, name=name, user_group_ids=user_group_ids, desc=desc)
        return self.get_json_response(response=response)

    ###############################
    #
    #   UPDATE APPLICATION GROUP
    #
    ###############################

    def request_update_application_group(self, application, application_group):
        """
        Update application group settings
        :param application: <dict> Application to update
        :param application_group: <dict> Application Group to update
        :return: <requests> Object for the update to the application_group
        """
        url = "%s/%s/groups/%s" % (
            self.get_baseurl(),
            application["id"],
            application_group["id"],
        )
        return self.session.put(url, data=application_group)

    def update_application_group(self, application, application_group):
        """
        Update Application Group
        :param application: <dict> Application to Update
        :param application_group: <dict> Application Group to Update
        :return: <dict> application group which was updated
        """
        response = self.request_update_application_group(application=application, application_group=application_group)
        return self.get_json_response(response=response)

    ###############################
    #
    #   DELETE APPLICATION GROUP
    #
    ###############################

    def request_delete_application_group(self, application, application_group):
        """
        Delete an application group
        :param application: <dict> Application which the group belongs to
        :param application_group: <dict> Application Group to delete
        :return: <requests> Object return from the deletion
        """
        url = "%s/%s/groups/%s" % (
            self.get_baseurl(),
            application["id"],
            application_group["id"],
        )
        return self.session.delete(url)

    def delete_application_group(self, application, application_group):
        """
        Delete an application group
        :param application: <dict> Application which the group belongs to
        :param application_group: <dict> Application Group to delete
        :return: <boolean> True if delete successful, False otherwise
        """
        response = self.request_delete_application_group(application=application, application_group=application_group)
        return self.get_bool_response(response=response)

    ###############################
    #
    #   LIST APPLICATION FEATURES
    #
    ###############################

    def request_get_application_features(self, application, params=None):
        """
        Obtain the features for an @application
        For instance, returns 'Site Access', 'File Upload' and other features which are available for the app
        :param application: <dict> application that we want to obtain the features for
        :return: <requests> request for features
        """
        url = "%s/%s/features/list" % (self.get_baseurl(), application["id"])
        if params is None:
            params = {"managedAppId": False}
        return self.session.post(url, should_wait=False, data=params)

    def get_application_features(self, application):
        """
        Obtain the features for an @application
        For instance, returns 'Site Access', 'File Upload' and other features which are available for the app
        :param application: <dict> application that we want to obtain the features for
        :return: <dict> If successful return features, otherwise empty
        """
        response = self.request_get_application_features(application=application)
        return self.get_json_response(response=response)

    def get_application_feature(self, application, feature_category, feature_name):
        """
        Returns the specific feature for a specific application
        :param application: <dict> The application of the application we wish to return
        :param feature_category: <string> The feature category such as Access / Download / Uploads
        :param feature_name: <string> The actual feature name such as
        'Site Access / Flash Object Download / Upload Video
        :return: <dict> The Feature settings
        """
        app_feature = {}
        for each_app_feature in self.get_application_features(application):
            if (each_app_feature["name"] == feature_name and each_app_feature["category"]["name"] == feature_category):
                app_feature = each_app_feature
                break
        return app_feature

    ###############################
    #
    #   CREATE APPLICATION FEATURE
    #
    ###############################

    def request_create_application_template_feature(self, application, values, name, ar_token, application_template,
                                                    message):
        """
        Request to create application template feature
        :param application: <dict> Application to create the feature.
        :param values: <dict> e.g. {'DM': ['DMValue', 'DMValue2'], 'DM2': ['DMValue', 'DMValue2']}
        :param name: <string> name of feature
        :param ar_token: <string> 4 digit AR Token
        :param application_template: <dict>  The 'function' type e.g. Temporary Test Template. JSON object for feature
        :param message: <string> optional customizations message
        :return: <dict> application_feature if successful otherwise empty
        """

        url = "%s/%s/features" % (self.get_baseurl(), application["id"])
        payload = {
            "name": name,
            "type": "CUSTOM",
            "function": application_template["id"],
            "customTokens": {
                "ar_test_policy_test_markings": {
                    "name": "ar_test_policy_test_markings",
                    "label": "AR Test Policy Markings Test Token",
                    "description": "A test token that with type Markings.",
                    "optional": True,
                    "type": "markings",
                    "value": "%s" % json.dumps(values),
                },
                "ar_test_policy_test_regex": {
                    "name": "ar_test_policy_test_regex",
                    "label": "AR Test Policy Regex Test Token",
                    "description": "A test token using a regex that validates against a four digit hex number.",
                    "regexValidator": "[0-9A-Fa-f]{4}",
                    "validationMessage": "Invalid entry. A four digit hex value is required.",
                    "value": ar_token,
                },
                "message": {
                    "name":
                    "message",
                    "label":
                    "Message",
                    "defaultValue":
                    "Certain features of this application have been removed or disabled in accordance with corporate policy.",
                    "optional":
                    True,
                },
            },
        }

        if message:
            payload["customTokens"]["message"]["value"] = message

        return self.session.post(url, data=payload)

    def create_application_template_feature(self, application, values, name, ar_token, application_template, message):
        """
        Create application template feature
        :param application: <dict> Application to create the feature.
        :param values: <dict> e.g. {'DM': ['DMValue', 'DMValue2'], 'DM2': ['DMValue', 'DMValue2']}
        :param name: <string> name of feature
        :param ar_token: <string> 4 digit AR Token
        :param application_template: <dict>  The 'function' type e.g. Temporary Test Template. JSON object for feature
        :param message: <string> optional customizations message
        :return: <dict> application_feature if successful otherwise empty
        """
        response = self.request_create_application_template_feature(
            application=application,
            values=values,
            name=name,
            ar_token=ar_token,
            application_template=application_template,
            message=message,
        )
        return self.get_json_response(response=response)

    def request_create_application_feature(
            self,
            application,
            application_template,
            name,
            feature_value,
            message="",
            tenantid=None,
    ):
        """
        Makes a CUSTOM application feature
        :param application: <dict> Application to create the feature.
        :param application_template: <dict> The 'function' type e.g. Block Request. JSON object for feature
        :param name: <string> name of the feature
        :param feature_value: <string> feature value depends on application_template. Maybe URL, or some other value
        :param message: <string> message for the application feature
        :return: <requests> response from the POST
        """
        url = "%s/%s/features" % (self.get_baseurl(), application["id"])

        # For now assume there is only 1 token
        template_token = application_template["tokens"][0]
        # for each_token in template_tokens:
        #     if feature_label == each_token["label"]:
        #         feature_token = each_token
        #         break

        payload = {
            "customTokens": {
                template_token["name"]: {
                    "value": feature_value
                }
            },
            "function": application_template["id"],
            # "managedAppId": application["id"],
            "message": message,
            "name": name,
            # "tenantId": self.get_tenant_id(tenantid=tenantid),
            "type": "CUSTOM",
        }
        return self.session.post(url, data=payload)

    def create_application_feature(
            self,
            application,
            application_template,
            name,
            feature_value,
            message="",
            tenantid=None,
    ):
        """
        Makes a CUSTOM application feature
        :param application: <dict> Application to create the feature.
        :param application_template: <dict> The 'function' type e.g. Block Request. JSON object for feature
        :param name: <string> name of the feature
        :param feature_value: <string> feature value depends on application_template. Maybe URL, or some other value
        :param message: <string> message for the application feature
        :return: <dict> application_feature if successful otherwise empty
        """
        response = self.request_create_application_feature(
            application=application,
            application_template=application_template,
            name=name,
            feature_value=feature_value,
            message=message,
            tenantid=tenantid,
        )
        return self.get_json_response(response=response)

    ###############################
    #
    #   UPDATE APPLICATION FEATURE
    #
    ###############################

    def request_update_application_feature(self, application, application_feature):
        """
        Update an Application Feature
        :param application: <dict> Application which the feature belongs to
        :param application_feature: <dict> application feature to update
        :return: <requests> object from the update
        """
        url = "%s/%s/features/%s" % (
            self.get_baseurl(),
            application["id"],
            application_feature["id"],
        )
        return self.session.put(url, data=application_feature)

    def update_application_feature(self, application, application_feature):
        """
        Update an Application Feature
        :param application: <dict> Application which the feature belongs to
        :param application_feature: <dict> application feature to update
        :return: <dict> updated application feature if successful, otherwise empty
        """
        response = self.request_update_application_feature(
            application=application, application_feature=application_feature)
        return self.get_json_response(response=response)

    ###############################
    #
    #   DELETE APPLICATION FEATURE
    #
    ###############################

    def request_delete_application_feature(self, application, application_feature):
        """
        Delete an application feature
        :param application: <dict> Application which the feature belongs to
        :param application_feature: <dict> application feature to delete
        :return: <requests> object from the deletion
        """
        url = "%s/%s/features/%s" % (
            self.get_baseurl(),
            application["id"],
            application_feature["id"],
        )
        return self.session.delete(url)

    def delete_application_feature(self, application, application_feature):
        """
        Delete an application feature
        :param application: <dict> Application which the feature belongs to
        :param application_feature: <dict> application feature to delete
        :return: <boolean> True if deletion successful, otherwise False
        """
        response = self.request_delete_application_feature(
            application=application, application_feature=application_feature)
        return self.get_bool_response(response=response)

    ########################################
    #
    #  LIST APP GROUP SETTINGS
    #
    ########################################

    def get_application_group_setting_for_feature(self, application, application_group, feature_category, feature_name):
        """
        Retrieve a settings for a specific feature
        :param application: <dict> Application which the feature belongs to
        :param application_group: <dict> Application Group which the feature belongs to
        :param feature_category: <string> Name of the feature category (e.g. Access)
        :param feature_name: <string> Name of the feature name (e.g. Site Access)
        :return: <dict> or None. Returns None if value could not be found, otherwise returns <dict> of the value
        """
        setting = None
        grp_name = application_group["name"]
        grp_settings = self.get_application_groups_by_name(application)
        application_feature = self.get_application_feature(
            application=application,
            feature_category=feature_category,
            feature_name=feature_name,
        )
        feature_id = application_feature["id"]
        # Make sure a value is set - Default is to leave everything UNCHECKED
        if feature_id in grp_settings[grp_name]["policies"]:
            setting = grp_settings[grp_name]["policies"][feature_id]
        return setting

    ###############################
    #
    #   UPDATE APP FOR GROUP
    #
    ###############################

    def request_update_application_for_group(self, application, application_group):
        """
        Update values for an application group
        :param application: <dict> application which the group belongs to
        :param application_group: <dict> application group settings to update
        :return: <requests> response from PUT
        """
        url = "%s/%s/groups/%s" % (
            self.get_baseurl(),
            application["id"],
            application_group["id"],
        )
        return self.session.put(url, data=application_group)

    def update_application_for_group(self, application, application_group, new_settings):
        """
        Updates a setting for a specific application, for a group.
        :param application: <dict> Application which the group belongs to.
        :param application_group: <dict> Application group settings to update.
        :param new_settings: <list> List of JSON objects which contain the new settings.
        e.g:
        new_settings = [
                {'category': 'Access', 'feature': 'Site Access', 'newvalue': 'DENY'},
                {'category': 'Uploads', 'feature': 'File Upload', 'newvalue': 'DENY'}]
        :return: <dict> Updated application group or empty.
        """

        # Get Group Feature settings for the application
        app_policy_group_name = application_group["name"]
        all_app_groups = self.get_application_groups_by_name(application=application)

        app_group = all_app_groups[app_policy_group_name]

        # Check to see if there are any settings for the group
        if app_group == {}:
            app_group["policies"] = {}
        if app_group["policies"] is None:
            app_group["policies"] = {}

        for each_new_setting in new_settings:
            feature_category = each_new_setting["category"]
            feature_name = each_new_setting["feature"]
            app_feature = self.get_application_feature(
                application=application,
                feature_category=feature_category,
                feature_name=feature_name,
            )

            if app_feature.get("states") is None:
                msg_bad_feature = "Invalid feature '{0}' in category '{1}'".format(feature_name, feature_category)
                raise Exception(msg_bad_feature)

            # Add the 'DEFAULT' state as an allowable state, if a custom policy
            # group is provided
            if app_policy_group_name != "Policy for All Users":
                app_feature["states"].append("DEFAULT")
            # Check to see if the new value setting is a valid state
            if each_new_setting["newvalue"] not in app_feature["states"]:
                raise Exception(
                    "%s is not a valid state. Expected %s" % (each_new_setting["newvalue"], app_feature["states"]))

            # Check to see if the setting is already defined - if it is change the value
            # If it isn't then we need to add that value to the json object
            if [app_feature["id"]] in list(app_group["policies"].keys()):
                app_group["policies"][app_feature["id"]]["state"] = each_new_setting["newvalue"]
            else:
                app_group["policies"][app_feature["id"]] = {
                    "featureType": app_feature["type"],
                    "featureId": app_feature["id"],
                    "state": each_new_setting["newvalue"],
                }

        response = self.request_update_application_for_group(application=application, application_group=app_group)
        return self.get_json_response(response=response)

    ###############################
    #
    #   SET FEATURES
    #
    ###############################

    def set_all_features(self, application, group_name="Policy for All Users", state="DENY"):
        """
        Sets all the features of an application to a default state. 

        :Args:
          :param application - <dict> application which the group belongs to
          :param group_name - <dict> application group settings to update
          :param state - <string> Sets the feature to Deny|Allow

        :Gotchas:
          I have to compare the index name value against Site access so I can 
          still access the page. The _Login_ value comes from JSFiddle since
          it has a policy not only to block JSFiddle but also to login...
        
        :Example:
          application = 'jsfiddle.net'
          response = self.set_all_features(self, application)

        :Returns:
          The command's JSON response into a dictionary object
        """
        app_features = self.get_application_features(application)
        app_group = self.get_application_groups_by_name(application)
        features = []
        for index in app_features:
            if (index["name"] != "Site Access" and index["name"] != "Login" and state in index["states"]):
                feature = {}
                feature[u"category"] = index["category"]["name"]
                feature[u"feature"] = index["name"]
                feature[u"newvalue"] = state
                features.append(feature)
        response = self.update_application_for_group(application, app_group[group_name], features)
        return response

    ###############################
    #
    #   LIST APPLICATION EXCEPTIONS
    #
    ###############################

    def request_application_exceptions(self, application, application_group, application_feature):
        """
        Obtain the configured exceptions.
        Exceptions are specific to an @application_feature (e.g. File Upload),
        which belong to an @application_group which belongs to an @application
        :param application: <dict> application which the group belongs to
        :param application_group: <dict> application group to retrieve the exceptions for
        :param application_feature: <dict> application feature to retrieve the exception for
        :return <requests> response from GET
        """
        url = "%s/%s/groups/%s/features/%s/exception-collection" % (
            self.get_baseurl(),
            application["id"],
            application_group["id"],
            application_feature["id"],
        )
        return self.session.get(url)

    def get_application_exceptions(self, application, application_group, application_feature):
        """
        Obtain the configured exceptions.
        Exceptions are specific to an @application_feature (e.g. File Upload),
        which belong to an @application_group which belongs to an @application
        :param application: <dict> application which the group belongs to
        :param application_group: <dict> application group to retrieve the exceptions for
        :param application_feature: <dict> application feature to retrieve the exception for
        :return <dict> application exceptions if successful otherwise empty
        """
        response = self.request_application_exceptions(
            application=application,
            application_group=application_group,
            application_feature=application_feature,
        )
        return self.get_json_response(response=response)

    def get_application_exceptions_by_url(self, application, application_group, application_feature):
        """
        Obtain the configured exceptions.
        Exceptions are specific to an @application_feature (e.g. File Upload),
        which belong to an @application_group which belongs to an @application.
        Return a dict with the URL for the exceptions as the KEY
        :param application: <dict> application which the group belongs to
        :param application_group: <dict> application group to retrieve the exceptions for
        :param application_feature: <dict> application feature to retrieve the exception for
        :return <dict> application exceptions with URL as the KEY if successful otherwise empty
        """
        e_by_url = {}
        exceptions = self.get_application_exceptions(
            application=application,
            application_group=application_group,
            application_feature=application_feature,
        )
        for each_exception in exceptions["exceptions"]:
            e_by_url[each_exception["url"]] = each_exception
        return e_by_url

    ###############################
    #
    #   CREATE APPLICATION EXCEPTION
    #
    ###############################

    def request_create_application_exception(
            self,
            application,
            application_group,
            application_feature,
            exception_url,
            exception_desc=None,
            tenantid=None,
    ):
        """
        Create an exception for an application feature
        :param application: <dict> application which the group belongs to
        :param application_group: <dict> application group to create the exceptions for
        :param application_feature: <dict> application feature to create the exception for
        :param exception_url: <string> url for the exception
        :param exception_desc: <string> desc or 'note' of the exception
        :param tenantid: <string> tenant id
        :return: <request> response from the POST
        """
        tenant_id_to_use = self.tenantid
        if tenantid:
            tenant_id_to_use = tenantid
        url = "%s/%s/groups/%s/features/%s/exceptions" % (
            self.get_baseurl(),
            application["id"],
            application_group["id"],
            application_feature["id"],
        )
        payload = {
            "tenantId": tenant_id_to_use,
            "managedAppId": application["id"],
            "policyGroupId": application_group["id"],
            "featureId": application_feature["id"],
            "url": exception_url,
        }
        if exception_desc:
            payload["note"] = exception_desc
        return self.session.post(url=url, data=payload)

    def create_application_exception(
            self,
            application,
            application_group,
            application_feature,
            exception_url,
            exception_desc=None,
            tenantid=None,
    ):
        """
        Create an exception for an application feature
        :param application: <dict> application which the group belongs to
        :param application_group: <dict> application group to create the exceptions for
        :param application_feature: <dict> application feature to create the exception for
        :param exception_url: <string> url for the exception
        :param exception_desc: <string> desc or 'note' of the exception
        :param tenantid: <string> tenant id
        :return: <request> response from the POST
        """
        response = self.request_create_application_exception(
            application=application,
            application_group=application_group,
            application_feature=application_feature,
            exception_url=exception_url,
            exception_desc=exception_desc,
            tenantid=tenantid,
        )
        return self.get_json_response(response=response)

    ###############################
    #
    #   DELETE APPLICATION EXCEPTION
    #
    ###############################

    def request_delete_application_exception(self, application, application_group, application_feature,
                                             application_exception):
        """
        Delete an application exception
        :param application: <dict> application which the group belongs to
        :param application_group: <dict> application group where the exception belongs to
        :param application_feature: <dict> application feature for the exception
        :param application_exception: <dict> application exception to delete
        :return: <requests> response from delete
        """
        url = "%s/%s/groups/%s/features/%s/exceptions/%s" % (
            self.get_baseurl(),
            application["id"],
            application_group["id"],
            application_feature["id"],
            application_exception["id"],
        )
        return self.session.delete(url=url)

    def delete_application_exception(self, application, application_group, application_feature, application_exception):
        """
        Delete an application exception
        :param application: <dict> application which the group belongs to
        :param application_group: <dict> application group where the exception belongs to
        :param application_feature: <dict> application feature for the exception
        :param application_exception: <dict> application exception to delete
        :return: <boolean> True if successful otherwise False
        """
        response = self.request_delete_application_exception(
            application=application,
            application_group=application_group,
            application_feature=application_feature,
            application_exception=application_exception,
        )
        return self.get_bool_response(response=response)

    ###############################
    #
    #   UPDATE APPLICATION EXCEPTION
    #
    ###############################

    def request_update_application_exception(self, application, application_group, application_feature,
                                             application_exception):
        """
        Update an application exception
        :param application: <dict> application which the group belongs to
        :param application_group: <dict> application group where the exception belongs to
        :param application_feature: <dict> application feature for the exception
        :param application_exception: <dict> application exception to update
        :return: <requests> response from PUT
        """
        url = "%s/%s/groups/%s/features/%s/exceptions/%s" % (
            self.get_baseurl(),
            application["id"],
            application_group["id"],
            application_feature["id"],
            application_exception["id"],
        )
        return self.session.put(url=url, data=application_exception)

    def update_application_exception(self, application, application_group, application_feature, application_exception):
        """
        Update an application exception
        :param application: <dict> application which the group belongs to
        :param application_group: <dict> application group where the exception belongs to
        :param application_feature: <dict> application feature for the exception
        :param application_exception: <dict> application exception to update
        :return: <dict> updated exception if successful otherwise empty
        """
        response = self.request_update_application_exception(
            application=application,
            application_group=application_group,
            application_feature=application_feature,
            application_exception=application_exception,
        )

        return self.get_json_response(response=response)

    ###############################
    #
    #   LIST APPLICATION TEMPLATES
    #
    ###############################

    def request_application_template(self, application):
        """
        https://confluence.in.ionicsecurity.com/display/IP/v2.0+LIST+Custom+Feature+Templates
        Obtain custom features available for the given @application
        :param application: <dict> application to retrieve templates for
        :return <requests> response from GET
        """
        url = "%s/%s/templates" % (self.get_baseurl(), application["id"])
        return self.session.get(url)

    def get_application_templates(self, application):
        """
        Obtain custom features available for the given @application
        :param application: <dict> application to retrieve templates for
        :return <dict> applcation templates if successful otherwise empty
        """
        response = self.request_application_template(application=application)
        return self.get_json_response(response=response)

    def get_application_templates_by_name(self, application):
        """
        Get the application templates with the application template name as the key.
        :param application: <dict> application to retrieve template for
        :return <dict> application templates with name as KEY otherwise empty
        """
        application_templates = {}
        for each_template in self.get_application_templates(application=application):
            application_templates[each_template["name"]] = each_template
        return application_templates


class AppPolicyKb(Base):
    """
    Return the applications that are in the knowledge base for a tenant
    These apps should appear in the dropdown box, when creating a new application
    """

    def __init__(self, apiuser, tenantid, refresh_on_init=True):
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.appkb_applications_full = {}
        self.appkb_applications = []
        self.appkb_applications_by_uri = {}
        self.appkb_supported_applications = {}

        if refresh_on_init:
            self.refresh()

    def get_base_url(self):
        return "%s/%s/appkb" % (self.resource_url, self.tenantid)

    def refresh(self):
        self.appkb_applications_full = self.get_appkb_applications()
        self.appkb_applications = self.appkb_applications_full.get("Resources")
        self.appkb_applications_by_uri = self.get_appkb_applications_by_uri()
        self.appkb_supported_applications = self.get_supported_appkb_apps()

    ###############################
    #
    #   LIST APPKB APPS
    #
    ###############################

    def request_supported_appkb_applications(self):
        """
        Retrieve all supported appkb applications
        :return: <requests> response from POST
        """
        url = "%s/applications/list" % self.get_base_url()
        data = {"tenantId": self.tenantid}
        return self.session.post(url, data=data)

    def get_supported_appkb_apps(self):
        """
        Retrieve all supported appkb applications
        :return: <dict> supported appkb applications if successful otherwise empty
        """
        response = self.request_supported_appkb_applications()
        return self.get_json_response(response=response)

    def get_supported_appkb_apps_by_name(self):
        apps_by_name = {}
        for each_user in self.appkb_supported_applications["Resources"]:
            apps_by_name[each_user["name"]] = each_user
        return apps_by_name

    def get_supported_appkb_apps_name_list(self):

        response = self.get_supported_appkb_apps()
        applications = []
        for item in response["Resources"]:
            applications.append(item["name"])
        return applications

    def request_appkb_applications(self, method="POST", params=None):
        """
        Retrieve appkb application
        :return: <requests> response from requests
        """
        if method == "POST":
            url = "%s/applications/list" % self.get_base_url()
            params = {"tenantId": self.tenantid, "limit": 100}
            return self.session.post(url, data=params)
        else:
            url = "%s/applications" % self.get_base_url()
            return self.session.get(url)

    def get_appkb_applications(self, method="POST", params=None):
        """
        Retrieve appkb applications
        :return: <dict> appkb applications if successful otherwise empty
        """
        response = self.request_appkb_applications(method=method, params=params)
        return self.get_json_response(response=response)

    def get_appkb_applications_by_uri(self):
        """
        Retrieve appkb applications by URI.
        :return: <dict> appkb applications with 'appUri' as the KEY if
            successful, otherwise empty.
        """
        appkb_applications_by_uri = {}
        if not self.appkb_applications:
            try:
                self.appkb_applications = self.get_appkb_applications()["Resources"]
            except KeyError:
                return appkb_applications_by_uri
        for each_application in self.appkb_applications:
            appkb_applications_by_uri[each_application["appUri"]] = each_application
        return appkb_applications_by_uri

    def number_of_applications(self):
        """
        :return: <int> number of application
        """
        return len(self.appkb_applications)

    def get_application_names(self):
        """
        Retrieve all the names of the applications avaliable for the tenant
        :return: <list> of strings of application names
        """
        names = []
        for each_app in self.appkb_applications:
            names.append(each_app["name"])
        return names

    def get_application_id(self, appuri):
        """
        Retrieve the application ID
        :param appuri: <string> uri of the application
        :return: <string> id of the application
        """
        application_id = ""
        if appuri in self.appkb_applications_by_uri:
            application_id = self.appkb_applications_by_uri[appuri]["id"]
        return application_id

    def get_custom_application(self):
        """
        Retrieve the 'Custom Application'
        :return: <dict> Custom Application
        """
        return self.get_specific_application(uri="example.com", application_name="Custom Application")

    def get_office_application(self):
        """
        Retrieve the 'Microsoft Office' Application
        :return: <dict> Microsoft Office
        """
        return self.get_specific_application(
            uri="application-microsoft-office",
            application_name="Microsoft Office Endpoint v1",
        )

    def get_global_application(self):
        """
        Retrieve the 'Global Application Policy' Application
        :return: <dict> Global Application Policy
        """
        return self.get_specific_application(uri="*", application_name="Global Application Policies")

    def get_specific_application(self, uri, application_name):
        """
        Return the desired application based on uri and name
        :param uri: <string> uri of the application
        :param application_name: <string> name of the application
        :return: appkb application if successful other empty
        """
        my_app = {}
        my_appuri = uri
        my_appname = application_name
        try:
            if self.appkb_applications_by_uri[my_appuri]["name"] == my_appname:
                my_app = self.appkb_applications_by_uri[my_appuri]
        except KeyError:
            print("No %s App Found" % application_name)
        return my_app


if __name__ == "__main__":
    import pickle
    import argparse
    import json
    from pydashboard.pydashboard.authenticate_apiuser import AuthApiUser

    def print_pretty_json(content):
        print(json.dumps(content, sort_keys=True, separators=(",", ": "), indent=2))

    parser = argparse.ArgumentParser(description="Obtain Application Policy Information from the dashboard")
    parser.add_argument(
        "--authfile",
        "-a",
        required=True,
        help="File which contains information about dashboard" + "session. See authenticate_apiuser.py to create" +
        "authfileout",
    )

    parser.add_argument("--create", "-c", help="Create an Application <appuri> <appname>", nargs=2)
    parser.add_argument("--get", "-g", help="Get JSON of Applications")
    parser.add_argument(
        "--update_features",
        "-uf",
        help="Update Application <appuri> <group> <settings>",
        nargs=3,
    )
    parser.add_argument("--delete", "-d", help="Delete Application with the provided appuri", nargs=1)
    parser.add_argument("--features", "-f", help="Get features for the application <appuri>", nargs=1)

    args = parser.parse_args()

    auth_args = pickle.load(open(args.authfile, "rb"))

    api_user = AuthApiUser(
        resource_url=auth_args["resource_url"],
        usr=auth_args["username"],
        pwd=auth_args["password"],
        tenantid=auth_args["tenantid"],
        login_on_init=False,
        load_tenant_info=False,
    )

    api_user.session = auth_args["session"]

    app_policy = ApplicationPolicies(apiuser=api_user, tenantid=auth_args["tenantid"])

    if args.get:
        if args.get[0] == "refresh":
            app_policy.refresh()
        print_pretty_json(app_policy.applications)

    if args.delete:
        # Delete the application with the provided URI
        app_policy.refresh()
        appuri = args.delete[0]
        print(app_policy.delete_application(application=app_policy.applications_by_appuri[appuri]))

    if args.create:
        # Create an Application
        appkb = AppPolicyKb(apiuser=api_user, tenantid=auth_args["tenantid"])
        appuri = args.create[0]
        appname = args.create[1]
        appkb_app = appkb.get_specific_application(uri=appuri, application_name=appname)
        new_app = app_policy.create_application(appname=appname, appuri=appuri, appkbid=appkb_app["id"])
        new_app = app_policy.enable_application(application=new_app)
        print(new_app)

    if args.features:
        # Get the Features of an application
        appuri = args.features[0]
        print_pretty_json(app_policy.get_application_features(application=app_policy.get_applications_by_uri()[appuri]))

    if args.update_features:
        # Update the sliders for the provide appri and policy group
        appuri = args.update_features[0]
        group = args.update_features[1]
        settings = json.loads(args.update_features[2])
        application = app_policy.get_applications_by_uri()[appuri]
        application_group = app_policy.get_application_groups_by_name(application=application)[group]
        print(
            app_policy.update_application_for_group(
                application=application,
                application_group=application_group,
                new_settings=settings,
            ))
