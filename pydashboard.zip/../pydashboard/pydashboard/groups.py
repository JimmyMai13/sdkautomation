from pydashboard.pydashboard.base import Base


class Groups(Base):
    """
    Perform operations on Groups
    """

    SCHEMA_CORE = "urn:scim:schemas:core:1.0"
    SCHEMA_EXTENSION = "urn:scim:schemas:extension:ionic:1.0"
    SCIM2_PATCH = "urn:ietf:params:scim:api:messages:2.0:PatchOp"
    DEFAULT_LIMIT = 20
    DEFAULT_PARAMS = {
        "asc": True,
        "limit": 100,
        "orderBy": "name",
        "skip": 0
    }

    def __init__(self, apiuser, tenantid, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        :param refresh_on_init: <boolean> Whether to refresh data policies upon initialization
        :return:
        """
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.groups_full = {}
        self.groups = []
        self.groups_by_name = {}
        self.scim_version = "1"

        if refresh_on_init:
            self.refresh()

    def refresh(self):
        self.groups_full = self.get_groups()
        self.groups = self.groups_full.get("Resources")
        self.groups_by_name = self.get_groups_by_name()

    def set_scim_version(self, version):
        if not isinstance(version, str):
            raise Exception("Version must be a string")
        else:
            self.scim_version = version

    def get_baseurl(self):
        return "%s/%s/scim/v%s/Groups" % (
            self.resource_url,
            self.tenantid,
            self.scim_version,
        )

    def get_bulk_baseurl(self):
        return "%s/%s/scim/v%/Bulk" % (
            self.resource_url,
            self.tenantid,
            self.scim_version,
        )

    def request_get_groups(self, params=None, method="POST", search=False):
        """
        Retrieve Groups Information
        :param limit: <int> number of groups to return
        :return: <requests> response from request
        """
        if method == "POST":
            if params is None:
                params = self.DEFAULT_PARAMS
            if search:
                url = "%s/.search" % self.get_baseurl()
            else:
                url = "%s/list" % self.get_baseurl()
            params = self.get_params(params=params)
            return self.session.post(url, data=params, should_wait=False)
        else:
            url = self.get_baseurl()
            return self.session.get(url, params=params)

    def get_groups(self, params=None, method="POST"):
        """
        Retrieve Groups Information
        :param limit: <int> number of groups to return
        :return: <dict> groups information if successful otherwise empty
        """
        response = self.request_get_groups(params=params, method=method)
        return self.get_json_response(response=response)

    def request_get_group(self, group, params=None):
        """
        Retrieve Group information
        :param group: <dict> group
        :return: <requests> response from GET
        """
        url = "%s/%s" % (self.get_baseurl(), group["id"])
        return self.session.get(url, params=params)

    def get_group(self, group, params=None):
        """
        Retrieve Group information
        :param group: <dict> group
        :param params: params
        :return: <dict> group information if successful otherwise empty
        """
        response = self.request_get_group(group=group, params=params)
        return self.get_json_response(response=response)

    def get_groups_by_name(self):
        """
        Retrieve Groups Information with the name as the KEY
        :param limit: <int> number of groups to return
        :return: <dict> groups information with name as KEY if successful otherwise empty
        """
        groups_by_name = {}
        if not self.groups:
            try:
                self.groups = self.get_groups()["Resources"]
            except KeyError:
                return groups_by_name
        for each_group in self.groups:
            groups_by_name[each_group["displayName"]] = each_group
        return groups_by_name

    def request_create_group(self, name, desc=None, externalid=None, tenantid=None):
        """
        Creates a new Group
        :param name: <string> The name of the User Group
        :param desc: <string> Description of the User Group
        :return: <requests> response from POST
        """
        url = "%s" % (self.get_baseurl())
        payload = {
            # "tenantId": self.get_tenant_id(tenantid=tenantid),
            "schemas": [self.SCHEMA_CORE, self.SCHEMA_EXTENSION],
            "displayName": name,
        }
        if externalid:
            payload["externalId"] = externalid
        if desc:
            payload[self.SCHEMA_EXTENSION] = {"description": desc}

        return self.session.post(url, data=payload)

    def create_group(self, name, desc=None, externalid=None, tenantid=None):
        """
        Creates a new Group
        :param name: <string> The name of the User Group
        :param desc: <string> Description of the User Group
        :return: <dict> group created if successful otherwise empty
        """
        response = self.request_create_group(name=name, desc=desc, externalid=externalid, tenantid=tenantid)
        return self.get_json_response(response=response)

    def request_update_group(self, group):
        """
        Update group
        :param group: <dict> group to update
        :return: <requests> response from PUT
        """
        url = "%s/%s" % (self.get_baseurl(), group["id"])
        return self.session.put(url=url, data=group)

    def update_group(self, group):
        """
        Update group
        :param group: <dict> group to update
        :return: <dict> updated group if successful other empty
        """
        response = self.request_update_group(group=group)
        return self.get_json_response(response=response)

    def request_delete_group(self, group):
        """
        Deletes a Group
        :param group: <dict> group to delete
        :return: <requests> response from DELETE
        """
        url = "%s/%s" % (self.get_baseurl(), group["id"])
        return self.session.delete(url=url)

    def delete_group(self, group):
        """
        Deletes a Group
        :param group: <dict> group to delete
        :return: <boolean> True if deletion successful other False
        """
        response = self.request_delete_group(group=group)
        return self.get_bool_response(response=response)

    def request_add_user_to_group(self, group, user_id_list):
        """
        Adds user to group
        :param group: <dict> group to add to user to
        :param user_id_list: <list> user id's to add to gorup
        :return: <requests> response from PATCH
        """

        url = "%s/%s" % (self.get_baseurl(), group["id"])
        payload = {"members": []}
        for x in range(len(user_id_list)):
            payload["members"].append({"value": user_id_list[x]})
        response = self.session.patch(url=url, data=payload)
        return response

    def add_user_to_group(self, group, user_id_list):
        """
        Adds users to Group
        :param group: <dict> group to add user to
        :param user_id_list: <list> user id's to add to group
        :return: <boolean> True if adding user successful
        """
        response = self.request_add_user_to_group(group, user_id_list)
        return self.get_bool_response(response=response)

    def request_remove_user_from_group(self, group, user_id_list):
        """
        Remove users from group
        :param group: <dict> group to remove user from
        :param user_id_list: <list> user id's to remove from group
        :return: <requests> response from Patch
        """
        url = "%s/%s" % (self.get_baseurl(), group["id"])
        payload = {"members": []}
        for x in range(len(user_id_list)):
            payload["members"].append({"value": user_id_list[x], "operation": "delete"})
        response = self.session.patch(url=url, data=payload)
        return response

    def remove_user_from_group(self, group, user_id_list):
        """
        Remove users from group
        :param group: <dict> group to add user to
        :param user_id_list: <list> user id's to add to group
        :return: <boolean> True if removing user successful
        """
        response = self.request_remove_user_from_group(group, user_id_list)
        return self.get_json_response(response=response)

    def request_update_group_patch(self, group, operations=[]):
        """
        Update Group
        :param group: <dict> group to update
        :param operations <list> operations for scim 2
        :return: <requests> response from Patch
        """
        url = "%s/%s" % (self.get_baseurl(), group["id"])
        if self.scim_version == "2":
            payload = {"schemas": [self.SCIM2_PATCH]}
            payload["Operations"] = operations
        else:
            payload = {"schemas": [self.SCHEMA_CORE, self.SCHEMA_EXTENSION]}
            payload["displayName"] = group["displayName"]
            payload["externalId"] = group["externalId"]
            UPDATE_DESC = group["urn:scim:schemas:extension:ionic:1.0"]["description"]
            payload[self.SCHEMA_EXTENSION] = {"description": "%s" % UPDATE_DESC}
        response = self.session.patch(url=url, data=payload)
        return response

    def update_group_patch(self, group, operations=[]):
        """
        Remove users from group
        :param group: <dict> update group
        :param operations: <list> operations for scim 2
        :return: <boolean> True if update group successful
        """
        response = self.request_update_group_patch(group, operations=operations)
        return self.get_bool_response(response=response)

    def request_create_group_permissions(self, group, user):
        """
        Create new manager of a group
        :param group: <dict> group
        :param user: <dict> user
        :return: <requests> response from POST
        """
        url = "%s/%s/permissions" % (self.get_baseurl(), group["id"])
        payload = {"manager": {"id": user["id"], "type": "users"}, "scopes": []}
        return self.session.post(url, data=payload)

    def create_group_permissions(self, group, user):
        """
        Create new manager of a group
        :param group: <dict> group
        :param user: <dict> user
        :return: <dict> permission details if successful otherwise empty
        """
        response = self.request_create_group_permissions(group=group, user=user)
        return self.get_json_response(response=response)

    def request_update_group_permissions(self, permissions):
        """
        Update Group Permissions
        :param permissions: <dict> permissions to update
        :return: <requests> response from PUT
        """
        url = "%s/%s/permissions/%s" % (
            self.get_baseurl(),
            permissions["resource"]["id"],
            permissions["id"],
        )
        payload = permissions
        return self.session.put(url, data=payload)

    def update_group_permissions(self, permissions):
        """
        Update Group Permissions
        :param permissions: <dict> permissions to update 
        :return: <dict> updated permissions if successful otherwise empty
        """
        response = self.request_update_group_permissions(permissions=permissions)
        return self.get_json_response(response=response)

    def request_get_group_permissions_details(self, permissions):
        """
        Get detail management information for a group
        :param permissions: <dict> permissions
        :return: <requests> response from GET
        """
        url = "%s/%s/permissions/%s" % (
            self.get_baseurl(),
            permissions["resource"]["id"],
            permissions["id"],
        )
        return self.session.get(url)

    def get_group_permissions_details(self, permissions):
        """
        Get detail management information for a group
        :param permissions: <dict> permissions
        :return: <dict> permission details if successful otherwise empty
        """
        response = self.request_get_group_permissions_details(permissions=permissions)
        return self.get_json_response(response=response)

    def request_get_group_permissions(self, group, params=None, method="POST", search=False):
        """
        Get Group Permissions list
        :param group: <dict> group
        :return: <requests> response from POST
        """
        if method == "POST":
            if search:
                url = "%s/%s/permissions/.search" % (self.get_baseurl(), group["id"])
            else:
                url = "%s/%s/permissions/list" % (self.get_baseurl(), group["id"])
            default_params = {
                "limit": 20,
                "skip": 0,
                "orderBy": "manager",
                "asc": True,
                "groupId": group["id"],
            }
            self.get_params(params=params, desired_params=default_params)
            return self.session.post(url, data=params)
        else:
            url = "%s/%s/permissions" % (self.get_baseurl(), group["id"])
            return self.session.get(url, params=params)

    def get_group_permissions(self, group, params=None, method="POST", search=False):
        """
        Get Group Permissions list
        :param group: <dict> group
        :return: <dict> permissions list if successful otherwise empty
        """
        response = self.request_get_group_permissions(group=group, params=params, method=method, search=search)
        return self.get_json_response(response=response)

    def request_delete_group_permissions(self, permissions):
        """
        Delete Group Permissions
        :param permissions: <dict> permissions to delete
        :return: <requests> response from DELETE
        """
        url = "%s/%s/permissions/%s" % (
            self.get_baseurl(),
            permissions["resource"]["id"],
            permissions["id"],
        )
        return self.session.delete(url)

    def delete_group_permissions(self, permissions):
        """
        Delete Group Permissions
        :param permissions: <dict> permissions to delete
        :return: <bool> True if successful otherwise False
        """
        response = self.request_delete_group_permissions(permissions=permissions)
        return self.get_bool_response(response=response)

    ########################################
    #
    #  BULK - for importing groups
    #  -
    #
    ########################################
    def make_group_json(self, name, description, ext_id, tenantid=None):

        payload = {
            "schemas": [self.SCHEMA_CORE, self.SCHEMA_EXTENSION],
            self.SCHEMA_EXTENSION: {
                "description": description
            },
            "displayName": name,
            "externalId": ext_id,
        }
        return payload

    def request_create_groups_bulk(self, groups):
        """

        :param users: <list> of user objects
        :return:
        """
        url = self.get_bulk_baseurl()
        bulk_payload = {
            "schemas": ["urn:scim:schemas:core:1.0"],
            "failOnErrors": 1,
            "Operations": [{
                "method": "POST",
                "path": "/Groups",
                "bulkId": "grouppost",
                "data": groups,
            }],
        }
        return self.session.post(url, data=bulk_payload)

    #######################################################
    #
    #
    # Search Bar
    #
    #
    #######################################################

    SEARCH_TYPE = {
        "name": "name__contains",
        "external_id": "external_id__contains",
        "description": "description__contains",
    }

    def request_search_bar(self, values, params=None):
        """
        values = [('SEARCH_TYPE', 'SEARCH_BY'), (), ()]
        :param values:
        :return:
        """
        url = "%s/list" % self.get_baseurl()
        params = self.get_params(params=params, desired_params=self.DEFAULT_PARAMS)
        for each_value in values:
            search_key = list(each_value.keys())[0]
            search_value = list(each_value.values())[0]
            params[self.SEARCH_TYPE[search_key]] = search_value
        # params.update(self.get_mongo_search_string(search_items=values))
        return self.session.post(url, data=params)

    def search_bar(self, values, params=None):
        params = self.get_params(params=params, desired_params=self.DEFAULT_PARAMS)
        response = self.request_search_bar(values=values, params=params)
        return self.get_json_response(response=response)
