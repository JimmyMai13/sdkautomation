from pydashboard.pydashboard.base import Base


class ResetPassword(Base):
    """
    This class allows you to reset a tenant admin password
    You can also request a forgot password email
    """

    def __init__(self, apiuser, tenantid):
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url
        self.baseurl_reset = "{url}/{tenantid}/auth/reset-password".format(url=self.resource_url,
                                                                           tenantid=self.tenantid)
        self.baseurl_forgot = "{url}/{tenantid}/auth/forgot-password".format(url=self.resource_url,
                                                                             tenantid=self.tenantid)

    def request_set_password(self, password, token, repeat_failed_request=False):
        url = self.baseurl_reset
        payload = {"password": password, "token": token}
        return self.session.post(url=url, data=payload, repeat_failed_request=repeat_failed_request)

    def set_password(self, password, token):
        response = self.request_set_password(password=password, token=token)
        return response

    def request_forgot_password(self, email=None, username=None):
        if email is None and username is None:
            raise ValueError("Argument required for either 'email' or 'username' parameter")
        else:
            url = self.baseurl_forgot
            if username is None:
                payload = {"email": email}
            else:
                payload = {"username": username}
            return self.session.post(url=url, data=payload)

    def forgot_password(self, email=None, username=None):
        response = self.request_forgot_password(email=email, username=username)
        return response
