import json
import os

import pytz

# from datetime import datetime

# json.dumps(<contents>, sort_keys=True, separators=(',', ': '), indent=4)


class DataPolicyRule:

    AND_OR = ["and", "or"]
    ALLOWED_EFFECTS = ["Permit", "Deny"]

    def __init__(self, effect, desc, andor="or"):

        self.rule = {}
        self.effect = effect
        self.description = desc
        self.condition = []  # list of Rule Conditions
        self.andor = andor
        if self.AND_OR:
            assert self.andor in self.AND_OR

        assert self.effect in self.ALLOWED_EFFECTS

    def build_rule(self):
        self.rule["effect"] = self.effect
        self.rule["description"] = self.description

        # If there are NO conditions, the rule applies to ALL DATA
        if len(self.condition) == 0:
            pass
            # self.rule['condition'] = {}
            # Do not set the 'condition' for All Data Policy
        elif len(self.condition) == 1:
            self.rule["condition"] = self.condition[0]
        elif len(self.condition) > 1:
            self.rule["condition"] = {}
            self.rule["condition"]["functionId"] = self.andor
            self.rule["condition"]["args"] = self.condition


class DataPolicyTarget:
    def __init__(self, andor="and"):
        self.target = {}
        self.target_conditions = []
        self.andor = andor

    def build_target(self):
        if len(self.target_conditions) == 1:
            self.target["condition"] = {}
            self.target["condition"] = self.target_conditions[0]
        elif len(self.target_conditions) > 1:
            self.target["condition"] = {}
            self.target["condition"]["functionId"] = self.andor
            self.target["condition"]["args"] = self.target_conditions
            # self.target = self.target_conditions
            # ["anyOf"] = []
            # self.target["anyOf"].append({"allOf": self.target_conditions})


class RuleCondition:

    FUNCTION_TYPE = {
        "string-subset": "string-subset",
        "string-at-least-one-member-of": "string-at-least-one-member-of",
        "string-equal": "string-equal",
        "string-one-and-only": "string-one-and-only",
        "string-bag": "string-bag",
        "dateTime-greater-than-or-equal": "dateTime-greater-than-or-equal",
        "date-add-duration": "date-add-duration",
        "dateTime-less-than-or-equal": "dateTime-less-than-or-equal",
        "ipAddress-endpoint-match": "ipAddress-endpoint-match",
        "not": "not",
        "or": "or",
        "and": "and",
    }

    def __init__(self):
        self.rule_condition = {}
        self.functionid = ""
        self.args = []
        self.build_not_condition = False

    def append_attributedesignator(self, category, attr_id):
        attributedesignator = {"category": category, "id": attr_id}
        self.args.append(attributedesignator)

    def set_functionid(self, function_type):
        self.functionid = self.FUNCTION_TYPE[function_type]

    def append_attributevalue(self, values, subject_attributes=False):
        """
        values should be a list of objects in a tuple:
        values = [('ABC', 'string'), ('DEF', 'string'), ('XYZ', 'string')]
        """
        if not subject_attributes:
            for each_value in values:
                a_value = {}
                a_value["dataType"] = each_value[1]
                a_value["value"] = each_value[0]
                self.args.append(a_value)
        else:
            a_value = {}
            subject_attr = []
            a_value["dataType"] = "string"
            for each_value in values:
                subject_attr.append(each_value[0])
            a_value["value"] = subject_attr
            self.args.append(a_value)

    @staticmethod
    def format_attribute_values(values, value_type="string"):
        """
        Create an list
        """
        formatted_values = []
        for each_value in values:
            formatted_values.append((each_value, value_type))
        return formatted_values

    def append_to_apply(self, applicable_values):
        if "apply" in self.rule_condition:
            self.rule_condition["apply"].append(applicable_values)
        else:
            self.rule_condition["apply"] = []
            self.rule_condition["apply"].append(applicable_values)

    # def set_not_condition(self):
    #     current_condition = self.rule_condition
    #     self.rule_condition = {}
    #     self.rule_condition["functionId"] = "not"
    #     self.rule_condition["args"] = []
    #     self.rule_condition["args"].append(current_condition)

    def build_condition(self):
        condition = dict()
        condition["functionId"] = self.functionid
        condition["args"] = self.args
        if self.build_not_condition:
            self.rule_condition["functionId"] = "not"
            self.rule_condition["args"] = []
            self.rule_condition["args"].append(condition)
        else:
            self.rule_condition = condition


class GenericCondition:
    """
    "functionId": "<some_function>",
    "args": [

        ],
    """

    def __init__(self, functionid):
        self.condition = {}
        self.functionid = functionid
        self.args = []

    def append_args(self, json_to_append):
        self.args.append(json_to_append)

    def build_specific_condition(self):
        self.condition["functionId"] = self.functionid
        self.condition["args"] = self.args
        # self.set_functionid(functionType=self.functiontype, function_name=function_name)
        # self.set_attributeDesignator(category=self.ad_category, id=self.ad_id)


class LocationCondition(RuleCondition):

    AD_CATEGORY = "environment"
    AD_ID = "location-country"

    def __init__(self, countries, isnot=False):
        super().__init__()
        self.countries = countries
        self.isnot = isnot
        self.build_specific_condition()

    def build_specific_condition(self):
        self.set_functionid(function_type="string-at-least-one-member-of")
        self.append_attributedesignator(category=self.AD_CATEGORY, attr_id=self.AD_ID)
        formatted_countries = self.format_attribute_values(values=self.countries)
        self.append_attributevalue(values=formatted_countries)
        if self.isnot:
            self.build_not_condition = True


class UserCondition(RuleCondition):

    AD_CATEGORY = "subject"
    AD_ID = "subject-id"

    ALLOWED_RULE_TYPES = ["match", "creator"]

    def __init__(self, rule_type, userids=None, isnot=False):
        super().__init__()
        self.rule_type = rule_type
        self.userids = userids if userids else []
        self.isnot = isnot
        assert self.rule_type in self.ALLOWED_RULE_TYPES
        self.build_specific_condition()

    def build_specific_condition(self):
        self.append_attributedesignator(category=self.AD_CATEGORY, attr_id=self.AD_ID)
        if self.rule_type == "match":
            self.build_match_rule(userids=self.userids)
        elif self.rule_type == "creator":
            self.build_creator_rule()
        if self.isnot:
            self.build_not_condition = True

    def build_match_rule(self, userids):
        self.set_functionid(function_type="string-at-least-one-member-of")
        formatted_users = self.format_attribute_values(values=userids)
        self.append_attributevalue(values=formatted_users)

    def build_creator_rule(self):
        self.set_functionid(function_type="string-equal")
        self.append_attributedesignator(category="resource", attr_id="created-user-id")


class UserGroupCondition(RuleCondition):

    AD_CATEGORY = "subject"
    AD_ID = "group"

    ALLOWED_RULE_TYPES = ["match", "creator"]
    ALLOWED_ANY_OR_ALL = {
        "any": "string-at-least-one-member-of",
        "all": "string-subset",
    }

    def __init__(self, rule_type, groupids=None, isnot=False, any_or_all="any"):
        super().__init__()
        self.rule_type = rule_type
        self.groupids = groupids if groupids else []
        self.isnot = isnot
        self.any_or_all = any_or_all
        assert self.rule_type in self.ALLOWED_RULE_TYPES
        assert self.any_or_all in list(self.ALLOWED_ANY_OR_ALL.keys())
        self.build_specific_condition()

    def build_specific_condition(self):
        if self.rule_type == "match":
            self.build_match_rule(groupids=self.groupids)
        elif self.rule_type == "creator":
            self.build_creator_rule()
        if self.isnot:
            self.build_not_condition = True
        self.append_attributedesignator(category=self.AD_CATEGORY, attr_id=self.AD_ID)

    def build_match_rule(self, groupids):
        formatted_users = self.format_attribute_values(values=groupids, value_type="string")
        self.append_attributevalue(values=formatted_users)
        self.set_functionid(function_type=self.ALLOWED_ANY_OR_ALL[self.any_or_all])

    def build_creator_rule(self):
        # For some reason this does not match Users -> string-equal
        self.append_attributedesignator(category="resource", attr_id="created-group")
        self.set_functionid(function_type=self.ALLOWED_ANY_OR_ALL[self.any_or_all])


class RelativeDateCondition(RuleCondition):

    AD_CATEGORY = "environment"
    AD_ID = "current-dateTime"
    DAYS_FORMAT = "P{0}D"
    ALLOWED_TIME_FRAME = {"days": {"dataType": "dayTimeDuration", "value": "P{0}D"}}

    def __init__(self, timeframe_type, timeframe_amount):
        super().__init__()
        self.timeframe_type = timeframe_type
        self.timeframe_amount = timeframe_amount
        assert self.timeframe_type in self.ALLOWED_TIME_FRAME.keys()
        self.build_specific_condition()

    def build_specific_condition(self):
        self.set_functionid(function_type="date-greater-than-or-equal")
        self.append_attributedesignator(category=self.AD_CATEGORY, attr_id=self.AD_ID)

        applied_time_frame = GenericCondition(functionid="date-add-duration")
        sub_attribute_designator = {"category": "resource", "id": "created-dateTime"}
        applied_time_frame.args.append(sub_attribute_designator)
        time_frame = self.ALLOWED_TIME_FRAME[self.timeframe_type]
        tf_value = time_frame["value"].format(self.timeframe_amount)
        time_frame["value"] = [tf_value]
        applied_time_frame.args.append(time_frame)
        applied_time_frame.build_specific_condition()
        self.args.append(applied_time_frame.condition)


class SpecificDateCondition(RuleCondition):

    AD_CATEGORY = "environment"
    AD_ID = "current-dateTime"

    ALLOWED_BEF_OR_AFT = {
        "after": "dateTime-greater-than-or-equal",
        "before": "dateTime-less-than-or-equal",
    }

    def __init__(self, specific_time, before_or_after="after", tzone=pytz.utc):
        super().__init__()
        self.specific_time = specific_time
        self.tzone = tzone
        self.before_or_after = before_or_after

        assert self.before_or_after in self.ALLOWED_BEF_OR_AFT.keys()
        self.policy_time = self.format_time()
        self.build_specific_condition()

    def format_time(self):
        return self.specific_time.replace(microsecond=0).isoformat("T")

    def build_specific_condition(self):
        self.set_functionid(function_type=self.ALLOWED_BEF_OR_AFT[self.before_or_after])
        self.append_attributedesignator(category=self.AD_CATEGORY, attr_id=self.AD_ID)
        formatted_time = self.format_attribute_values(values=[self.policy_time], value_type="dateTime")
        self.append_attributevalue(values=formatted_time)


class DeviceCondition(RuleCondition):

    AD_CATEGORY = "environment"
    AD_ID = "device-id"

    def __init__(self, device_ids, isnot=False):
        super().__init__()
        self.device_ids = device_ids
        self.isnot = isnot
        self.build_specific_condition()

    def build_specific_condition(self):
        self.set_functionid(function_type="string-at-least-one-member-of")
        self.append_attributedesignator(category=self.AD_CATEGORY, attr_id=self.AD_ID)
        formatted_device_ids = self.format_attribute_values(values=self.device_ids)
        self.append_attributevalue(values=formatted_device_ids)
        if self.isnot:
            self.build_not_condition = True


class IPAddressCondition(RuleCondition):

    AD_CATEGORY = "environment"
    AD_ID = "ipAddress"

    def __init__(self, ips, isnot=False):
        super().__init__()
        self.ips = ips
        self.isnot = isnot
        self.build_specific_condition()

    def build_specific_condition(self):
        self.set_functionid(function_type="ipAddress-endpoint-match")
        self.append_attributedesignator(category=self.AD_CATEGORY, attr_id=self.AD_ID)
        formatted_ips = self.format_attribute_values(values=self.ips, value_type="ipAddress")
        self.append_attributevalue(values=formatted_ips)
        if self.isnot:
            self.build_not_condition = True


class TargetCondition:
    # This is used to create a data policy with a condition group

    def __init__(self):
        self.target_condition = {}
        self.functionid = ""
        self.args = []
        self.build_not_condition = False

    def build_condition(self):
        condition = dict()
        condition["functionId"] = self.functionid
        condition["args"] = self.args
        if self.build_not_condition:
            self.target_condition["functionId"] = "not"
            self.target_condition["args"] = []
            self.target_condition["args"].append(condition)
        else:
            self.target_condition = condition

    def set_functionid(self, function_type):
        self.functionid = function_type

    def append_attributedesignator(self, category, attr_id, present=None):
        attributedesignator = {"category": category, "id": attr_id}
        self.args.append(attributedesignator)

    def append_attributevalue(self, data_type, values):
        """
        values should be a list of objects in a tuple:
        values = [('ABC', 'string'), ('DEF', 'string'), ('XYZ', 'string')]
        """
        a_value = dict()
        a_value["dataType"] = data_type
        a_value["value"] = values
        self.args.append(a_value)


class AdvancedCondition:

    ALLOWED_ANY_OR_ALL = {
        "any": "string-at-least-one-member-of",
        "all": "string-subset",
    }
    ALLOWED_DOES_NOT_EQUAL = {"does_not_equal": "not"}
    CUSTOM_VALUES = "custom values"
    DEFAULT_CATEGORY = "resource"

    def __init__(
            self,
            attribute1,
            attribute2,
            attribute1_category,
            attribute2_category,
            does_not_equal=False,
            any_or_all="any",
    ):

        super().__init__()
        self.attribute1 = attribute1
        self.attribute2 = attribute2
        self.attribute1_category = attribute1_category
        self.attribute2_category = attribute2_category
        self.does_not_equal = does_not_equal
        self.any_or_all = any_or_all
        self.advanced_attributes_from_file = None

    def custom_values_attributes(self):
        if self.attribute2_category == self.CUSTOM_VALUES:
            attributedesignator = {"dataType": "string", "value": self.attribute2}
        else:
            attributedesignator = {}
        return attributedesignator


class AdvancedTargetCondition(TargetCondition):

    def __init__(
            self,
            attribute1,
            attribute2,
            attribute1_category,
            attribute2_category,
            does_not_equal=False,
            any_or_all="any"
    ):
        super().__init__()
        self.ac = AdvancedCondition(
            attribute1=attribute1,
            attribute2=attribute2,
            attribute1_category=attribute1_category,
            attribute2_category=attribute2_category,
            does_not_equal=does_not_equal,
            any_or_all=any_or_all,
        )
        self.build_specific_condition()

    def build_specific_condition(self):
        if self.ac.does_not_equal:
            self.build_not_condition = True
        self.set_functionid(function_type=self.ac.ALLOWED_ANY_OR_ALL[self.ac.any_or_all])
        if self.ac.attribute2_category == self.ac.CUSTOM_VALUES:
            self.args.append(self.ac.custom_values_attributes())
            self.append_attributedesignator(category=self.ac.attribute1_category, attr_id=self.ac.attribute1)
        else:
            self.append_attributedesignator(category=self.ac.attribute1_category, attr_id=self.ac.attribute1)
            self.append_attributedesignator(category=self.ac.attribute2_category, attr_id=self.ac.attribute2)


class AdvancedRuleCondition(RuleCondition):

    def __init__(
            self,
            attribute1,
            attribute2,
            attribute1_category,
            attribute2_category,
            does_not_equal=False,
            any_or_all="any",
    ):

        super().__init__()
        self.ac = AdvancedCondition(
            attribute1=attribute1,
            attribute2=attribute2,
            attribute1_category=attribute1_category,
            attribute2_category=attribute2_category,
            does_not_equal=does_not_equal,
            any_or_all=any_or_all,
        )
        self.build_specific_condition()

    def build_specific_condition(self):
        if self.ac.does_not_equal:
            self.build_not_condition = True
        self.set_functionid(function_type=self.ac.ALLOWED_ANY_OR_ALL[self.ac.any_or_all])
        if self.ac.attribute2_category == self.ac.CUSTOM_VALUES:
            self.args.append(self.ac.custom_values_attributes())
            self.append_attributedesignator(category=self.ac.attribute1_category, attr_id=self.ac.attribute1)
        else:
            self.append_attributedesignator(category=self.ac.attribute1_category, attr_id=self.ac.attribute1)
            self.append_attributedesignator(category=self.ac.attribute2_category, attr_id=self.ac.attribute2)


class MarkedDataCondition(TargetCondition):

    AD_CATEGORY = "resource"
    ALLOWED_ISNOT = {"isnot": "not"}
    ALLOWED_ANY_OR_ALL_DM = {"any": "or", "all": "and"}
    ALLOWED_ANY_OR_ALL_DMV = {"any": "or", "all": "string-subset"}

    def __init__(
            self,
            rule_type,
            marking_names,
            marking_values=None,
            isnot=False,
            any_or_all="any",
    ):

        super().__init__()
        self.rule_type = rule_type
        self.marking_names = marking_names
        self.marking_values = marking_values
        self.isnot = isnot
        self.any_or_all = any_or_all
        allowed = (self.any_or_all in self.ALLOWED_ANY_OR_ALL_DM or self.ALLOWED_ANY_OR_ALL_DMV)
        msg_not_allowed = "'any_or_all value of '{any_or_all}' is NOT in {any_or_all_names}".format(
            any_or_all=self.any_or_all,
            any_or_all_names=list(self.ALLOWED_ANY_OR_ALL_DM.keys()),
        )
        assert allowed, msg_not_allowed
        self.build_specific_condition()

    def append_attributedesignator2(self, category, attr_id):
        """
        POLICY-3259
        https://jira.in.ionicsecurity.com/browse/POLICY-3259
        """
        for each_marking in attr_id:
            inner_json = dict()
            inner_json["functionId"] = "integer-greater-than"
            inner_json["args"] = []
            attributedesignator = {
                "functionId": "string-bag-size",
                "args": [{
                    "category": category,
                    "id": each_marking
                }],
            }
            inner_json["args"].append(attributedesignator)
            some_value = {"value": 0}
            inner_json["args"].append(some_value)
            self.args.append(inner_json)

    def build_specific_condition(self):
        if self.isnot:
            self.build_not_condition = True
        if self.rule_type == "markings":
            self.set_functionid(function_type=self.ALLOWED_ANY_OR_ALL_DM[self.any_or_all])
            self.build_marking_rule(marking_names=self.marking_names)
        elif self.rule_type == "marking_values":
            self.set_functionid(function_type=self.ALLOWED_ANY_OR_ALL_DMV[self.any_or_all])
            self.build_marking_value_rule(marking_names=self.marking_names, marking_values=self.marking_values)

    def build_marking_rule(self, marking_names):
        self.append_attributedesignator2(category=self.AD_CATEGORY, attr_id=marking_names)

    def build_marking_value_rule(self, marking_names, marking_values):
        self.append_attributevalue(data_type="string", values=marking_values)
        self.append_attributedesignator(category="resource", attr_id=marking_names[0])


class UnMarkedDataCondition(TargetCondition):

    AD_CATEGORY = "resource"

    def __init__(self):
        super().__init__()
        self.build_specific_condition()

    def append_attributedesignator(self, category, attr_id, present=False):
        attributedesignator = {
            "category": category,
            "id": attr_id,
            "mustBePresent": present,
        }
        self.args.append(attributedesignator)

    def build_specific_condition(self):
        self.set_functionid(function_type="boolean-equal")
        self.append_attributevalue(data_type="boolean", values=[False])
        self.append_attributedesignator(category=self.AD_CATEGORY, attr_id="ionic-has-marking", present=True)


class CreatedByUsersCondition(TargetCondition):

    AD_CATEGORY = "resource"
    AD_ID = "created-user-id"

    def __init__(self, userids, isnot=False):
        super().__init__()
        self.userids = userids
        self.isnot = isnot
        self.build_specific_condition()

    def build_specific_condition(self):
        if self.isnot:
            self.build_not_condition = True
        self.set_functionid(function_type="string-at-least-one-member-of")
        self.append_attributevalue(data_type="string", values=self.userids)
        self.append_attributedesignator(category=self.AD_CATEGORY, attr_id=self.AD_ID)


class CreatedByGroupsCondition(TargetCondition):

    AD_CATEGORY = "resource"
    AD_ID = "created-group"

    ALLOWED_ANY_OR_ALL = {
        "any": "string-at-least-one-member-of",
        "all": "string-subset",
    }

    def __init__(self, groupids, isnot=False, any_or_all="any"):
        super().__init__()
        self.groupids = groupids
        self.isnot = isnot
        self.any_or_all = any_or_all
        self.build_specific_condition()

    def build_specific_condition(self):
        self.set_functionid(function_type=self.ALLOWED_ANY_OR_ALL[self.any_or_all])
        if self.isnot:
            self.build_not_condition = True
        self.append_attributevalue(data_type="string", values=self.groupids)
        self.append_attributedesignator(category=self.AD_CATEGORY, attr_id=self.AD_ID)


if __name__ == "__main__":
    # Location True
    # mycat = LocationCondition(["USA", "UK", "AND"], isnot=False)

    # Location False
    # mycat = LocationCondition(["USA", "UK", "AND"], isnot=True)

    # User Match True
    # mycat = UserCondition("match", userids=["12345", "67890"], isnot=False)

    # User Match False
    # mycat = UserCondition("match", userids=["12345", "67890"], isnot=True)

    # User Creator True
    # mycat = UserCondition("creator", isnot=False)

    # User Creator False
    # mycat = UserCondition("creator", isnot=True)

    # User Group Match True
    # mycat = UserGroupCondition("match", groupids=["T1", "T2"], isnot=False, any_or_all="all")

    # User Group Match False
    # mycat = UserGroupCondition("match", groupids=["T1", "T2"], isnot=True)

    # User Group Creator True
    # mycat = UserGroupCondition("creator", isnot=False)

    # User Group Creator False
    # mycat = UserGroupCondition("creator", isnot=True)

    # Relative Date 123 day
    # mycat = RelativeDateCondition("days", 123)

    # Specific Date After
    # mycat = SpecificDateCondition("12345", before_or_after="after")

    # Specific Date Before
    # mycat = SpecificDateCondition(datetime.now(), before_or_after="after")

    # Device is device id
    # mycat = DeviceCondition(device_ids=["D6Sn.A.0d59d9f0-b27d-41f4-a09b-32687a24b383"], isnot=False)

    # Device is not device id
    # mycat = DeviceCondition(device_ids=["D6Sn.A.0d59d9f0-b27d-41f4-a09b-32687a24b383"], isnot=True)

    # IP address is Ionic IP - 38.140.48.58
    # mycat = IPAddressCondition(ips=["38.140.48.58"])

    # IP address is not Ionic IP - 38.140.48.58
    # mycat = IPAddressCondition(ips=["38.140.48.58"], isnot=True)

    # mycat = TargetCondition(marking_id="classification", marking_values=["red"])
    # mycat.build_condition()
    # import json

    # dpt = DataPolicyTarget()
    # # classification_m = MarkedDataCondition(marking_name="classification", marking_values=["red", "blue"])
    # # classification_m.build_condition()
    # #
    # paz_m = MarkedDataCondition(rule_type="markings",
    #                             marking_names=["classification", "DM1", "ionic-detect"],
    #                             marking_values=["red"],
    #                             isnot=False,
    #                             any_or_all="any")
    # paz_m.build_condition()

    # new_rule = DataPolicyRule(effect="Permit", desc="Test1234")
    # jim = AdvancedRuleCondition(attribute1='action-id', attribute2='custom values', custom_values=['a', 'b', 'd'], does_not_equal=True, any_or_all="any")
    # jim.build_condition()
    # new_rule.condition.append(jim.rule_condition)
    # new_rule.build_rule()
    # print(json.dumps(new_rule.rule, sort_keys=True, separators=(',', ': '), indent=4))

    dpt = DataPolicyTarget()
    jim = MarkedDataCondition(
        rule_type="marking_values",
        marking_names=["DM"],
        marking_values=["DMV"],
        isnot=True,
        any_or_all="all",
    )
    jim.build_condition()
    dpt.target_conditions.append(jim.target_condition)
    dpt.build_target()
    print(json.dumps(dpt.target, sort_keys=True, separators=(",", ": "), indent=4))

    # dpt.target_conditions.append(classification_m.target_condition)
    # dpt.target_conditions.append(paz_m.target_condition)
    # unmarked = UnMarkedDataCondition()
    # unmarked.build_condition()
    # unmarked1 = UnMarkedDataCondition(marking_name="paz")
    # unmarked1.build_condition()
    # dpt.target_conditions.append(unmarked.target_condition)
    # dpt.target_conditions.append(paz_m.target_condition)
    #
    # dpt.build_target()
    #
    # print(json.dumps(dpt.target, sort_keys=True, separators=(',', ': '), indent=4))
    # quit()
    #
    # new_rule = DataPolicyRule(effect="Permit", desc="Test123")
    # mycat = UserGroupCondition("creator", isnot=False)
    # mycat.build_condition()
    # mycat2 = UserCondition(rule_type="match", userids=['12345', '67890'], isnot=True)
    # mycat2.build_condition()
    # new_rule.conditions.append(mycat.rule_condition)
    # new_rule.conditions.append(mycat2.rule_condition)
    #
    # new_rule.build_rule()
    # # print(json.dumps(new_rule.rule, sort_keys=True, separators=(',', ': '), indent=4))
    #
    # new_rule = DataPolicyRule(effect="Permit", desc="Test123")
    # loc = LocationCondition(countries=["USA", "ARE"], isnot=True)
    # loc.build_condition()
    # new_rule.condition.append(loc.rule_condition)
    # new_rule.build_rule()
    # print(json.dumps(new_rule.rule, sort_keys=True, separators=(',', ': '), indent=4))
