from pydashboard.pydashboard.base import Base


class History(Base):
    """
    Retrieve History Status information
    """

    SUPPORTED_ENDPOINTS = [
        "applications",
        "policies",
        "markings",
        "scim/Roles",
        "scim/Users",
        "scim/Groups",
        "scim/Devices",
        "enrollmentcfgs",
        "apikeys",
        "cover-pages",
        "login-configs",
        "keyspaces",
        "branding/images",
        "branding/templates",
        "custom-products",
    ]
    DEFAULT_ENDPOINT = "applications"
    DEFAULT_POST_PARAMS = {"limit": 100, "asc": True, "skip": 0}
    DEFAULT_GET_PARAMS = "limit=0&asc=True&skip=0"

    def __init__(self, apiuser, tenantid, history_type):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        :param history_type: "applications", "policies"
        :return:
        """

        if history_type not in self.SUPPORTED_ENDPOINTS:
            raise Exception("Invalid history type %s" % history_type)

        self.apiuser = apiuser
        self.tenantid = tenantid
        self.history_type = history_type

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.history_full = []
        self.history = []

    ######################
    #
    #  HELPER FUNCTIONS
    #
    ######################

    def set_history_type(self, history_type, tenantid=None):
        if history_type not in self.SUPPORTED_ENDPOINTS:
            raise Exception("Invalid history type %s" % history_type)
        else:
            self.history_type = history_type
            if tenantid is not None:
                self.tenantid = tenantid

    def get_baseurl(self):
        return "{resource_url}/{tenantid}/{history_type}/history".format(
            resource_url=self.resource_url,
            tenantid=self.tenantid,
            history_type=self.history_type,
        )

    def get_object_baseurl(self, object):
        return "{resource_url}/{tenantid}/{history_type}/{object_id}".format(
            resource_url=self.resource_url,
            tenantid=self.tenantid,
            history_type=self.history_type,
            object_id=object["id"],
        )

    def get_object_permissions_baseurl(self, object, permissions):
        return "{resource_url}/{tenantid}/{history_type}/{object_id}/permissions/{permissions_id}/history".format(
            resource_url=self.resource_url,
            tenantid=self.tenantid,
            history_type=self.history_type,
            object_id=object["id"],
            permissions_id=permissions["id"],
        )

    def get_object_with_endpoint_base_url(self, endpoint, object):
        return "{resource_url}/{tenantid}/{endpoint}/{object_id}/{history_type}".format(
            resource_url=self.resource_url,
            tenantid=self.tenantid,
            endpoint=endpoint,
            object_id=object["id"],
            history_type=self.history_type,
        )

    ######################
    #
    #  REQUESTS
    #
    ######################

    def request_get_history(self, params=None, method="POST", search=False):
        """
        Request history resources
        :param params: optional params
        :param method: <str> request method
        :return: <requests> response from request
        """
        baseurl = self.get_baseurl()
        if method == "POST":
            if search:
                url = "{baseurl}/.search".format(baseurl=baseurl)
            else:
                url = "{baseurl}/list".format(baseurl=baseurl)
            params = self.get_params(params=params, desired_params=self.DEFAULT_POST_PARAMS)
            return self.session.post(url=url, data=params)
        else:
            url = baseurl
            params = self.get_params(params=params, desired_params=self.DEFAULT_GET_PARAMS)
            return self.session.get(url=url, params=params)

    def get_history(self, params=None, method="POST", search=False):
        """
        Get history resources
        :param params: optional params
        :param method: <str> request method
        :return: <dict> response from request
        """
        response = self.request_get_history(params=params, method=method, search=search)
        return self.get_json_response(response=response)

    def request_get_object_history(self, object, params=None, method="POST"):
        """
        Request object history resources
        :param object: <dict> requesting object
        :param params: optional params
        :param method: <str> request method
        :return: <requests> response from request
        """
        baseurl = self.get_object_baseurl(object=object)
        if method == "POST":
            url = "{baseurl}/history/list".format(baseurl=baseurl)
            params = self.get_params(params=params, desired_params=self.DEFAULT_POST_PARAMS)
            return self.session.post(url=url, data=params)
        else:
            url = baseurl
            params = self.get_params(params=params, desired_params=self.DEFAULT_GET_PARAMS)
            return self.session.get(url=url, params=params)

    def get_object_history(self, object, params=None, method="POST"):
        """
        Get object history resources
        :param object: <dict> requesting object
        :param params: optional params
        :param method: <str> request method
        :return: <dict> object history
        """
        response = self.request_get_object_history(object=object, params=params, method=method)
        return self.get_json_response(response=response)

    def request_get_history_by_log_id(self, log, params=None):
        """
        Request history resources by log id
        :param log: <dict> log object
        :param params: optional params
        :return: <requests> response from GET
        """
        url = "{baseurl}/history/{log_id}".format(baseurl=self.get_baseurl(), log_id=log["id"])
        params = self.get_params(params=params, desired_params=self.DEFAULT_GET_PARAMS)
        return self.session.get(url=url, params=params)

    def get_history_by_log_id(self, log, params=None):
        """
        Get history resources by log id
        :param log: <dict> log object
        :param params: optional params
        :return: <dict> history resources
        """
        response = self.request_get_history_by_log_id(log=log, params=params)
        return self.get_json_response(response=response)

    def request_get_object_history_by_log_id(self, object, log, params=None):
        """
        Request object history resource by log id
        :param object: <dict> object
        :param log: <dict> log object
        :param params: optional params
        :return: <requests> response from GET
        """
        url = "{baseurl}/history/{log_id}".format(baseurl=self.get_object_baseurl(object=object), log_id=log["id"])
        params = self.get_params(params=params, desired_params=self.DEFAULT_GET_PARAMS)
        return self.session.get(url=url, params=params)

    def get_object_history_by_log_id(self, object, log, params=None):
        """
        Get object history resource by log id
        :param object: <dict> object
        :param log: <dict> log object
        :param params: optional params
        :return: <dict> object history by log id
        """
        response = self.request_get_object_history_by_log_id(object=object, log=log, params=params)
        return self.get_json_response(response=response)

    def request_get_object_history_with_endpoint(self, object, endpoint, method="POST", params=None):
        """
        Request get object history with specified endpoint
        :param object: <dict> object
        :param endpoint: <str> endpoint
        :param method: <str> request method
        :param params: optional params
        :return: <requests> response from requests
        """
        baseurl = "{baseurl}/history".format(
            baseurl=self.get_object_with_endpoint_base_url(endpoint=endpoint, object=object))
        if method == "POST":
            url = "{baseurl}/list".format(baseurl=baseurl)
            params = self.get_params(params=params, desired_params=self.DEFAULT_POST_PARAMS)
            return self.session.post(url=url, data=params)
        else:
            url = baseurl
            params = self.get_params(params=params, desired_params=self.DEFAULT_GET_PARAMS)
            return self.session.get(url=url, params=params)

    def get_object_history_with_endpoint(self, object, endpoint, method="POST", params=None):
        """
        Get object history with specified endpoint
        :param object: <dict> object
        :param endpoint: <str> endpoint
        :param method: <str> request method
        :param params: optional params
        :return: <dict> history resources
        """
        response = self.request_get_object_history_with_endpoint(
            object=object, endpoint=endpoint, method=method, params=params)
        return self.get_json_response(response=response)

    def request_get_object_history_with_endpoint_and_object(self, object, endpoint, object2, method="POST",
                                                            params=None):
        """
        Request object history with specified endpoint
        :param object: <dict> object
        :param endpoint: <str> endpoint
        :param object2: <dict> second object
        :param method: <str> request method
        :param params: optional params
        :return: <requests> response from requests
        """
        baseurl = "{baseurl}/{second_object_id}/history".format(
            baseurl=self.get_object_with_endpoint_base_url(endpoint=endpoint, object=object),
            second_object_id=object2["id"],
        )
        if method == "POST":
            url = "{baseurl}/list".format(baseurl=baseurl)
            params = self.get_params(params=params, desired_params=self.DEFAULT_POST_PARAMS)
            return self.session.post(url=url, data=params)
        else:
            url = baseurl
            params = self.get_params(params=params, desired_params=self.DEFAULT_GET_PARAMS)
            return self.session.get(url=url, params=params)

    def get_object_history_with_endpoint_and_object(self, object, endpoint, object2, method="POST", params=None):
        """
        Request object history with specified endpoint
        :param object: <dict> object
        :param endpoint: <str> endpoint
        :param object2: <dict> second object
        :param method: <str> request method
        :param params: optional params
        :return: <dict> history resources
        """
        response = self.request_get_object_history_with_endpoint_and_object(
            object=object,
            endpoint=endpoint,
            object2=object2,
            method=method,
            params=params,
        )
        return self.get_json_response(response=response)

    def request_get_object_permissions_history(self, object, permissions, params=None, method="POST"):
        """
        Request get object permissions history
        :param object: <dict> object
        :param permissions: <dict> permissions
        :param params: optional params
        :param method: <str> request method
        :return: <requests> response from requests
        """
        baseurl = "{baseurl}/permissions/{permissions_id}/history".format(
            baseurl=self.get_object_baseurl(object=object),
            permissions_id=permissions["id"],
        )
        if method == "POST":
            url = "{baseurl}/list".format(baseurl=baseurl)
            params = self.get_params(params=params, desired_params=self.DEFAULT_POST_PARAMS)
            return self.session.post(url=url, data=params)
        else:
            url = baseurl
            params = self.get_params(params=params, desired_params=self.DEFAULT_GET_PARAMS)
            return self.session.get(url=url, params=params)

    def get_object_permissions_history(self, object, permissions, params=None, method="POST"):
        """
        Request get object permissions history
        :param object: <dict> object
        :param permissions: <dict> permissions
        :param params: optional params
        :param method: <str> request method
        :return: <dict> object permissions history
        """
        response = self.request_get_object_permissions_history(
            object=object, permissions=permissions, params=params, method=method)
        self.get_json_response(response=response)
