from pydashboard.pydashboard.base import Base


class Settings(Base):
    """
    Retrieve Settings for a Tenant
    """

    VALID_PASSWORD_OPTIONS = [
        "numbers",
        "lowerCase",
        "upperCase",
        "history",
        "specialCharacters",
        "rotation",
        "minLength",
        "expire",
    ]

    PRODUCTS_ENABLE_DISABLE = {"enable": "stable", "disable": "none"}

    DEFAULT_MIN_PASS_LEN = 10
    DEFAULT_MAX_LOGIN_ATTEMPTS = 3
    DEFAULT_LOCKOUT_DUR = 1440
    DEFAULT_SESSION_TIMEOUT = 15
    DEFAULT_USER_MERGE = "email"
    DEFAULT_LOWERCASE = False
    DEFAULT_UPPERCASE = True
    DEFAULT_NUMBERS = True
    DEFAULT_SPECIAL_CHARS = False
    DEFAULT_CLOUD_DISCOVERY = True
    DEFAULT_DISABLE_POLICY_CACHE = True
    DEFAULT_USER_FEEDBACK = False
    DEFAULT_METRICS = False
    DEFAULT_ACTIVITY = False
    DEFAULT_APPLICATION_POLICY = False

    def __init__(self, apiuser, tenantid, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        :param refresh_on_init: <boolean> Whether to refresh data policies upon initialization
        :return:
        """
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.settings = {}
        self.baseurl = "{url}/tenants/{tenantid}".format(url=self.resource_url, tenantid=tenantid)

        if refresh_on_init:
            self.refresh()

    def refresh(self):
        self.settings = self.get_settings()

    def request_get_settings(self):
        """
        Retrieve settings
        :return: <requests> response from GET
        """
        url = self.baseurl
        return self.session.get(url)

    def get_settings(self):
        """
        Retrieve settings
        :return: <dict> settings if successful otherwise empty
        """
        response = self.request_get_settings()
        return self.get_json_response(response=response)

    def request_update_settings(self, settings, repeat_failed_request=True):
        """
        Update settings
        :return: <requests> response from UPDATE
        """
        url = self.baseurl
        return self.session.put(url, data=settings, repeat_failed_request=repeat_failed_request)

    def update_settings(self, settings):
        """
        Update settings with the provided settings
        :param settings: <dict> new setting values
        :return: <dict> new settings if successful other empty
        """
        updated_settings = {}
        if "_next_version" not in settings:
            settings["_next_version"] = int(settings["_version"]) + 1
        response = self.request_update_settings(settings=settings)
        return self.get_json_response(response=response)

    def reset_settings_to_default_values(self, settings=None):
        """
        Reset default settings values
        :param settings: <dict> current settings values
        :return: <dict> default settings values
        """
        if settings is None:
            self.refresh()
            settings = self.settings
        settings["settings"]["password"]["minLength"] = self.DEFAULT_MIN_PASS_LEN
        settings["settings"]["password"]["lowerCase"] = self.DEFAULT_LOWERCASE
        settings["settings"]["password"]["upperCase"] = self.DEFAULT_UPPERCASE
        settings["settings"]["password"]["numbers"] = self.DEFAULT_NUMBERS
        settings["settings"]["password"]["specialCharacters"] = self.DEFAULT_SPECIAL_CHARS
        if "login" not in settings:
            login_settings = {
                "maxLoginAttempts": self.DEFAULT_MAX_LOGIN_ATTEMPTS,
                "lockoutDuration": self.DEFAULT_LOCKOUT_DUR,
            }
            settings["settings"]["login"] = login_settings
        settings["settings"]["userMergeField"] = self.DEFAULT_USER_MERGE
        settings["settings"]["session"]["timeout"] = self.DEFAULT_SESSION_TIMEOUT
        settings["settings"]["cloudDiscovery"] = self.DEFAULT_CLOUD_DISCOVERY
        settings["settings"]["disablePolicyCache"] = self.DEFAULT_DISABLE_POLICY_CACHE
        settings["settings"]["userFeedback"]["enabled"] = self.DEFAULT_USER_FEEDBACK
        settings["settings"]["metrics"] = self.DEFAULT_METRICS
        settings["settings"]["analytics"]["activity"]["enabled"] = self.DEFAULT_ACTIVITY
        settings["settings"]["analytics"]["applicationPolicy"]["enabled"] = self.DEFAULT_APPLICATION_POLICY

        response = self.update_settings(settings=settings)
        return response

    def enable_cloud_discovery(self, settings):
        """
        Enable Cloud Discovery
        :param settings: <dict> settings to update
        :return: <dict> updated settings
        """
        settings["settings"]["cloudDiscovery"] = True
        return self.update_settings(settings=settings)

    def disable_cloud_discovery(self, settings):
        """
        Disable Cloud Discovery
        :param settings: <dict> settings to updated
        :return: <dict> updated settings
        """
        settings["settings"]["cloudDiscovery"] = False
        return self.update_settings(settings=settings)

    def enable_policy_cache(self, settings):
        """
        Enable Policy Cache
        :param settings: <dict> settings to update
        :return: <dict> updated settings
        """
        settings["settings"]["disablePolicyCache"] = True
        return self.update_settings(settings=settings)

    def disable_policy_cache(self, settings):
        """
        Disable Policy Cache
        :param settings: <dict> settings to update
        :return: <dict> updated settings
        """
        settings["settings"]["disablePolicyCache"] = False
        return self.update_settings(settings=settings)

    def update_enrollmenturl(self, settings, enrollmenturl):
        """
        Update the Enrollment URL
        :param settings: <dict> settings to update
        :param enrollmenturl: <string> new enrollment url
        :return: <dict> updated settings
        """
        settings["settings"]["enrollmentUrl"] = enrollmenturl
        return self.update_settings(settings=settings)

    def update_password_strength(self, settings, **kwargs):
        password_strength = settings["settings"]["password"]
        if kwargs is not None:
            for k, v in kwargs.items():
                if k in self.VALID_PASSWORD_OPTIONS:
                    password_strength[k] = v

                else:
                    print("fix %s" % (k))

        settings["settings"]["password"] = password_strength
        return self.update_settings(settings=settings)

    def enable_disable_products(self, settings, products_to_update, type, all_products):
        """
        enable products in settings page
        :param settings: <dict> JSON Object
        :param all_products: <list> list of all the products
        :param products_to_update: <list> list of products to make changes to
        :param type: <string> e.g. 'enable' / 'disable'
        :return: updated settings
        """
        if type not in self.PRODUCTS_ENABLE_DISABLE:
            raise Exception("%s is not a valid option (%s)" % (type, list(self.PRODUCTS_ENABLE_DISABLE.keys())))

        enable_disable_setting = self.PRODUCTS_ENABLE_DISABLE[type]
        new_settings_product_list = {}
        settings_products_list = settings["settings"]["products"]

        for csa_product in all_products:
            # If the product has no versions ignore
            total_versions = csa_product["versions"]["totalResults"]
            if total_versions == 0:
                continue
            csaproductid = csa_product["id"]

            if csaproductid in settings_products_list:
                # Get the current download statuses and build a
                # new_settings_product_list object with the current statuses
                current_download_status = settings_products_list[csaproductid]["download"]
                new_settings_product_list[csaproductid] = {
                    "id": csaproductid,
                    "download": current_download_status,
                }
            else:
                # If csa product is not in TA setting spec object, then append that csa product to TA spec
                new_settings_product_list[csaproductid] = {
                    "id": csaproductid,
                    "download": "none",
                }

        if products_to_update:
            # The products to update, retrieve there product ids and
            # fish it out in new_settings_product_list and navigate
            # to "download" and update the status.
            for each_product in products_to_update:
                productid = each_product["id"]
                new_settings_product_list[productid]["download"] = enable_disable_setting
        settings["settings"]["products"] = new_settings_product_list
        return self.update_settings(settings=settings)

    def enable_products(self, settings, products_to_update, all_products):
        """
        enable products in settings page
        :param settings: <dict> JSON Object
        :param all_products: <list> list of all the products
        :param products_to_update: <list> list of products to make changes to
        :return: updated settings
        """
        return self.enable_disable_products(
            settings=settings,
            products_to_update=products_to_update,
            type="enable",
            all_products=all_products,
        )

    def disable_products(self, settings, products_to_update, all_products):
        """
        disable products in settings page
        :param settings: <dict> JSON Object
        :param all_products: <list> list of all the products
        :param products_to_update: <list> list of products to make changes to
        :return: updated settings
        """
        return self.enable_disable_products(
            settings=settings,
            type="disable",
            products_to_update=products_to_update,
            all_products=all_products,
        )

    def update_product_versions(self, settings, all_products, products_to_update=[]):
        """
        Update Product version available for download.
        :param products_to_update: list of tuples.
        e.g product_to_update = [(product1, versionx), (product2, versiony)]
        """
        new_settings_product_list = {}
        settings_products_list = settings["settings"]["products"]
        for csa_product in all_products:
            # If the product has no versions ignore
            total_versions = csa_product["versions"]["totalResults"]
            if total_versions == 0:
                continue
            csaproductid = csa_product["id"]

            if csaproductid in settings_products_list:
                # Get the current download statuses and build a
                # new_settings_product_list object with the current statuses
                current_download_status = settings_products_list[csaproductid]["download"]
                new_settings_product_list[csaproductid] = {
                    "id": csaproductid,
                    "download": current_download_status,
                }
            else:
                # If csa product is not in TA setting spec object, then append that csa product to TA spec
                new_settings_product_list[csaproductid] = {
                    "id": csaproductid,
                    "download": "none",
                }

        if products_to_update:
            # The products to update, retrieve there product ids and
            # fish it out in new_settings_product_list and navigate
            # to "download" and update the download status to include the product version ID.
            for each_product in products_to_update:
                product = each_product[0]
                product_version = each_product[1]
                new_settings_product_list[product["id"]]["download"] = product_version["id"]
        settings["settings"]["products"] = new_settings_product_list
        return self.update_settings(settings=settings)

    def update_lockout_time(self, settings, max_login_attempts=10, lockout_duration=10):
        if "login" not in settings["settings"]:
            settings["settings"]["login"] = {}
        settings["settings"]["login"]["maxLoginAttempts"] = max_login_attempts
        settings["settings"]["login"]["lockoutDuration"] = lockout_duration
        return self.update_settings(settings=settings)
