# -*- coding: utf-8 -*-

import base64
import json
import logging
import os
import time
import uuid
from mimetypes import MimeTypes

import requests
from requests_toolbelt.multipart.encoder import MultipartEncoder

from pydashboard.pydashboard.base import Base
from pydashboard.pydashboard.hmac_auth import HmacAuth

log = logging.getLogger("pydashboard")


class AuthApiUser(Base):
    """
    Authenticate API User
    """

    VALID_LOGIN_TYPES = {"dashboard": "",
                         "api": "/v2",
                         "hmac": "/v2",
                         "oauth": "/v2"}

    def __init__(
            self,
            resource_url,
            usr,
            pwd,
            tenantid=None,
            login_on_init=True,
            load_tenant_info=True,
            login_type=None,
            csa=True,
    ):
        """
        Authenticate as a CSA or user with API access to their tenant
        If no tenantid is provided - the usr/pwd provided should be for a CSA account
        If a tenantid is provided - the usr/pwd provided should be for a Tenant Admin for that tenant.
        :param resource_url: dashboard url e.g 'https://dashboard.ionic.engineering'
        :param usr: email, username or apikey — depends on user's method of authentication
        :param pwd: password or secret — depends on user's method of authentiction
        :param tenantid: Optional - user's tenantid
        :param login_on_init: If True - Will attempt to login and set api keys. Otherwise those methods need to be
            called.
        :return:
        """


        self.login_type = login_type

        if self.login_type not in list(self.VALID_LOGIN_TYPES.keys()):
            raise Exception("Invalid Login Type! Expected one of: %s" % list(self.VALID_LOGIN_TYPES.keys()))

        self.resource_url = "%s%s" % (resource_url, self.VALID_LOGIN_TYPES[login_type])
        self.usr = usr
        self.pwd = pwd
        self.tenantid = tenantid
        self.login_url = ""

        if login_type == "hmac":
            self.session = MySession(requests.Session(), api_key_id=self.usr, secret=self.pwd)
            if not self.resource_url.startswith("http"):
                self.resource_url = "https://" + self.resource_url
        else:
            self.session = MySession(requests.Session())

        if login_type == "dashboard":
            if login_on_init:
                resp = self.request_login()
                if resp.status_code == 200:
                    self.set_api_keys(login_response=resp, refresh_on_init=load_tenant_info)
                else:
                    self.session.close_session()
                    raise Exception("Login Issue: %s" % (resp.text))

        if login_type == "api":
            if not self.resource_url.startswith("http"):
                self.resource_url = "https://" + self.resource_url
            self.session.requests_session.headers["Authorization"] = "Basic %s" % self.get_basic_auth_header(
                username=self.usr,
                password=self.pwd)

        if login_type == "oauth":
            if not self.resource_url.startswith("http"):
                self.resource_url = "https://" + self.resource_url
            self.session.requests_session.headers["Authorization"] = "Bearer %s" % self.pwd
        if csa:
            self.session.requests_session.headers["X-Auth-Tenant-Id"] = tenantid

    @staticmethod
    def get_basic_auth_header(username, password):
        login_format = "{}:{}".format(username, password)
        return base64.b64encode(bytes(login_format, encoding="utf-8")).decode("utf-8")

    def request_login(self):
        # Check if email is being used
        if "@" in self.usr:
            payload = {"password": self.pwd, "email": self.usr}
        else:
            payload = {"password": self.pwd, "userName": self.usr}
        if self.tenantid:
            url = "{}/{}/auth/login".format(self.resource_url, self.tenantid)
        else:
            url = "{}/auth/login".format(self.resource_url)
        self.login_url = url
        return self.session.login_post(url=self.login_url, data=payload)

    def set_api_keys(self, login_response, refresh_on_init):

        if login_response.status_code is not 200:
            return

        self.tenants = Tenants(
            apiuser=self,
            resource_url=self.resource_url,
            tenantid=self.tenantid,
            refresh_on_init=refresh_on_init,
        )

    def close_session(self):
        self.session.close_session()


class MySession:
    """
    Wrapper class for requests/sessions
    """

    CONTENT_TYPE_HEADER = "Content-Type"
    JSON_HEADER = "application/json"

    SHOULD_WAIT_TIME = 0.5  # Number of seconds to wait between failed requests
    CODES = requests.codes

    STATUS_OK = requests.codes.ok
    STATUS_UNAUTHORIZED = requests.codes.unauthorized
    GOOD_STATUSES = [
        requests.codes.ok,  # 200
        requests.codes.created,  # 201
        requests.codes.no_content,  # 204
    ]

    def __init__(self, requests_session, api_key_id=None, secret=None):
        self.requests_session = requests_session
        self.api_key_id = api_key_id
        self.secret = secret
        if self.secret is None:
            self.requests_session.headers[self.CONTENT_TYPE_HEADER] = self.JSON_HEADER

    @staticmethod
    def log_lines(log_type, method):
        log.info("___________________________________")
        log.info("_____________%s %s ____________" % (log_type, method))
        log.info("___________________________________")

    def log_start(self, method):
        self.log_lines(log_type="START", method=method.upper())

    def log_end(self, method):
        self.log_lines(log_type="END", method=method.upper())

    @staticmethod
    def log_request_failed():
        log.info("___________________________________")
        log.info("REQUEST FAILED - TRY ONE MORE TIME PLEASE")
        log.info("___________________________________")

    def get(self, url, params=None, repeat_failed_request=True, log_header=True):

        get_method = "get"

        params = params if params else {}

        if log_header:
            self.log_start(method=get_method)
        self.add_cid_header()

        log.info("GET URL:{}".format(url))
        log.info("PARAMS:{}".format(params))
        log.info("HEADERS:{}".format(self.requests_session.headers))
        log.info("COOKIES:{}".format(self.requests_session.cookies))

        if self.secret is None:
            resp = self.requests_session.get(url, params=params)
        else:
            resp = self.requests_session.get(url, auth=HmacAuth(api_key=self.api_key_id, api_secret=self.secret))

        log.info("STATUS_CODE:{}".format(resp.status_code))
        log.info("RESPONSE:{}".format(resp.text))

        if resp.status_code not in self.GOOD_STATUSES and repeat_failed_request:
            self.log_request_failed()
            resp = self.get(url=url, params=params, repeat_failed_request=False, log_header=False)
        if log_header:
            self.log_end(method=get_method)
        return resp

    def put(self, url, data, should_wait=True, repeat_failed_request=True, log_header=True):

        put_method = "put"

        if log_header:
            self.log_start(method=put_method)

        if should_wait:
            time.sleep(self.SHOULD_WAIT_TIME)

        self.add_cid_header()

        log.info("PUT URL:{}".format(url))
        log.info("DATA:{}".format(json.dumps(data)))
        log.info("HEADERS:{}".format(self.requests_session.headers))
        log.info("COOKIES:{}".format(self.requests_session.cookies))

        if self.secret is None:
            resp = self.requests_session.put(url=url, data=json.dumps(data))
        else:
            resp = self.requests_session.put(
                url,
                data=json.dumps(data),
                auth=HmacAuth(api_key=self.api_key_id, api_secret=self.secret),
            )

        log.info("STATUS_CODE:{}".format(resp.status_code))
        log.info("RESPONSE:{}".format(resp.text))

        if resp.status_code not in self.GOOD_STATUSES and repeat_failed_request:
            self.log_request_failed()
            resp = self.put(url=url, data=data, repeat_failed_request=False, log_header=False)

        if log_header:
            self.log_end(method=put_method)
        return resp

    def post(self, url, data, should_wait=True, repeat_failed_request=False, log_header=True):

        post_method = "post"

        if log_header:
            self.log_start(method=post_method)

        if should_wait:
            time.sleep(self.SHOULD_WAIT_TIME)

        self.add_cid_header()
        url = url.strip("/")  # removing trailing slash for all requests except for login
        log.info("POST URL:{}".format(url))
        log.info("DATA:{}".format(json.dumps(data)))
        log.info("HEADERS:{}".format(self.requests_session.headers))
        log.info("COOKIES:{}".format(self.requests_session.cookies))
        if self.secret is None:
            resp = self.requests_session.post(url=url, data=json.dumps(data))
        else:
            resp = self.requests_session.post(
                url,
                data=json.dumps(data),
                auth=HmacAuth(api_key=self.api_key_id, api_secret=self.secret),
            )

        log.info("STATUS_CODE:{}".format(resp.status_code))
        log.info("RESPONSE:{}".format(resp.text))

        if resp.status_code not in self.GOOD_STATUSES and repeat_failed_request:
            self.log_request_failed()
            resp = self.post(url=url, data=data, repeat_failed_request=False, log_header=False)

        if log_header:
            self.log_end(method=post_method)
        return resp

    @staticmethod
    def get_file_content_type(file_path):
        return MimeTypes().guess_type(file_path)

    def post_with_file(
            self,
            url,
            data,
            file_path,
            file_name,
            should_wait=True,
            repeat_failed_request=True,
            log_header=True,
    ):

        post_with_file_method = "post_with_file"

        if log_header:
            self.log_start(method=post_with_file_method)
        if should_wait:
            time.sleep(self.SHOULD_WAIT_TIME)

        self.add_cid_header()
        url = url.strip("/")  # removing trailing slash for all requests except for login
        log.info("POST URL:{}".format(url))
        log.info("DATA:{}".format(json.dumps(data)))
        log.info("HEADERS:{}".format(self.requests_session.headers))
        log.info("COOKIES:{}".format(self.requests_session.cookies))

        fields = {}
        fields.update(data)
        fields["file"] = (
            file_name,
            open(file_path, "rb"),
            self.get_file_content_type(file_path=file_path),
        )
        log.info("FIELDS:{}".format(fields))

        encoder = MultipartEncoder(fields=fields)

        self.requests_session.headers[self.CONTENT_TYPE_HEADER] = encoder.content_type

        resp = self.requests_session.post(url=url, data=encoder)
        self.requests_session.headers[self.CONTENT_TYPE_HEADER] = self.JSON_HEADER

        log.info("STATUS_CODE:{}".format(resp.status_code))
        log.info("RESPONSE:{}".format(resp.text))

        if resp.status_code not in self.GOOD_STATUSES and repeat_failed_request:
            self.log_request_failed()
            resp = self.post_with_file(
                url=url,
                data=data,
                file_path=file_path,
                file_name=file_name,
                repeat_failed_request=False,
                log_header=False,
            )

        if log_header:
            self.log_end(method=post_with_file_method)

        return resp

    def put_with_file(
            self,
            url,
            data,
            file_path,
            file_name,
            should_wait=True,
            repeat_failed_request=True,
            log_header=True,
    ):

        put_with_file_method = "put_with_file"

        if log_header:
            self.log_start(method=put_with_file_method)
        if should_wait:
            time.sleep(self.SHOULD_WAIT_TIME)

        self.add_cid_header()
        url = url.strip("/")  # removing trailing slash for all requests except for login
        log.info("PUT URL:{}".format(url))
        log.info("DATA:{}".format(json.dumps(data)))
        log.info("HEADERS:{}".format(self.requests_session.headers))
        log.info("COOKIES:{}".format(self.requests_session.cookies))

        fields = {}
        fields.update(data)
        fields["file"] = (
            file_name,
            open(file_path, "rb"),
            self.get_file_content_type(file_path=file_path),
        )
        log.info("FIELDS:{}".format(fields))

        encoder = MultipartEncoder(fields=fields)

        self.requests_session.headers[self.CONTENT_TYPE_HEADER] = encoder.content_type

        resp = self.requests_session.put(url=url, data=encoder)
        self.requests_session.headers[self.CONTENT_TYPE_HEADER] = self.JSON_HEADER

        log.info("STATUS_CODE:{}".format(resp.status_code))
        log.info("RESPONSE:{}".format(resp.text))

        if resp.status_code not in self.GOOD_STATUSES and repeat_failed_request:
            self.log_request_failed()
            resp = self.put_with_file(
                url=url,
                data=data,
                file_path=file_path,
                file_name=file_name,
                repeat_failed_request=False,
                log_header=False,
            )

        if log_header:
            self.log_end(method=put_with_file_method)

        return resp

    def delete(self, url, repeat_failed_request=True, log_header=True):

        delete_method = "delete"

        if log_header:
            self.log_start(method=delete_method)

        self.add_cid_header()
        log.info("DELETE URL:{}".format(url))
        log.info("HEADERS:{}".format(self.requests_session.headers))
        log.info("COOKIES:{}".format(self.requests_session.cookies))

        if self.secret is None:
            resp = self.requests_session.delete(url=url)
        else:
            resp = self.requests_session.delete(url, auth=HmacAuth(api_key=self.api_key_id, api_secret=self.secret))

        log.info("STATUS_CODE:{}".format(resp.status_code))
        log.info("RESPONSE:{}".format(resp.text))

        if resp.status_code not in self.GOOD_STATUSES and repeat_failed_request:
            self.log_request_failed()
            resp = self.delete(url=url, repeat_failed_request=False, log_header=False)

        if log_header:
            self.log_end(method=delete_method)

        return resp

    def options(self, url, log_header=True):

        options_method = "options"

        if log_header:
            self.log_start(method=options_method)

        self.add_cid_header()
        log.info("OPTIONS URL:{}".format(url))
        log.info("HEADERS:{}".format(self.requests_session.headers))
        log.info("COOKIES:{}".format(self.requests_session.cookies))
        resp = self.requests_session.options(url=url)
        log.info("STATUS_CODE:{}".format(resp.status_code))
        log.info("RESPONSE:{}".format(resp.text))

        if log_header:
            self.log_end(method=options_method)

        return resp

    def patch(self, url, data, log_header=True):

        patch_method = "patch"

        if log_header:
            self.log_start(method=patch_method)

        self.add_cid_header()
        log.info("PATCH URL:{}".format(url))
        log.info("DATA:{}".format(json.dumps(data)))
        log.info("HEADERS:{}".format(self.requests_session.headers))
        log.info("COOKIES:{}".format(self.requests_session.cookies))
        if self.secret is None:
            resp = self.requests_session.patch(url=url, data=json.dumps(data))
        else:
            resp = self.requests_session.patch(
                url,
                data=json.dumps(data),
                auth=HmacAuth(api_key=self.api_key_id, api_secret=self.secret),
            )

        log.info("STATUS_CODE:{}".format(resp.status_code))
        log.info("RESPONSE:{}".format(resp.text))

        if log_header:
            self.log_end(method=patch_method)

        return resp

    def login_post(self, url, data, log_header=True):

        login_post_method = "login_post"

        if log_header:
            self.log_start(method=login_post_method)

        self.add_cid_header()
        log.info("POST URL:{}".format(url))
        log.info("DATA:{}".format(json.dumps(data)))
        log.info("HEADERS:{}".format(self.requests_session.headers))
        log.info("COOKIES:{}".format(self.requests_session.cookies))

        resp = self.requests_session.post(url=url, data=json.dumps(data))

        xsrf_token = resp.cookies.get("XSRF-TOKEN")
        csrf_token = resp.cookies.get("csrf_token")
        session_cookies = resp.cookies.get("session")
        log.info("COOKIE XSRF-TOKEN: {}".format(xsrf_token))
        log.info("COOKIE SESSION: {}".format(session_cookies))
        self.requests_session.headers["X-XSRF-TOKEN"] = xsrf_token
        self.requests_session.headers["X-CSRF-TOKEN"] = csrf_token

        log.info("STATUS_CODE:{}".format(resp.status_code))
        log.info("RESPONSE:{}".format(resp.text))

        if log_header:
            self.log_end(method=login_post_method)

        return resp

    def download_file(self, url, target_location, log_header=True):
        """
        Download files which have no auth
        """

        download_file_method = "download_file"

        if log_header:
            self.log_start(method=download_file_method)
        log.info(download_file_method)
        log.info("URL: {}".format(url))
        log.info("TARGET: {}".format(target_location))

        with open(os.path.abspath(target_location), "wb") as file:
            r = self.get(url)
            file.write(r.content)

        return r

    def add_x_api_key(self, x_api_key):
        self.requests_session.headers["X-API-KEY"] = x_api_key

    def close_session(self):
        self.requests_session.close()

    def add_cid_header(self):
        cid = "CID|" + str(uuid.uuid1())
        log.info("CREATE CID: {}".format(cid))
        self.requests_session.headers["X-Conversation-Id"] = cid

    # Uncomment and use when debugging a problem
    # def pretty_json(self, contents):
    #    return json.dumps(contents, sort_keys=True, separators=(',', ': '), indent=2)


class Tenants:
    """
    Obtain Tenant information
    """

    def __init__(self, apiuser, resource_url, tenantid="", refresh_on_init=True):
        self.apiuser = apiuser
        self.tenantid = tenantid
        self.tenant_info = None
        self.tenant_spec = None
        self.api_keys = None

        self.session = self.apiuser.session
        self.resource_url = resource_url
        if refresh_on_init:
            self.refresh()

    def refresh(self):
        self.tenant_info, self.tenant_spec = self.get_tenants()
        self.api_keys = {}
        # self.find_apikeys()

    def request_tenants(self):
        url = "{}/tenants/{}".format(self.resource_url, self.tenantid)
        return self.session.get(url)

    def get_tenants(self):
        """
        Returns tenant information
        If no tenant ID is provided - a list of all tenants is returned
        If a tenant ID is provide only that tenant spec is returned (no list)

        tenant_info = the payload returned from the 'tenant' query
        tenant_spec is a dictionary with tenant ids as the keys. The values represent the tenant info
        """

        tenant_info = {}
        tenant_spec = {}
        resp = self.request_tenants()
        if resp.status_code == self.session.STATUS_OK:
            tenant_info = resp.json()
            if self.tenantid != "":
                tenant_info = [tenant_info]
                tenant_spec = self.get_tenant_spec(t_info=tenant_info)
        else:
            log.error("User does not have the appropriate permissions to request tenants")
        return tenant_info, tenant_spec

    @staticmethod
    def get_tenant_spec(t_info):
        tenant_spec = {}
        for each_tenant in t_info:
            tenant_spec[each_tenant["id"]] = each_tenant
        return tenant_spec

    def find_apikeys(self):
        for t_info in self.tenant_info:
            self.api_keys[t_info["id"]] = t_info["_ionic_api_key"]


def main():
    import pickle
    import argparse

    parser = argparse.ArgumentParser(description="Authentication with Ionic Dashboard")
    parser.add_argument(
        "--resource_url",
        "-d",
        required=True,
        help="URL of the Dashboard (without Tenant ID)",
    )
    parser.add_argument("--tenantid", "-t", required=True, help="Tenant ID")
    parser.add_argument("--username", "-u", required=True, help="Tenant Admin Username")
    parser.add_argument("--password", "-p", required=True, help="Tenant Admin Password")
    parser.add_argument(
        "--authfileout",
        "-f",
        required=True,
        help="Filename to save the credentials and session info",
    )
    args = parser.parse_args()

    save_to_file = vars(args)  # Add the input arguments to the file

    api_user = AuthApiUser(
        resource_url=args.resource_url,
        usr=args.username,
        pwd=args.password,
        tenantid=args.tenantid,
        login_on_init=False,
        load_tenant_info=False,
    )

    api_user.request_login()
    save_to_file["session"] = api_user.session
    pickle.dump(save_to_file, open(args.authfileout, "wb"))


if __name__ == "__main__":
    main()
