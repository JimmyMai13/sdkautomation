from pydashboard.pydashboard.base import Base


class Countries(Base):

    #DEFAULT_POST_PARAMS = {"limit": 20, "skip": 0}

    def __init__(self, apiuser, refresh_on_init=True):
        self.apiuser = apiuser
        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url
        self.countries_full = {}

        if refresh_on_init:
            self.refresh()

    def get_baseurl(self):
        return "{}/countries".format(self.resource_url)

    def refresh(self):
        self.countries_full = self.get_countries()
        self.countries = self.countries_full.get("Resources")

    def request_get_countries(self, params=None, method="POST", country_self=None):
        if method == "POST":
            if params is None:
                params = dict()
            url = "{baseurl}/list".format(baseurl=self.get_baseurl())
            return self.session.post(url, data=params)
        elif country_self is not None:
            url = "{baseurl}/self".format(baseurl=self.get_baseurl())
            return self.session.get(url, params=params)
        else:
            url = self.get_baseurl()
            return self.session.get(url, params=params)

    def get_countries(self, params=None, method="POST"):
        response = self.request_get_countries(method=method, params=params)
        return self.get_json_response(response=response)
