from pydashboard.pydashboard.base import Base


class MissionControl(Base):
    """
    Access Mission Control Data
    """

    def __init__(self, apiuser, tenantid, refresh_on_init=False):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        :param refresh_on_init: <boolean> Whether to refresh data policies upon initialization
        :return:
        """
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.cloud_discovery = {}
        self.app_policy = {}
        self.data_policy = {}
        self.registration = {}

        if refresh_on_init:
            self.refresh()

    def refresh(self, size_value=10, from_value=0, gte="now-15m", lte="now"):
        self.cloud_discovery = self.get_cloud_discovery(size_value=size_value, from_value=from_value, gte=gte, lte=lte)
        self.app_policy = self.get_app_policy(size_value=size_value, from_value=from_value, gte=gte, lte=lte)
        self.data_policy = self.get_data_policy(size_value=size_value, from_value=from_value, gte=gte, lte=lte)
        self.registration = self.get_registration(size_value=size_value, from_value=from_value, gte=gte, lte=lte)

    def get_baseurl_mc(self):
        return "%s/%s/elasticsearch_queries" % (self.resource_url, self.tenantid)

    def request_mc_data(self, filter):
        """
        Retrieve Mission Control Data
        :param filter: <dict> filter for the type of data being requested
        :return: <requests> response from POST
        """
        return self.session.post(url=self.get_baseurl_mc(), data=filter)

    def get_request_mc_data(self, filter):
        """
        Retrieve Mission Control Data
        :param filter: <dict> filter for the type of data being requested
        :return: <dict> mission control data if successful otherwise empty
        """
        response = self.request_mc_data(filter=filter)
        return self.get_json_response(response=response)

    def get_hits_from_data(self, full_mc_request):
        """
        Parse out the relevant object in the full request
        :param full_mc_request: <dict> full response from the request for MC data
        :return:
        """
        return full_mc_request["hits"]["hits"]

    def cloud_discovery_index_name(self):
        return "messages-clouddiscovery"

    def app_policy_index_name(self):
        return "messages-arm"

    def data_policy_index_name(self):
        return "keytrans"

    def registration_index_name(self):
        return "messages-registration"

    def get_cloud_discovery(self, size_value=10, from_value=0, gte="now-15m", lte="now"):

        my_filter = self.general_filter(
            index_name=self.cloud_discovery_index_name(),
            size_value=size_value,
            from_value=from_value,
            gte=gte,
            lte=lte,
        )
        return self.get_request_mc_data(filter=my_filter)

    def get_app_policy(self, size_value=10, from_value=0, gte="now-15m", lte="now"):

        my_filter = self.general_filter(
            index_name=self.app_policy_index_name(),
            size_value=size_value,
            from_value=from_value,
            gte=gte,
            lte=lte,
        )
        return self.get_request_mc_data(filter=my_filter)

    def get_data_policy(self, size_value=10, from_value=0, gte="now-15m", lte="now"):

        my_filter = self.general_filter(
            index_name=self.data_policy_index_name(),
            size_value=size_value,
            from_value=from_value,
            gte=gte,
            lte=lte,
        )
        return self.get_request_mc_data(filter=my_filter)

    def get_registration(self, size_value=10, from_value=0, gte="now-15m", lte="now"):

        my_filter = self.general_filter(
            index_name=self.registration_index_name(),
            size_value=size_value,
            from_value=from_value,
            gte=gte,
            lte=lte,
        )
        return self.get_request_mc_data(filter=my_filter)

    def general_filter(self, index_name, size_value, from_value, gte, lte):
        return {
            "index": index_name,
            "query": {
                "from": from_value,
                "size": size_value,
                "filter": {
                    "bool": {
                        # "must_not": [
                        #     {
                        #         "regexp": {
                        #             "message.type": ".*allowed"
                        #         }
                        #     }
                        # ],
                        "must": [{
                            "range": {
                                "Timestamp": {
                                    "gte": gte + "/h",
                                    "lte": lte + "/h"
                                }
                            }
                        }]
                    }
                },
                "sort": [{
                    "Timestamp": {
                        "order": "desc",
                        "unmapped_type": "date",
                        "mode": "sum",
                    }
                }],
            },
        }

    def dataprotected(self, dataprotected_name, dataprotected_value):
        data = {
            "query": {
                "query": {
                    "filtered": {
                        "filter": {
                            "bool": {
                                "must": [
                                    {
                                        "term": {
                                            "data_markings.parent": dataprotected_name
                                        }
                                    },
                                    {
                                        "term": {
                                            "data_markings.values": dataprotected_value
                                        }
                                    },
                                    {
                                        "term": {
                                            "action": "create"
                                        }
                                    },
                                    {
                                        "range": {
                                            "Timestamp": {
                                                "gte": "now-1M",
                                                "lte": "now"
                                            }
                                        }
                                    },
                                ]
                            }
                        }
                    }
                },
                "size": 0,
                "aggs": {
                    "dataMarkingValue": {
                        "terms": {
                            "field": "data_markings.values"
                        }
                    }
                },
            },
            "index": "keytrans",
        }
        return self.session.post(
            "%s/%s/elasticsearch_queries/" % (self.resource_url, self.tenantid),
            data=data,
        )

    def dataaccessed(self, dataaccessed_name, dataaccessed_value):
        data = {
            "query": {
                "query": {
                    "filtered": {
                        "filter": {
                            "bool": {
                                "must": [
                                    {
                                        "range": {
                                            "Timestamp": {
                                                "gte": "now-1M",
                                                "lte": "now"
                                            }
                                        }
                                    },
                                    {
                                        "term": {
                                            "data_markings.parent": dataaccessed_name
                                        }
                                    },
                                    {
                                        "term": {
                                            "data_markings.values": dataaccessed_value
                                        }
                                    },
                                    {
                                        "term": {
                                            "action": "get"
                                        }
                                    },
                                ]
                            }
                        }
                    }
                },
                "size": 0,
                "aggs": {
                    "timestamp": {
                        "date_histogram": {
                            "field": "Timestamp",
                            "interval": "day",
                            "pre_zone": "-04:00",
                        },
                        "aggs": {
                            "decision": {
                                "terms": {
                                    "field": "decision"
                                }
                            }
                        },
                    }
                },
            },
            "index": "keytrans",
        }
        return self.session.post(
            "%s/%s/elasticsearch_queries/" % (self.resource_url, self.tenantid),
            data=data,
        )
