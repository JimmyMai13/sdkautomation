from pydashboard.pydashboard.base import Base


class BrandingImages(Base):
    """
    Perform operations on Branding Images API
    """

    def __init__(self, apiuser, tenantid, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        :param refresh_on_init: <boolean> Whether to refresh data policies upon initialization
        :return:
        """
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url
        self.baseurl = "{url}/{tenantid}/branding/images".format(url=self.resource_url, tenantid=self.tenantid)

        self.DEFAULT_GET_PARAMS = "asc=true&limit=0&orderBy=name&skip=0&tenantId={}".format(self.tenantid)
        self.DEFAULT_POST_PARAMS = {
            "asc": True,
            "limit": 100,
            "orderBy": "last_name",
            "skip": 0
        }

        self.branding_images = []

        if refresh_on_init:
            self.refresh()

    #########################
    #
    #   HELPER
    #
    #########################

    def refresh(self):
        self.branding_images = self.get_all_branding_images().get("Resources")

    def set_tenantid(self, tenantid, method="POST"):
        self.tenantid = tenantid
        if method == "POST":
            self.DEFAULT_POST_PARAMS["tenantid"] = tenantid
        else:
            self.DEFAULT_GET_PARAMS = ("asc=true&limit=0&orderBy=name&skip=0&tenantId=%s" % tenantid)

    #########################
    #
    #   LIST
    #
    #########################

    def request_get_all_branding_images(self, tenantid=None, method="POST"):
        """
        Retrieve all branding images
        :param method: <string> request type
        :return: <requests> response from POST or GET
        """
        params = {"limit": 20, "skip": 0, "asc": True}
        if tenantid is not None:
            self.set_tenantid(tenantid=tenantid)
        if method == "POST":
            url = "{baseurl}/list".format(baseurl=self.baseurl)
            return self.session.post(url, data=params)
        else:
            url = self.baseurl
            return self.session.get(url)

    def get_all_branding_images(self, tenantid=None):
        """
        Retrieve branding images
        :param params optional params
        :param method <string> request type
        :return: <dict> branding images if successful otherwise empty
        """
        response = self.request_get_all_branding_images(tenantid=tenantid)
        return self.get_json_response(response=response)

    def request_get_branding_image_by_id(self, imgId):
        """
        Get branding image resource
        :param imgId: unique image ID branding image to get
        :return: <requests> response from GET
        """
        url = "{baseurl}/{imgId}".format(baseurl=self.baseurl, imgId=imgId)
        return self.session.get(url)

    def get_branding_image_by_id(self, imgId):
        """
        Get branding image resource
        :param imgId: unique image ID branding image to get
        :return: <dict> branding image if successful otherwise empty
        """
        response = self.request_get_branding_image_by_id(imgId=imgId)
        return self.get_json_response(response=response)

    #########################
    #
    #   UPLOAD
    #
    #########################

    def request_upload_branding_image(self, file_path, file_name):
        """
        Upload a branding image file
        :param file_name: file name to be uploaded
        :param file_path: path of file to be uploaded
        :return: <requests> response POST
        """
        url = "{baseurl}".format(baseurl=self.baseurl)
        return self.session.post_with_file(url=url, data={}, file_path=file_path, file_name=file_name)

    def upload_branding_image(self, file_path, file_name):
        """
        Upload a branding image file
        :param file_name: file name to be uploaded
        :param file_path: path of file to be uploaded
        :return: <dict> created branding image if successful otherwise empty
        """
        response = self.request_upload_branding_image(file_path=file_path, file_name=file_name)
        return self.get_json_response(response=response)

    #########################
    #
    #   UPDATE
    #
    #########################

    def request_update_branding_image(self, file_path, file_name, image):
        """
        Upload a branding image file
        :param file_name: file name to be uploaded
        :param file_path: path of file to be uploaded
        :param image: image object to be updated
        :return: <requests> response POST
        """
        url = "{baseurl}/{imageid}".format(baseurl=self.baseurl, imageid=image["id"])
        return self.session.put_with_file(url=url, data={}, file_path=file_path, file_name=file_name)

    def update_branding_image(self, file_path, file_name, image):
        """
        Upload a branding image file
        :param file_name: file name to be uploaded
        :param file_path: path of file to be uploaded
        :param image: image object to be updated
        :return: <dict> created branding image if successful otherwise empty
        """
        response = self.request_update_branding_image(file_path=file_path, file_name=file_name, image=image)
        return self.get_json_response(response=response)

    #########################
    #
    #   DOWNLOAD
    #
    #########################

    def request_download_branding_image(self, imgId, target_location):
        """
        Download branding image page
        :param imgId: <string> branding image file ID to download
        :param target_location: target location to download file
        :return: <requests> response from GET
        """
        url = "{baseurl}/{imgId}/file".format(baseurl=self.baseurl, imgId=imgId)
        return self.session.download_file(url, target_location=target_location)

    #########################
    #
    #   DELETE
    #
    #########################

    def request_delete_branding_image(self, imgId):
        """
        Delete branding image file
        :param imgId: <string> branding image id to delete
        :return: <requests> response from DELETE
        """
        url = "{baseurl}/{imgId}".format(baseurl=self.baseurl, imgId=imgId)
        return self.session.delete(url)

    def delete_branding_image(self, imgId):
        """
        Delete branding image file
        :param imgId: <string> branding image id to delete
        :return: <bool> True if successful, otherwise false
        """
        response = self.request_delete_branding_image(imgId=imgId)
        return self.get_bool_response(response=response)
