from pydashboard.pydashboard.base import Base


class Services(Base):
    def __init__(self, apiuser, tenantid):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        """

        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

    def get_baseurl(self):
        """Base url for request"""
        return "{}/services".format(self.resource_url)

    def request_get_services(self, params=None):
        """
        Get Dashboard services
        :param params: optional params
        :return: <requests> response from GET
        """
        url = self.get_baseurl()
        return self.session.get(url=url, params=params)

    def get_services(self, params=None):
        """
        :param params: optional params
        Get Dashboard services
        :return: <dict> dashboard services if successful, otherwise empty
        """
        response = self.request_get_services(params=params)
        return self.get_json_response(response=response)
