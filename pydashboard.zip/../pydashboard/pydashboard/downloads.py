from pydashboard.pydashboard.base import Base


class Downloads(Base):
    """
    Retrieve Product Downloads information
    """

    def __init__(self, apiuser, tenantid, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        :param refresh_on_init: <boolean> Whether to refresh data policies upon initialization
        :return:
        """
        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.downloads_full = {}
        self.downloads = {}

        if refresh_on_init:
            self.refresh()

    def get_baseurl(self):
        return "{}/{}/downloads".format(self.resource_url, self.tenantid)

    def refresh(self):
        self.downloads_full = self.get_downloads()
        self.downloads = self.downloads_full.get("Resources")

    def request_get_downloads(self, method="POST"):
        """
        Retrieve downloads information
        :return: <requests> response from request
        """
        url = "{}".format(self.get_baseurl())
        if method == "POST":
            url = "{}/list".format(url)
            return self.session.post(url, data={})
        else:
            return self.session.get(url)

    def get_downloads(self, method="POST"):
        """
        Retrieve Downloads
        :return: <dict> products or empty
        """
        response = self.request_get_downloads(method=method)
        return self.get_json_response(response=response)
