from pydashboard.pydashboard.base import Base


class BrandingTemplates(Base):
    """
    Perform operations on Branding templates API
    """

    DEFAULT_LIMIT = 20
    DEFAULT_SKIP = 0
    DEFAULT_ASC = True

    ACCEPTABLE_TEMPLATE_FIELD_TYPES = ["text", "image", "bool", "color"]

    DEFAULT_TEMPLATE_TYPES = ['side-nav', 'info', 'enablement',
                              'welcome-email', 'deployment-email',
                              'password-changed-email', 'welcome-back-email',
                              'reset-password-email', 'lockout-email',
                              'email-changed-email', 'verify-email-address-email',
                              'registration-verify-email-address-email',]

    EMAIL_TEMPLATES = list()

    for template in DEFAULT_TEMPLATE_TYPES:
        if 'email' in template:
            EMAIL_TEMPLATES.append(template)

    NUM_DEFAULT_TEMPLATES = len(DEFAULT_TEMPLATE_TYPES)

    EMAIL_PREVIEW_RESPONSE_KEYS = ["subject", "text", "html"]

    FIELDS_INCLUDED_IN_EMAIL_PREVIEW = ["greeting", "message", "closing", "signature"]  # instructions key prefixed

    FIELDS_EXCLUDED_IN_EMAIL_PREVIEW = ["sso-alternate-instructions", "sso-instructions"]

    DEEP_DIFF_EXCLUDE_PATHS = {"root['_createdTs']", "root['_createdBy']",
                               "root['_updatedTs']", "root['_updatedBy']",
                               "root['_version']", "root['changedBy']"}

    def __init__(self, apiuser, tenantid, refresh_on_init=True):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        :param refresh_on_init: <boolean> Whether to refresh data policies upon initialization
        :return:
        """
        self.apiuser = apiuser
        self.tenantid = tenantid
        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url
        self.baseurl = "{url}/{tenantid}/branding/templates".format(url=self.resource_url, tenantid=self.tenantid)
        self.default_payload = dict(limit=self.DEFAULT_LIMIT, skip=self.DEFAULT_SKIP, asc=self.DEFAULT_ASC)
        self.branding_templates = list()

        if refresh_on_init:
            self.refresh()

    #########################
    #
    #   HELPER
    #
    #########################

    def refresh(self):
        self.branding_templates = self.get_all_branding_templates().get("Resources")

    def verify_brand_template_is_valid(self, brand_field_type):
        if brand_field_type not in self.DEFAULT_TEMPLATE_TYPES:
            raise ValueError("INVALID_BRAND_FIELD_TYPE : The accepted brand template types are: ".join(
                self.DEFAULT_TEMPLATE_TYPES))

    def verify_field_type_is_valid(self, field_type):
        if not isinstance(field_type, str):
            raise TypeError("The 'field_type' parameter only accepts string data types")
        if field_type not in self.ACCEPTABLE_TEMPLATE_FIELD_TYPES:
            raise ValueError("INVALID_FIELD_TYPE_VALUE : The values accepted for field_type are ".join(
                self.ACCEPTABLE_TEMPLATE_FIELD_TYPES))

    def get_fields_in_payload_with_data_type(self, payload, field_type="text"):
        """
        Returns a list of fields in the payload with the specified data type
        :param payload: payload to parse
        :param field_type: acceptable fields are: "text", "image", "bool"
        :return: list of fields matching type
        """
        self.verify_field_type_is_valid(field_type=field_type)
        fields = list()
        for each in payload["fields"]:
            if payload["fields"][each]["type"] == field_type:
                fields.append(each)
        return fields

    #########################
    #
    #   LIST
    #
    #########################

    def request_get_all_branding_templates(self, payload=None):
        """
        Send POST request to get list of all branding templates
        :param payload: request payload
        :type: dict
        :return: response and status code from POST request
        :type: requests
        """
        if payload is None:
            payload = self.default_payload

        # TODO --> Verify payload

        url = self.baseurl+"/list"
        return self.session.post(url=url, data=payload)

    def get_all_branding_templates(self, payload=None):
        """
        Get all default branding templates
        :return: resource list of branding templates with metadata
        :type: json
        """
        response = self.request_get_all_branding_templates(payload=payload)
        return self.get_json_response(response=response)

    def request_get_branding_template(self, brand_template_type, params=None):
        """
        Send GET request to get specific branding template
        :param brand_template_type: type of branding template
        :type: str
        :param params: optional query params
        :type: str
        :return: response and status code from GET request
        :type: requests
        """

        # TODO --> Verify params

        url = self.baseurl+"/" + brand_template_type
        return self.session.get(url=url, params=params)

    def get_branding_template(self, brand_template_type, params=None):
        """
        Send GET request to get specific branding template
        :param brand_template_type: type of branding template
        :type: str
        :param params: optional query params
        :type: str
        :return: resource for specific branding tempalte
        :type: json
        """
        response = self.request_get_branding_template(brand_template_type=brand_template_type, params=params)
        return self.get_json_response(response=response)

    #########################
    #
    #   UPDATE
    #
    #########################

    def request_update_branding_templates(self, brand_template_type, payload):
        """
        Update branding templates
        :param brand_template_type: <string> type of branding image to get
        :param payload: <dict> data payload for request
        :return: <requests> response from PUT
        """
        url = self.baseurl+"/" + brand_template_type
        return self.session.put(url=url, data=payload)

    def update_branding_templates(self, brand_template_type, payload):
        """
        Update branding templates
        :param brand_template_type: <string> type of branding image to get
        :param payload: <dict> data payload for request
        :return: <dict> branding templates if successful otherwise empty
        """
        response = self.request_update_branding_templates(
            payload=payload, brand_template_type=brand_template_type)
        return self.get_json_response(response=response)

    #########################
    #
    #   DELETE
    #
    #########################

    def request_delete_branding_template(self, brand_template_type):
        """
        Reset branding template
        :param brand_template_type: <string> branding template id to delete
        :return: response from DELETE request
        :type: requests
        """

        url = self.baseurl+"/" + brand_template_type
        return self.session.delete(url)

    def delete_branding_template(self, brand_template_type):
        """
        Delete branding templates
        :param brand_template_type: <string> branding template type to delete
        :return: True if successful, otherwise False
        :type: bool
        """
        response = self.request_delete_branding_template(brand_template_type=brand_template_type)
        return self.get_bool_response(response=response)

    #########################
    #
    #   PREVIEW EMAIL
    #
    #########################

    def request_get_branding_email_preview(self, email_template):
        """
        Get branding template email preview
        :param email_template: type of branding email template
        :type: str
        :return: response from GET request
        :type: requests
        """

        # TODO --> Verify params

        url = self.baseurl + "/" + email_template + "/preview"
        return self.session.get(url=url)

    def get_branding_email_preview(self, email_template):
        """
        Get branding template email preview
        :param email_template: type of branding email template
        :type: str
        :return: email preview template if successful, otherwise empty
        :type: json
        """
        response = self.request_get_branding_email_preview(email_template=email_template)
        return self.get_json_response(response=response)
