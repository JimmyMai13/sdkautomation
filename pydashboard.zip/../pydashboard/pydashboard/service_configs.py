from pydashboard.pydashboard.base import Base


class ServiceConfigs(Base):
    def __init__(self, apiuser, tenantid):
        """
        :param apiuser: <AuthApiUser> authentication from authenticate_apiuser.py
        :param tenantid: <string> tenant id
        """

        self.apiuser = apiuser
        self.tenantid = tenantid

        self.session = self.apiuser.session
        self.resource_url = self.apiuser.resource_url

        self.scim_version = "1"

    def set_scim_version(self, version):
        if not isinstance(version, str):
            raise Exception("Version must be a string")
        else:
            self.scim_version = version

    def get_baseurl(self):
        return "%s/%s/scim/v%s" % (self.resource_url, self.tenantid, self.scim_version)

    def request_get_service_provider_configs(self, params=None):
        """
        Get Service Provider Configs
        :param params: <dict> optional params
        :return: <requests> response from GET
        """
        url = "%s/ServiceProviderConfigs" % self.get_baseurl()
        return self.session.get(url, params=params)

    def get_service_provider_configs(self, params=None):
        """
        Get Service Provider Configs
        :param params: <dict> optional params
        :return: <dict> service provider configs
        """
        response = self.request_get_service_provider_configs(params=params)
        return self.get_json_response(response=response)

    def request_get_all_schemas(self, params=None):
        """
        Get All Schemas
        :param params: <dict> optional params
        :return: <requests> response from GET
        """
        url = "%s/Schemas" % self.get_baseurl()
        return self.session.get(url, params=params)

    def get_all_schemas(self, params=None):
        """
        Get All Schemas
        :param params: <dict> optional params
        :return: <dict> schemas
        """
        response = self.request_get_all_schemas(params=params)
        return self.get_json_response(response=response)

    def request_get_schema(self, schema_id, params=None):
        """
        Get Schemas
        :param schema_id: <string> schema id
        :return: <request> response from GET
        """
        url = "{baseurl}/Schemas/{schema_id}".format(baseurl=self.get_baseurl(), schema_id=schema_id)
        return self.session.get(url, params=params)

    def get_schema(self, schema_id, params=None):
        """
        Get Schemas
        :param schema_id: <string> schema id
        :return: <dict> schema
        """
        response = self.request_get_schema(schema_id=schema_id, params=params)
        return self.get_json_response(response=response)
