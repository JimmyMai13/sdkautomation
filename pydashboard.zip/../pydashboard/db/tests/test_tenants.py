# import pytest
#
# from ..tenants import Tenants
#
#
# @pytest.mark.skip
# class TestTenants:
#
#     def __init__(self):
#         self.t = None
#
#     # noinspection PyUnusedLocal
#     @pytest.fixture(scope="class")
#     def setup_t(self, request):
#         self.t = Tenants()
#         return self
#
#     def test_tenant_details(self, setup_t):
#
#         my_tenant = setup_t.t.get_tenant(environment="QAW", tenant_name="Paz (D6Sn)")
#         assert my_tenant
#
#         expected_tenant = {
#             'tenantid': '55689790e25cfa5074551cf1',
#             'enrolltype': 'ionicidp',
#             'environment': 'QAW',
#             'tenant_name': 'Paz (D6Sn)',
#             'keyspace': 'D6Sn',
#             'lockabler': 'MANUAL'}
#         assert expected_tenant == my_tenant
#
#     def test_tenant_lockable_details(self, setup_t):
#
#         my_tenant = setup_t.t.get_tenant_from_lockable_resource(lockable_resource="QAW_Paz (D6Sn)")
#         assert my_tenant
#
#         assert {
#                    'tenantid': '55689790e25cfa5074551cf1',
#                    'enrolltype': 'ionicidp',
#                    'environment': 'QAW',
#                    'tenant_name': 'Paz (D6Sn)',
#                    'keyspace': 'D6Sn',
#                    'lockabler': 'MANUAL'
#         } == my_tenant
#
#     def test_lockable_split(self, setup_t):
#         my_split = setup_t.t.split_lockable_resource(lockable_resource="QAW_Paz (D6Sn)")
#         assert my_split
#         assert my_split[0] == "QAW"
#         assert my_split[1] == "Paz (D6Sn)"
