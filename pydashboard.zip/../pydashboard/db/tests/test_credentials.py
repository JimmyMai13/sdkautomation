# import pytest
#
# from ..credentials import Credentials
#
#
# @pytest.mark.skip
# class TestCredentials:
#
#     def __init__(self):
#         self.c = None
#
#     # noinspection PyUnusedLocal
#     @pytest.fixture(scope="class")
#     def setup_c(self, request):
#         self.c = Credentials()
#         return self
#
#     def test_default_ta(self, setup_c):
#         default_creds = setup_c.c.get_default_ta_credentials()
#         assert default_creds
#         expected_creds = {
#             'password': 'Ionic12345',
#             'type': 'default_ta',
#             'username': 'ionic_tester@ionic.com'}
#         assert expected_creds == default_creds
