# import pytest
#
# from ..environments import Environments
#
#
# @pytest.mark.skip
# class TestEnvironments:
#
#     def __init__(self):
#         self.t = None
#
#     # noinspection PyUnusedLocal
#     @pytest.fixture(scope="class")
#     def setup_t(self, request):
#         self.t = Environments()
#         return self
#
#     def test_tenant_details(self, setup_t):
#
#         my_tenant = setup_t.t.get_environment(environment="QAW")
#         assert my_tenant
#
#         expected_tenant = {
#             'csa_user': 'ionic_csa_tester@ionic.com',
#             'csa_tenantid': '576b1c8d81b3e3e25a189865',
#             'csa_pwd': 'Ionic12345',
#             'api_host': 'qa-west-api.in.ionicsecurity.com',
#             'ta_user': 'ionic_tester@ionic.com',
#             'ta_pwd': 'Ionic12345',
#             'dashboard_url': 'https://qa-west-dashboard.in.ionicsecurity.com',
#             'environment': 'QAW',
#             'enrollment_host': 'https://qa-west-enrollment.in.ionicsecurity.com',
#             'api_version': '/v2.2',
#             'redis_info': None}
#         assert expected_tenant == my_tenant
