from pydashboard.db.db_base import DBBase
import argparse
import os


class Tenants(DBBase, object):
    # subclass object for python2 support!
    table_name = "tenants"
    columns = ["environment", "tenant_name", "keyspace", "tenantid", "enrolltype", "lockabler"]

    def __init__(self):
        # super().__init__() # Only works for python3
        super(Tenants, self).__init__()  # python2 support

    def get_sql_columns(self):
        return ",".join(self.columns)

    def get_tenant_query(self, environment, tenant_name):

        query = ("SELECT {columns}"
                 " FROM {table}"
                 " WHERE environment = '{environment}'"
                 " AND tenant_name = '{tenant}'").format(
                     columns=self.get_sql_columns(), table=self.table_name, environment=environment, tenant=tenant_name)
        r = self.cur.execute(query)
        results = r.fetchall()
        return query, results

    def delete_tenant_query(self, environment, tenant_name):

        query = ("DELETE FROM {table}"
                 " WHERE environment = '{environment}'"
                 " AND tenant_name = '{tenant}'").format(
                     table=self.table_name, environment=environment, tenant=tenant_name)
        r = self.cur.execute(query)
        self.conn.commit()
        results = r.fetchall()
        return query, results

    def insert_tenant_query(self, environment, tenant_name, keyspace, tenantid, enrolltype, lockabler):

        query = ("INSERT INTO {table} VALUES ("
                 "'{environment}',"
                 " '{tenant}',"
                 " '{keyspace}',"
                 " '{tenant_id}',"
                 " '{enroll_type}',"
                 " '{lockable_resource}')").format(
                     table=self.table_name,
                     environment=environment,
                     tenant=tenant_name,
                     keyspace=keyspace,
                     tenant_id=tenantid,
                     enroll_type=enrolltype,
                     lockable_resource=lockabler)
        r = self.cur.execute(query)
        self.conn.commit()
        return query, r

    def get_tenant(self, environment, tenant_name, verify_single_row=True):
        """
        Return Tenant information for a single tenant
        :param environment: QAW
        :param tenant_name: Paz (D6Sn) or AU9Y
        :param verify_single_row: Fail if result count is not 1
        :return:
        """
        if "Auto" not in tenant_name:
            tenant_name = "Auto ({})".format(tenant_name)

        query, results = self.get_tenant_query(environment=environment, tenant_name=tenant_name)
        if verify_single_row and len(results) != 1:
            if len(results) == 0:
                msg_row_count = "Could not find tenant. Query: {query}"
            else:
                msg_row_count = "More than 1 tenant found for query. Query: {query}"
            msg_row_count.format(query=query)
            raise ValueError(msg_row_count)
        return self.make_dict(keys=self.columns, values=results[0])

    def get_tenant_from_lockable_resource(self, lockable_resource, verify_single_row=True):
        """
        Get Tenant resource from a lockable name such as:
        'QAW_Tenant1 (ABCD)'
        :param lockable_resource:
        :param verify_single_row:
        :return:
        """

        env, tenant_name = self.split_lockable_resource(lockable_resource=lockable_resource)
        return self.get_tenant(environment=env, tenant_name=tenant_name, verify_single_row=verify_single_row)

    @staticmethod
    def split_lockable_resource(lockable_resource):
        """
        Retrieve env and tenant name from a lockable resource
        :param lockable_resource:
        :return:
        """

        lock_r = lockable_resource.split('_', 1)
        assert len(lock_r) == 2, "Not enough '_' in the lockable resource name." " e.g 'QASE_Tenant1 (ABCD)'"
        env = lock_r[0]
        tenant_name = lock_r[1]
        return env, tenant_name

    def add_tenant(self, environment, tenant_name, keyspace, tenantid, enrolltype, lockabler=""):

        self.delete_tenant_query(environment=environment, tenant_name=tenant_name)
        query, result = self.insert_tenant_query(
            environment=environment,
            tenant_name=tenant_name,
            keyspace=keyspace,
            tenantid=tenantid,
            enrolltype=enrolltype,
            lockabler=lockabler)
        return query, result

    def write_to_txt(self, path, dict_to_write=None):
        file = open(path, "w")
        for each in dict_to_write:
            file.write(each + ":" + dict_to_write[each] + "\n")
        file.close()


def main():
    parser = argparse.ArgumentParser(
        description='Environments')
    parser.add_argument(
        '--env',
        default="QASE",
        required=False,
        help="e.g. QASE, DEVENG, ENG, QAP")
    parser.add_argument(
        '--keyspace',
        default="AU9Y",
        required=False,
        help="e.g. AU9Y")
    parser.add_argument(
        '--lockr',
        default="QASE_Auto (AU9Y)",
        required=False,
        help="e.g. QASE_Auto (AU9Y)")
    args = parser.parse_args()
    t = Tenants()
    lockable = "{}_Auto ({})".format(args.env, args.keyspace)
    t.write_to_txt(os.path.join(os.getcwd(), "TestInputs", "tenant_info.txt"), t.get_tenant_from_lockable_resource(lockable_resource=lockable))

    # query, result = t.add_tenant(
    #     environment="QAW",
    #     tenant_name="hello",
    #     tenantid="12345",
    #     keyspace="ABCD",
    #     enrolltype="ionicidp",
    #     lockabler="QAW_GENERAL1")
    # print(query)
    # print(result)
    # r = t.delete_tenant_query("QAW", "hello")
    # print(r)
    # print(t.get_tenant_query("QASE", "Auto (AU9Y)"))
    # print('\n')
    # print(t.get_tenant_from_lockable_resource(
    #   lockable_resource="QASE_Auto (AU9Y)"))
    # print(t.get_tenant(environment="QASE", tenant_name="Auto (AU9Y)", verify_single_row=False))

if __name__ == "__main__":
    main()
