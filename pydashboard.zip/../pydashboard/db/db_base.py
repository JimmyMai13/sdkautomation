import os
import sqlite3

from .. import db


class DBBase:

    db_name = "info.db"

    def __init__(self):
        self.db_path = db.__path__[0] + os.sep + self.db_name
        self.conn = sqlite3.connect(self.db_path)
        self.cur = self.conn.cursor()

    def close(self):
        self.cur.close()
        self.conn.close()

    @staticmethod
    def make_dict(keys, values):
        return dict(zip(keys, values))
