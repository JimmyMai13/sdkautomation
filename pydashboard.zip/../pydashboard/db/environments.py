from pydashboard.db.db_base import DBBase
import argparse
import os


class Environments(DBBase, object):

    table_name = "environments"
    columns = [
        "environment", "ta_user", "ta_pwd", "dashboard_url", "enrollment_host", "api_host", "api_version", "csa_user",
        "csa_pwd", "csa_tenantid", "redis_info"
    ]

    def __init__(self):
        # super().__init__() # Only works for python3
        super(Environments, self).__init__()  # python2 support

    def get_sql_columns(self):
        return ",".join(self.columns)

    def get_environment(self, environment, verify_single_row=True):
        """
        Return Environment information
        :param environment: QAW
        :param verify_single_row: Fail if result count is not 1
        :return:
        """
        query = "SELECT %s FROM %s WHERE environment = '%s'" % (self.get_sql_columns(), self.table_name, environment)
        r = self.cur.execute(query)
        results = r.fetchall()
        if verify_single_row:
            assert len(results) == 1
        return self.make_dict(keys=self.columns, values=results[0])

    def write_to_txt(self, path, dict_to_write=None):
        file = open(path, "w")
        for each in dict_to_write:
            file.write(each + ":" + dict_to_write[each] + "\n")
        file.close()

    def get_environment_from_lockable_resource(self, lockable_resource, verify_single_row=True):
        """
        Get Tenant resource from a lockable name such as:
        'QAW_Tenant1 (ABCD)'
        :param lockable_resource:
        :param verify_single_row:
        :return:
        """

        env, tenant_name = self.split_lockable_resource(lockable_resource=lockable_resource)
        return self.get_environment(environment=env, verify_single_row=verify_single_row)

    @staticmethod
    def split_lockable_resource(lockable_resource):
        """
        Retrieve env and tenant name from a lockable resource
        :param lockable_resource:
        :return:
        """

        lock_r = lockable_resource.split('_', 1)
        assert len(lock_r) == 2, "Not enough '_' in the lockable resource name." " e.g 'QASE_Tenant1 (ABCD)'"
        env = lock_r[0]
        tenant_name = lock_r[1]
        return env, tenant_name


def main():
    parser = argparse.ArgumentParser(
        description='Environments')
    parser.add_argument(
        '--env',
        default="QASE",
        required=False,
        help="e.g. QASE, DEVENG, ENG, QAP")
    parser.add_argument(
        '--keyspace',
        default="AU9Y",
        required=False,
        help="e.g. AU9Y")
    parser.add_argument(
        '--lockr',
        default="QASE_Auto (AU9Y)",
        required=False,
        help="e.g. QASE_Auto (AU9Y)")
    args = parser.parse_args()
    e = Environments()
    lockable = "{}_Auto ({})".format(args.env, args.keyspace)
    e.write_to_txt(os.path.join(os.getcwd(), "TestInputs", "environment_info.txt"), e.get_environment_from_lockable_resource(lockable))

if __name__ == "__main__":
    main()
