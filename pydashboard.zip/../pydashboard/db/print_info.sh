#!/usr/bin/env bash
sqlite3 info.db < print_info.script