from pydashboard.db.db_base import DBBase


class Credentials(DBBase):

    table_name = 'credentials'
    columns = [
        "type",
        "username",
        "password",
    ]

    def __init__(self):
        super().__init__()

    def get_sql_columns(self):
        return ",".join(self.columns)

    def get_credentials(self, cred_type, verify_single_row=True):
        """
        Return username, password for credential type
        :param cred_type: the type of credential requested. e.g. 'ad'
        :param verify_single_row: Fail if result count is not 1
        :return:
        """

        query = "SELECT {columns} FROM {table} WHERE type = '{type}'".format(
            columns=self.get_sql_columns(), table=self.table_name, type=cred_type)
        r = self.cur.execute(query)
        results = r.fetchall()
        if verify_single_row:
            assert len(results) == 1
        return self.make_dict(keys=self.columns, values=results[0])

    def get_default_ta_credentials(self):
        return self.get_credentials(cred_type='default_ta')


def main():
    c = Credentials()
    r = c.get_credentials(cred_type='artifactory')
    print(r)


if __name__ == '__main__':
    main()
