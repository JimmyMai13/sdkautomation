# pydashboard

Interface for Ionic Dashboard Commands

[Authenticate User Account](#authenticate-user-account) <br />
[Authenticate CSA Account](#authenticate-user-account) <br />
[No Authentication](#no-authentication) <br />
[Application Policy](#application-policy) <br />
[Data Markings](#data-markings) <br />
[Data Policies](#data-policies) <br />
[Users](#users) <br />
[Groups](#groups) <br />
[Keyspace Status](#keyspace-status) <br />
[Settings](#settings) <br />
[Products](#products) <br />
[Product Downloads](#product-downloads) <br />
[Key Transactions](#key-transactions) <br />
[CSA Product](#csa-products) <br />
[Download Product](#download-product) <br />
[Policy Simulator](#policy-simulator) <br />
[Build Package](#build-package) <br />

## Authenticate User Account

Import & Instance

```
my_tenant_id = "5539279be25cfa0876a1577d"

from authenticate_apiuser import AuthApiUser
my_user = AuthApiUser(resource_url='https://qa-west-dashboard.in.ionicsecurity.com',
                      usr='ionic_tester@ionic.com',
                      pwd='Ionic123',
                      tenantid=my_tenant_id)

```

## Authenticate CSA Account

Import & Instance

```
from authenticate_apiuser import AuthApiUser
my_csa = AuthApiUser(resource_url='https://qa-west-dashboard.in.ionicsecurity.com',
                      usr='csa_admin@ionic.com',
                      pwd='csa_admin_password',
                      tenantid="")

```

## No Authentication

Import & Instance

```
from authenticate_apiuser import AuthApiUser
no_auth = AuthApiUser(resource_url='https://qa-west-dashboard.in.ionicsecurity.com',
                      usr=None,
                      pwd=None,
                      tenantid=None,
                      login_on_init=False)

```

Close the session:

```
my_user.close_session()
```


## Application Policy

Import & Instance

```
from application_policy import ApplicationPolicies, AppPolicyKb
app_policy = ApplicationPolicies(apiuser=my_user, tenantid=my_tenant_id)
```

Get the applications:

```
app_policy.applications
```

To Obtain appkb information for the dashboard:

```
appkb = AppPolicyKb(apiuser=my_user, tenantid=my_tenant_id)
appkb.get_application_names()
```

To create an Application Policy:

```
youtube_id = appkb.get_application_id('youtube.com')
youtube = app_policy.create_application(appname="youtube", appuri="youtube.com", appkbid=youtube_id, description="my youtube app")
```

To enable an Application Policy

```
youtube = app_policy.applications_by_appuri["youtube.com"]
app_policy.enable_application(application=youtube)
```

To Set Features:

```
new_settings = [{'category': 'Access', 'feature': 'Site Access', 'newvalue': 'DENY'}, ]
group_to_update = "Default"
app_group = app_policy.get_application_groups_by_name(application=youtube)
updated_youtube = app_policy.update_application_for_group(application=youtube,
                                                              application_group=app_group["Default"],
                                                              new_settings=new_settings)
```

To Create a new application policy Group

```
# Note the caller is expected to provide the group ID which can be found from the 'UserGroup' calls

youtube = app_policy.applications_by_appuri["youtube.com"]
new_group = app_policy.create_application_group(application=youtube,
                                                name="paz group",
                                                user_group_ids="56779ffb81b3e3c2fddd4713",
                                                desc="This is the group for Paz",)
```

To Create a Feature

```
youtube = app_policy.applications_by_appuri["youtube.com"]
block_request = app_policy.get_application_templates_by_name(application=youtube)["Block Request"]
my_feature = app_policy.create_application_feature(application=youtube,
                                                   application_template=block_request,
                                                   name="Paz Block Request",
                                                   feature_value="youtube.com/block_paz",
                                                   message="You cannot access block_paz",)
```

## Data Markings

Import & Instance

```
from data_markings import DataMarkings
dm = DataMarkings(apiuser=my_user, tenantid=my_tenant_id)
```

Create a Data Marking

```
paz = dm.create_data_marking(name="paz", display="Paz Data Marking", desc="Data Marking for Paz")
```

Delete a Data Marking

```
paz = dm.get_data_markings_by_name()["paz"]
dm.delete_data_marking(marking=paz)
```

Create a Data Marking Value

```
paz = dm.get_data_markings_by_name()["paz"]
paz_detail = dm.get_data_marking_detail(marking=paz)
dm.create_data_marking_value(marking_detail=paz_detail, name="value one", desc="This is value one marking value")
```

Delete a Data Marking Value

```
paz = dm.get_data_markings_by_name()["paz"]
paz_detail = dm.get_data_marking_detail(marking=paz)
marking_value = dm.get_data_marking_values_by_name(marking_detail=paz_detail)["value one"]
dm.delete_data_marking_value(marking_detail=paz_detail, marking_value=marking_value)
```

## Data Policies

Import & Instance

```
from data_policies import DataPolicies
from data_policy_builder import *
dp = DataPolicies(apiuser=my_user, tenantid=my_tenant_id)
```

Create an 'All Data' Data Policy

```
paz_dp = dp.create_data_policy(name="paz dp")
```

Create a 'Marked' Data Policy for "Classification" = "blue"

```
dpt = DataPolicyTarget()
paz_m = MarkedDataCondition(marking_name="classification", marking_values=["blue"])
paz_m.build_condition()
dpt.target_conditions.append(paz_m.target_condition)
dpt.build_target()
marked = dp.create_data_policy(name="marked", desc="This should be marked", target=dpt.target)
```

Create an 'Unmarked' Data Policy which applies to markings "classification" and "paz"

```
dpt = DataPolicyTarget()
unmarked_1 = UnMarkedDataCondition(marking_name="classification")
unmarked_1.build_condition()
unmarked_2 = UnMarkedDataCondition(marking_name="paz")
unmarked_2.build_condition()
dpt.target_conditions.append(unmarked_1.target_condition)
dpt.target_conditions.append(unmarked_2.target_condition)
dpt.build_target()
unmarked = dp.create_data_policy(name="unmarked", desc="This should be unmarked", target=dpt.target)
```

Rules

1) Formulate 1 or more Conditions <br />
2) Append the Rule to the policy <br />

```
my_condition = SOME_CONDITION (see below for different condition types)
my_condition.build_condition()
paz_dp = dp.get_data_policies_by_name()["paz dp"]
new_rule = DataPolicyRule(effect="Permit", desc="My New Rule")
new_rule.condition.append(my_condition.rule_condition)
new_rule.build_rule()
rules_to_add = [new_rule.rule, ]
paz_dp_updated = dp.append_data_policy_rule(policy=paz_dp, rules=rules_to_add)
```

Create a Device Rule Condition

```
my_condition = DeviceCondition(device_ids=["OaqE.F.e4d3acdd-cc5e-4cd8-ab78-a7320534b975"], isnot=False)
```

Create a Group Rule

```
my_condition = UserGroupCondition("match", groupids=["5678f17481b3e3c40cf3c619", "5678f17481b3e3c30362e236"], isnot=True)
```

Create a IP Address Rule

```
my_condition = IPAddressCondition(ips=["38.140.48.58"], isnot=True)
```

Create a Location Rule

```
my_condition = LocationCondition(["USA", "GBR", ], isnot=False)
```

Create a Specific Data Rule

```
from datetime import datetime
my_condition = SpecificDateCondition(datetime.now(), before_or_after="after")
```

Create a Time Elaspsed Rule

```
my_condition = RelativeDateCondition("days", 123)
```

Create a User Rule

```
my_condition = UserCondition("match", userids=["5678e7ba81b3e3c3064304cd", "5678e7b038a709ce27df920a"], isnot=False)
```

Create a Advanced Rule


```
my_condition = AdvancedRuleCondition(attribute1="classification", attribute2=["hello", "world"], attribute1_category="resource", attribute2_category="custom values", does_not_equal=True, any_or_all="all")
```

```
my_condition = AdvancedRuleCondition(attribute1="Ionic", attribute2="Security", attribute1_category="subject", attribute2_category="environment", does_not_equal=True, any_or_all="all")
```

```
my_condition = AdvancedRuleCondition(attribute1="Ionic", attribute2=["Security"], attribute1_category="action", attribute2_category="custom values", does_not_equal=True, any_or_all="all")
```

## Users

```
from users import Users
my_users = Users(apiuser=my_user, tenantid=my_tenant_id)
```

Create a User

```
my_user = my_users.create_user(firstname="Paz", lastname="Patel", emails:[{"primary":true,"value":"paz@ionic.com"},{"value":"paz2@ionic.com"}], domainUpn="paz@ionicsecurity.com")
```

Enable a user

```
paz = my_users.users_by_username["paz@ionic.com"]
my_users.enable_user(user=paz)
```

Disable a user

```
paz = my_users.users_by_username["paz@ionic.com"]
my_users.disable_user(user=paz)
```

Delete a user

```
paz = my_users.users_by_username["paz@ionic.com"]
my_users.delete_user(user=paz)
```

## Groups

Import & Instance

```
from groups import Groups
my_groups = Groups(apiuser=my_user, tenantid=my_tenant_id)
```

Create a Group

```
my_groups.create_group(name="paz group")
```

Delete a Group

```
paz_grp = my_groups.groups_by_name["paz group"]
my_groups.delete_group(group=paz_grp)
```

Assign a User to a Group

```
paz_user = my_users.users_by_username["paz@ionic.com"]
paz_grp = my_groups.groups_by_name["paz group"]
my_users.add_groups_to_user(user=paz_user, groups=[paz_grp, ])
```

## Keyspace Status

Import & Instance

```
from keyspace_status import KeyspaceStatus
ks = KeyspaceStatus(apiuser=my_user, tenantid=my_tenant_id)
```

Retrieve Keyspace Status Information

```
my_keyspace = "OaqE"
ks.keyspaces_by_keyspace[my_keyspace]
```

## Settings

Import & Instance

```
from settings import Settings
my_settings = Settings(apiuser=my_user, tenantid=my_tenant_id)
```

Retrieve Settings

```
my_settings.settings
```

Enable or Disable Cloud Discovery

```
my_settings.enable_cloud_discovery(settings=my_settings.settings)
my_settings.disable_cloud_discovery(settings=my_settings.settings)
```

Enable or Disable Policy Cache

```
my_settings.enable_policy_cache(settings=my_settings.settings)
my_settings.disable_policy_cache(settings=my_settings.settings)
```

Update the Enrollment URL

```
my_settings.update_enrollmenturl(settings=my_settings.settings, enrollmenturl="https://qa-west-enrollment.in.ionicsecurity.com/keyspace/OaqE/register")
```

## Products

Import & Instance

```
from products import Products
my_products = Products(apiuser=my_user, tenantid=my_tenant_id)
```

Retrieve Product Information

```
my_products.products
```

## Product Downloads

Import & Instance

```
from product_downloads import ProductDownloads
my_product_downloads = ProductDownloads(apiuser=my_user, tenantid=my_tenant_id)
```

Retrieve Product Download information

```
my_product_downloads.product_downloads
```

## Key Transactions

Import & Instance

```
from key_transactions import KeyTransactions
kt = KeyTransactions(apiuser=my_user, tenantid=my_tenant_id)
```

Get Key Transactions

```
kt.keytransactions_by_cid["CID|OaqE.F.043a3f05-c89e-4f87-b4c7-e4862edac7e7|1450853448|vOLx"]
```

## CSA Products

Import & Instance

```
from csa_products import CSAProducts
csa_prod = CSAProducts(apiuser=my_csa)
```

Create a Product

```
prod = csa_prod.create_product(name="paz prod")
```

Create a Ionic Hosted Version

```
version_ionic = csa_prod.create_ionic_version(product=prod, name="paz version", file_name="file_name.txt", file_path="/file_path/file_path/file_name.txt")
```

Create a Externally Hosted Version

```
version_external = csa_prod.create_external_version(product=prod, name="paz version", external_url="https://www.ionicsecurity.com")
```

Set Stable Product Version
```
stable = csa_prod.set_product_stable_version(product=prod, version=version_external)
```

Unset Stable Product Version
```
stable = csa_prod.set_product_stable_version(product=prod)
```

Delete a Product
```
csa_prod.delete_product(product=prod)
```

Enable/Disable a Product
```
csa_prod.enable_product(product=prod)
csa_prod.disable_product(product=prod)
```

Enable/Disable a Version
```
csa_prod.enable_version(version=version_external, product=prod)
csa_prod.enable_version(version=version_ionic, product=prod)
```

Delete a Version
```
csa_prod.delete_version(product=prod, version=version_ionic)
```

## Download Product

Import & Instance

```
from public_downloads import PublicDownloads
pd = PublicDownloads(apiuser=no_auth, tenantid=my_tenant_id)
```

Retrieve a Product
```
my_product = pd.downloads_by_name.get("Product Name")
```

Request a Screen
```
screen = pd.create_screen(firstname="papa", lastname="john", country="US", company="Ionic", street="123 Main Street", email="papa@ionic.com", sourceip=None)
```

Download Product Using a Screen
```
resp = pd.download_product(product=my_product, screen=screen, target_location="/tmp/paz/")
```

## Policy Simulator

The Policy Simulator requests are sent via the DataPolicies class. However to construct the simulator payload use the policy_simulator module

Import & Instance

```
from policy_simulator import PolicySimulator, SimulatorResults
from data_policies import DataPolicies
from datetime import datetime, timedelta
from pytz import timezone
dp = DataPolicies(apiuser=my_user, tenantid=my_tenant_id)
psim = PolicySimulator(name="My Sim")
```

Retrieve List of Simulations

```
# NOTE: 'name' is not a unique field. Therefore simulations with the same name will only appear once in the dict
my_simulation = dp.get_simulations_by_name().get("SIMULATION NAME")
```

Delete a Simulation

```
delete_success = dp.delete_simulation(simulation=my_simulation)
```

Create a Simulation

Add Policy to Simulation

```
my_policy_1 = dp.policies_by_name.get("Policy 1")
my_policy_2 = dp.policies_by_name.get("Policy 2")
psim.add_policies(policies=[my_policy_1, my_policy_2])
```

Set Policy Version

```
psim.set_policy_version(version=1000)
```

Add Requester User to Simulation

```
paz = users.get_users_by_email().get("paz_user_d6sn@ionic.com")
psim.add_requester_user(users=[paz])
```

Add Requester Groups to Simulation

```
g1 = grps.groups_by_name.get("g1")
g2 = grps.groups_by_name.get("g2")
psim.add_requester_groups(groups=[g1, g2])
```

Add Requester Device to Simulation

```
my_device = devices.devices_by_deviceid.get("D6Sn._.78977717-75bc-4cb7-965b-0fd0c608852e")
psim.add_requester_device(devices=[my_device, ])
```

Add Requester Time to Simulation

```
past_time = datetime.now(timezone("Etc/GMT")) - timedelta(days=5)
psim.add_requester_time(specific_time=past_time)
```

Add Resource User to Simulation

```
eric = users.get_users_by_email().get("eric_ta_d6sn@ionic.com")
psim.add_resource_user(users=[eric])
```

Add Resource Groups to Simulation

```
g3 = grps.groups_by_name.get("g3")
g4 = grps.groups_by_name.get("g4")
psim.add_resource_groups(groups=[g3, g4])
```

Add Resource Device to Simulation

```
my_device = devices.devices_by_deviceid.get("D6Sn.8.e7c0445d-cde5-44de-9bc4-2de162f074c8")
psim.add_resource_device(devices=[my_device, ])
```

Add Data Marking with Value to Simulation

```
psim.add_marking(marking_name="classification", marking_values=["blue", "red"])
psim.add_marking(marking_name="ionic-info-type", marking_values=["filename", ])
```

Add Action Type to Simulation

```
psim.add_request(type="get")
```

After the desired properties have been added to the simulation, the payload must be built

```
psim.build_payload()
```

Create the simulation request

```
my_result = dp.create_simulation(simulation_payload=psim.simulation_payload)
```

Simulation Results

```
sim_results = SimulatorResults(result=my_result)
sim_results.refresh() # This must be called if the 'sim_results.result' property is updated
print(sim_results.decision)
```

Build Package

```
python3 setup.py sdist --format=zip
pip3 install ./dist/pydashboard-1.0.zip
```
