import argparse
import json
import pickle

from pydashboard.pydashboard.authenticate_apiuser import AuthApiUser
from pydashboard.pydashboard.data_policies import DataPolicies
from pydashboard.pydashboard.data_policy_builder import (DataPolicyTarget, MarkedDataCondition, UnMarkedDataCondition)

# import sys
# import os

# current_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
# p = os.path.abspath(os.path.join(current_dir, os.pardir, "pydashboard"))
# sys.path.append(p)
#
# sys.path.append("../pydashboard/")
# sys.path.append("../pydashboard/pydashboard/")  # add path for Brians automation


def print_pretty_json(content):
    print(json.dumps(content, sort_keys=True, separators=(',', ': '), indent=2))


parser = argparse.ArgumentParser(description='Data Policy Information from the dashboard')
parser.add_argument(
    '--authfile',
    '-a',
    required=True,
    help="File which contains information about dashboard" + "session. See authenticate_apiuser.py to create" +
    "authfileout")

parser.add_argument('--create_alldata', help="Create 'All Data' Policy <name> <effect>", nargs=2)
parser.add_argument('--create_marked', help="Create 'Unmarked' Policy <name> <effect> <list of json>", nargs=3)
parser.add_argument('--create_unmarked', help="Create 'Marked' Policy <name> <effect> <list of data markings>", nargs=3)
parser.add_argument('--delete', help="Delete Data Policy with the provided <name>", nargs=1)
parser.add_argument('--get', help="Get all Data Policies <appuri>", nargs=1)

args = parser.parse_args()

auth_args = pickle.load(open(args.authfile, "rb"))

api_user = AuthApiUser(
    resource_url=auth_args['resource_url'],
    usr=auth_args['username'],
    pwd=auth_args['password'],
    tenantid=auth_args['tenantid'],
    login_on_init=False,
    load_tenant_info=False)

api_user.session = auth_args['session']

data_policy = DataPolicies(apiuser=api_user, tenantid=auth_args['tenantid'])

if args.get:
    if args.get[0] == 'refresh':
        data_policy.refresh()
        print_pretty_json(data_policy.policies)

if args.delete:
    # Delete the Data Policy with the provided policy name
    data_policy.refresh()
    policy_name = args.delete[0]
    if policy_name in data_policy.policies_by_name:
        policy_to_delete = data_policy.policies_by_name[policy_name]
        print(data_policy.delete_data_policy(policy=policy_to_delete))
    else:
        print("could not find data policy to delete")

if args.create_alldata:
    # Create a Data Policy
    p_name = args.create_alldata[0]
    p_effect = args.create_alldata[1]
    new_policy = data_policy.create_data_policy(name=p_name)
    new_policy_with_rule = ""
    if p_effect == "permit":
        new_policy_with_rule = data_policy.create_data_policy_always_allow_rule(policy=new_policy)
    elif p_effect == "deny":
        new_policy_with_rule = data_policy.create_data_policy_always_deny_rule(policy=new_policy)
    enabled_policy = data_policy.enable_data_policy(policy=new_policy_with_rule)
    print_pretty_json(content=enabled_policy)

if args.create_marked:
    p_name = args.create_marked[0]
    p_effect = args.create_marked[1]
    p_markings = json.loads(args.create_marked[2])
    print(p_effect)
    dpt = DataPolicyTarget()
    for each_marking_values in p_markings:
        data_marking = list(each_marking_values.keys())[0]
        data_marking_values = each_marking_values[data_marking]
        marked_data_cond = MarkedDataCondition(
            marking_names=data_marking, marking_values=data_marking_values, rule_type=data_marking_values)
        marked_data_cond.build_condition()
        dpt.target_conditions.append(marked_data_cond.target_condition)
    dpt.build_target()
    new_policy = data_policy.create_data_policy(name=p_name, desc=p_name, target=dpt.target)
    new_policy_with_rule = ""
    if p_effect == "permit":
        new_policy_with_rule = data_policy.create_data_policy_always_allow_rule(policy=new_policy)
    elif p_effect == "deny":
        new_policy_with_rule = data_policy.create_data_policy_always_deny_rule(policy=new_policy)
    enabled_policy = data_policy.enable_data_policy(policy=new_policy_with_rule)
    print_pretty_json(content=enabled_policy)

if args.create_unmarked:
    p_name = args.create_unmarked[0]
    p_effect = args.create_unmarked[1]
    p_markings = json.loads(args.create_unmarked[2])

    dpt = DataPolicyTarget()
    if len(p_markings) > 0:
        for each_marking_name in p_markings:
            unmarked_data_cond = UnMarkedDataCondition(marking_name=each_marking_name)
            unmarked_data_cond.build_condition()
            dpt.target_conditions.append(unmarked_data_cond.target_condition)
    else:
        unmarked_data_cond = UnMarkedDataCondition(marking_name="")
        unmarked_data_cond.build_condition()
        dpt.target_conditions.append(unmarked_data_cond.target_condition)

    dpt.build_target()
    new_policy = data_policy.create_marked_data_policy(name=p_name, desc=p_name, target=dpt.target)
    if p_effect == "permit":
        new_policy_with_rule = data_policy.create_data_policy_always_allow_rule(policy=new_policy)
    elif p_effect == "deny":
        new_policy_with_rule = data_policy.create_data_policy_always_deny_rule(policy=new_policy)
    enabled_policy = data_policy.enable_data_policy(policy=new_policy_with_rule)
    print_pretty_json(content=enabled_policy)
