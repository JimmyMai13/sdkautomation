import argparse
import json
import pickle

from pydashboard.pydashboard.authenticate_apiuser import AuthApiUser
from pydashboard.pydashboard.mission_control import MissionControl
"""
Command line interface for mission control
"""

parser = argparse.ArgumentParser(
    description='retrive mission control data policy, application policy, and cloud discovery logs')

parser.add_argument(
    '--authfile',
    '-a',
    required=True,
    help="File which contains information about dashboard session. See authentication_apiuser.py to create authfileout")
parser.add_argument('--sizeValue', '-sv', default="10", help='')
parser.add_argument('--fromValue', '-fv', default="0", help='')
parser.add_argument('--gte', '-g', required=True, help='')
parser.add_argument('--lte', '-l', required=True, help='')
parser.add_argument('--data_policy', '-dp', help='', action="store_true")
parser.add_argument('--app_policy', '-ap', help='', action="store_true")
parser.add_argument('--cloud_discovery', '-cd', help='', action="store_true")
args = parser.parse_args()

auth_args = pickle.load(open(args.authfile, "rb"))

api_user = AuthApiUser(
    resource_url=auth_args['resource_url'],
    usr=auth_args['username'],
    pwd=auth_args['password'],
    tenantid=auth_args['tenantid'],
    login_on_init=False,
    load_tenant_info=False)
api_user.session = auth_args['session']

logs = MissionControl(apiuser=api_user, tenantid=auth_args['tenantid'])
# size_value= 10, from_value=0, gte="now-15m", lte="now"
output = {}
if args.cloud_discovery:
    output = logs.get_cloud_discovery(args.sizeValue, args.fromValue, args.gte, args.lte)
if args.app_policy:
    output = logs.get_app_policy(args.sizeValue, args.fromValue, args.gte, args.lte)
if args.data_policy:
    output = logs.get_data_policy(args.sizeValue, args.fromValue, args.gte, args.lte)
print(json.dumps(output))
