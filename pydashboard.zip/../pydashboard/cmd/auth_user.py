import argparse
import pickle

from pydashboard.pydashboard.authenticate_apiuser import AuthApiUser

# import os
# import sys

# current_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
# p = os.path.abspath(os.path.join(current_dir, os.pardir, "pydashboard"))
# sys.path.append(p)

parser = argparse.ArgumentParser(description='Authentication with Ionic Dashboard')
parser.add_argument('--resource_url', '-d', required=True, help="URL of the Dashboard (without Tenant ID)")
parser.add_argument('--tenantid', '-t', required=True, help="Tenant ID")
parser.add_argument('--username', '-u', required=True, help="Tenant Admin Username")
parser.add_argument('--password', '-p', required=True, help="Tenant Admin Password")
parser.add_argument(
    '--authfileout', '-f', required=True, help="Filename to save the credentials and session information")
args = parser.parse_args()

save_to_file = vars(args)  # Add the input arguments to the file

api_user = AuthApiUser(
    resource_url=args.resource_url,
    usr=args.username,
    pwd=args.password,
    tenantid=args.tenantid,
    login_on_init=False,
    load_tenant_info=False)
r = api_user.request_login()
print(r)
save_to_file['session'] = api_user.session
pickle.dump(save_to_file, open(args.authfileout, "wb"))
