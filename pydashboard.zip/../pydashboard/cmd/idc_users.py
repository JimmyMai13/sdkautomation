import argparse
import json
import pickle

from pydashboard.pydashboard.authenticate_apiuser import AuthApiUser
from pydashboard.pydashboard.users import Users

# import sys
# import os

# current_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
# p = os.path.abspath(os.path.join(current_dir, os.pardir, "pydashboard"))
# sys.path.append(p)


def print_pretty_json(content):
    print(json.dumps(content, sort_keys=True, separators=(',', ': '), indent=2))


parser = argparse.ArgumentParser(description='Obtain Users Information from the dashboard')
parser.add_argument(
    '--authfile',
    '-a',
    required=True,
    help="File which contains information about dashboard" + "session. See authenticate_apiuser.py to create" +
    "authfileout")

parser.add_argument(
    '--create',
    '-c',
    help="Create a User <firstname> <lastname> <email> <domainupn> <acct_type> <password> <externalid>",
    nargs=7)
parser.add_argument('--get', '-g', help="Get JSON of Users")
parser.add_argument('--delete', '-d', help="Delete User with the provided username", nargs=1)

args = parser.parse_args()

auth_args = pickle.load(open(args.authfile, "rb"))

api_user = AuthApiUser(
    resource_url=auth_args['resource_url'],
    usr=auth_args['username'],
    pwd=auth_args['password'],
    tenantid=auth_args['tenantid'],
    login_on_init=False,
    load_tenant_info=False)

api_user.session = auth_args['session']

idc_users = Users(apiuser=api_user, tenantid=auth_args['tenantid'])

if args.get:
    if args.get[0] == 'refresh':
        idc_users.refresh()
    print_pretty_json(idc_users.users)

if args.delete:
    # Delete the user with the provided username
    username_to_delete = args.delete[0]
    idc_users.refresh()
    user_to_delete = idc_users.users_by_username.get(username_to_delete)
    if user_to_delete:
        user_deleted = idc_users.delete_user(user=user_to_delete)
        print(user_deleted)
    else:
        print("Could not find %s" % username_to_delete)

if args.create:
    # Create a User
    firstname = args.create[0]
    lastname = args.create[1]
    email = args.create[2]
    domainUpn = args.create[3]
    acct_type = args.create[4]  # e.g. "user" / "ta" / "scim_access"
    externalid = args.create[5]
    password = args.create[6]

    set_password = None
    if acct_type == "scim_access":
        set_password = password

    new_user = idc_users.create_user(
        firstname=firstname,
        lastname=lastname,
        emails=[{
            "value": email
        }],
        domainUpn=domainUpn,
        acct_type=acct_type,
        externalid=externalid)
    print_pretty_json(new_user)
