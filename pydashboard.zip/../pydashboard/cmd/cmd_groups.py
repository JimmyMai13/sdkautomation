import argparse
import json
import logging
import pickle

from pydashboard.pydashboard.authenticate_apiuser import AuthApiUser, MySession
from pydashboard.pydashboard.groups import Groups
from pydashboard.pydashboard.users import Users

# import os
# import sys

# current_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
# p = os.path.abspath(os.path.join(current_dir, os.pardir, "pydashboard"))
# sys.path.append(p)

logging.basicConfig(filename='group_policy.log', level=logging.DEBUG)


def print_pretty_json(content):
    print(json.dumps(content, sort_keys=True, separators=(',', ': '), indent=2))


parser = argparse.ArgumentParser(description='Obtain group policy information')

parser.add_argument(
    '--authfile',
    '-a',
    required=True,
    help="File which contains information about dashboard session. See authenticate_apiuser.py to create authfileout")

parser.add_argument('--assign', help='', nargs='+')

parser.add_argument('--remove', help='', nargs='+')

parser.add_argument(
    '--strict',
    dest='strict',
    action='store_true',
    help="Will throw an exception if 1) A user is added to a group to which they already belong. "
    "2) An attempt is made to remove a user from a group which they do not belong")

parser.set_defaults(strict=False)

args = parser.parse_args()

auth_args = pickle.load(open(args.authfile, "rb"))

api_user = AuthApiUser(
    resource_url=auth_args['resource_url'],
    usr=auth_args['username'],
    pwd=auth_args['password'],
    tenantid=auth_args['tenantid'],
    login_on_init=False,
    load_tenant_info=False)

api_user.session = auth_args['session']

users = Users(apiuser=api_user, tenantid=auth_args['tenantid'])
groups = Groups(apiuser=api_user, tenantid=auth_args['tenantid'])

if args.assign:

    user_data = users.users_by_username[args.assign.pop(0)]
    groups_to_add = []
    groups_to_add_by_id = {}  # used if 'strict' is set
    for group_name in args.assign:
        new_group = groups.groups_by_name[group_name]
        groups_to_add.append(new_group)
        groups_to_add_by_id[new_group["id"]] = new_group["displayName"]

    if args.strict:
        new_group_ids = []
        current_user_groups = users.get_group_ids_from_user(user=user_data)
        for new_grp in groups_to_add:
            new_group_ids.append(new_grp["id"])
        matches = set(new_group_ids).intersection(set(current_user_groups))
        if matches:
            grp_names = []
            for each_match in matches:
                grp_names.append(groups_to_add_by_id[each_match])
            raise Exception("User is already in %s" % grp_names)
    print(users.add_groups_to_user(user=user_data, groups=groups_to_add))

if args.remove:

    user_data = users.users_by_username[args.remove.pop(0)]
    groups_to_remove = []
    groups_to_remove_by_id = {}  # used if 'strict' is set
    for group_name in args.remove:
        new_group = groups.groups_by_name[group_name]
        groups_to_remove.append(new_group)
        groups_to_remove_by_id[new_group["id"]] = new_group["displayName"]

    if args.strict:
        new_group_ids = []
        current_user_groups = users.get_group_ids_from_user(user=user_data)
        for new_grp in groups_to_remove:
            new_group_ids.append(new_grp["id"])
        extra_grps = set(new_group_ids) - (set(current_user_groups))
        if extra_grps:
            grp_names = []
            for each_match in extra_grps:
                grp_names.append(groups_to_remove_by_id[each_match])
            raise Exception("User is not in %s" % grp_names)

    print(users.remove_groups_from_user(user=user_data, groups=groups_to_remove))
