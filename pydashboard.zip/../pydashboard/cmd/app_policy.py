import argparse
import json
import logging
import pickle

from pydashboard.pydashboard.application_policy import (ApplicationPolicies, AppPolicyKb)
from pydashboard.pydashboard.authenticate_apiuser import AuthApiUser

# import os
# import sys

# current_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
# p = os.path.abspath(os.path.join(current_dir, os.pardir, "pydashboard"))
# sys.path.append(p)

logging.basicConfig(filename="app_policy.log", level=logging.DEBUG)


def print_pretty_json(content):
    print(json.dumps(content, sort_keys=True, separators=(",", ": "), indent=2))


parser = argparse.ArgumentParser(description="Obtain Application Policy Information from the dashboard")

parser.add_argument(
    "--authfile",
    "-a",
    required=True,
    help="File which contains information about dashboard session. See authenticate_apiuser.py to create authfileout",
)

parser.add_argument("--create", "-c", help="Create an Application <appuri> <appname>", nargs=2)

parser.add_argument("--create_application_by_name", help="", nargs="+")

parser.add_argument("--get", "-g", help="Get JSON of Applications")

parser.add_argument(
    "--update_features",
    "-uf",
    help="Update Application <appuri> <group> <settings>",
    nargs=3,
)

parser.add_argument("--delete", "-d", help="Delete Application with the provided appuri", nargs=1)

parser.add_argument("--features", "-f", help="Get features for the application <appuri>", nargs=1)

parser.add_argument(
    "--set_all_features",
    "-sa",
    help="Set all features for the application <appuri> <state>",
    nargs=2,
)

parser.add_argument("--set_feature_by_name", "-sf", help="", nargs=3)

parser.add_argument("--set_feature_message", "-sm", help="", nargs=4)

args = parser.parse_args()

auth_args = pickle.load(open(args.authfile, "rb"))

api_user = AuthApiUser(
    resource_url=auth_args["resource_url"],
    usr=auth_args["username"],
    pwd=auth_args["password"],
    tenantid=auth_args["tenantid"],
    login_on_init=False,
    load_tenant_info=False,
)

api_user.session = auth_args["session"]

app_policy = ApplicationPolicies(apiuser=api_user, tenantid=auth_args["tenantid"])

if args.get:
    if args.get[0] == "refresh":
        app_policy.refresh()
    print_pretty_json(app_policy.applications)

if args.delete:
    # Delete the application with the provided URI
    app_policy.refresh()
    app_to_delete = app_policy.applications_by_appuri[args.delete[0]]
    print(app_policy.delete_application(application=app_to_delete))

if args.create:
    # Create an Application
    appkb = AppPolicyKb(apiuser=api_user, tenantid=auth_args["tenantid"])
    # print(appkb.appkb_payload)
    appuri = args.create[0]
    appname = args.create[1]
    desired_uri = appuri
    if len(args.create) > 2:
        desired_uri = args.create[2]
    appkb_app = appkb.get_specific_application(uri=appuri, application_name=appname)
    new_app = app_policy.create_application(appname=appname, appuri=desired_uri, appkbid=appkb_app["id"])
    new_app = app_policy.enable_application(application=new_app)
    print(new_app)

if args.create_application_by_name:
    application_name = args.create_application_by_name[0]
    app_uri = args.create_application_by_name[1]
    enabled = args.create_application_by_name[2]
    appkb = AppPolicyKb(apiuser=api_user, tenantid=auth_args["tenantid"])
    appkb_applications = appkb.get_appkb_applications()["Resources"]

    data = next((x for x in appkb_applications if x["name"] == application_name), None)
    if not data:
        raise ValueError("[Error] Application not found: " + application_name)

    if data["appUri"] != app_uri:
        data["appUri"] = app_uri
    response = app_policy.request_create_application(
        appname=data["name"],
        appuri=data["appUri"],
        appkbid=data["id"],
        altappuri=data["altAppUri"],
        description=data["description"],
    )
    new_app = response.json()
    if response.status_code == 409:
        raise ValueError("[Error] Application already exists: " + data["name"])
    if enabled.lower() == "true":
        new_app = app_policy.enable_application(new_app)
    print_pretty_json(new_app)

if args.set_all_features:
    app_policy.refresh()
    features = args.set_all_features[0]
    states = args.set_all_features[1]
    app_features = app_policy.applications_by_appuri[features]
    response = app_policy.set_all_features(app_features, states)
    print(json.dumps(response))

if args.features:
    # Get the Features of an application
    app_policy.refresh()
    app = app_policy.applications_by_appuri[args.features[0]]
    print_pretty_json(app_policy.get_application_features(application=app))

if args.set_feature_by_name:
    app_policy.refresh()
    app_uri = args.set_feature_by_name[0]
    feature_name = args.set_feature_by_name[1]
    state = args.set_feature_by_name[2]

    try:
        app = app_policy.applications_by_appuri[app_uri]
        features = app_policy.get_application_features(app)
        groups = app_policy.get_application_groups_by_name(app)
        group = groups["Policy for All Users"]
        feature_list = []
        for index in features:
            if index["name"] == feature_name and state in index["states"]:
                feature = {}
                feature[u"category"] = index["category"]["name"]
                feature[u"feature"] = index["name"]
                feature[u"newvalue"] = state
                feature_list.append(feature)
        response = app_policy.update_application_for_group(app, group, feature_list)
    except KeyError:
        raise KeyError("[Error] Application does not exists, you must create it.")
    print_pretty_json(response)

if args.update_features:
    # Update the sliders for the provide appuri and policy group
    appuri = args.update_features[0]
    group = args.update_features[1]
    settings = json.loads(args.update_features[2])
    application = app_policy.get_applications_by_uri()[appuri]
    application_group = app_policy.get_application_groups_by_name(application=application)[group]
    print(
        app_policy.update_application_for_group(
            application=application,
            application_group=application_group,
            new_settings=settings,
        ))

if args.set_feature_message:
    appuri = args.set_feature_message[0]
    feature_category = args.set_feature_message[1]
    feature_name = args.set_feature_message[2]
    feature_message = args.set_feature_message[3]

    app_policy.refresh()
    application = app_policy.applications_by_appuri[appuri]
    app_feature = app_policy.get_application_feature(
        application=application,
        feature_category=feature_category,
        feature_name=feature_name,
    )
    message_key = "message"
    if feature_name == "Site Access":
        message_key = "message_site_access"
    app_feature["customTokens"][message_key]["value"] = feature_message
    print_pretty_json(app_policy.update_application_feature(application=application, application_feature=app_feature))
