"""Setup module for Ionic Client SDK
"""

from distutils.core import setup

# from codecs import open
# from os import environ, path

projectName = 'pydashboard'

setup(
    name=projectName,
    version="1.0",
    description='pydashboard api',
    long_description="pydashboard api",

    # Replace with eventual dev homepage
    url='https://stash.in.ionicsecurity.com/projects/QA/repos/pydashboard/browse',

    # Author details
    author='Paz Patel',
    author_email='paz@ionicsecurity.com',
    license='Ionic Security SDK License',

    # See https://pypi.python.org/pypi?%3Aaction=list_classifiers
    classifiers=[
        #   3 - Alpha
        #   4 - Beta
        #   5 - Production/Stable
        'Development Status :: 5 - Production/Stable',

        # Indicate who your project is intended for
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries :: Python Modules',

        # Pick your license as you wish (should match "license" above)
        'License :: Ionic Security SDK License',

        # Supported Python versions
        'Programming Language :: Python',
        'Programming Language :: Python :: 2',
        'Programming Language :: Python :: 3',
    ],

    # What does your project relate to?
    keywords='ionic',
    packages=[projectName]

    # package_data={projectName : ['*',]}
    # include_package_data=True
)
