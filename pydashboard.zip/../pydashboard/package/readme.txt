to quickly build a package
mkdir /tmp/somedir
cd /tmp/somedir
git clone ssh://git@stash.in.ionicsecurity.com:7999/qa/pydashboard.git
cp ./pydashboard/package/* ./
python3 setup.py sdist --format=zip
pip3 install dist/pydashboard*zip
pip3 install -r pydashboard/requirements.txt
